# Package Manifest

Package: `source-capture-envelope-v1-pro-review-2026-06-24-r11`

Purpose: focused Pro review package for VAKS Source Capture Envelope v1.0-rc1 r11.

## Included

- `REVIEW_BRIEF.md`: reviewer orientation and verification summary.
- `P0_FIX_NOTES.md`: r10 P0 fix notes.
- `PRO_REVIEW_PROMPT.md`: copy-paste review prompt.
- `SCHEMA.md`, `SOURCE_INTAKE.md`: source contract context.
- `contract/`: package-local contract lint scope.
- `docs/`: source ID and snapshot manifest specs.
- `schemas/`: source capture and snapshot hygiene JSON Schemas.
- `templates/`: Source Card and adjacent intake templates used by contract lint.
- `tools/`: scanner, bundle validator, self-test, contract lint, failure matrix, and enum registry.
- `smoke-linxiv/`: repo archive smoke bundle.
- `smoke-generic-blob/`: generic blob smoke bundle.
- `verification/`: package-local replay results.
- `PACKAGE_FILE_LIST.txt`: package file list with POSIX `/` paths.
- `PACKAGE_SHA256SUMS.txt`: package SHA256 list with POSIX `/` paths.

## Excluded

- Reviewed knowledge writes.
- Candidate/reviewed/action artifacts.
- Databases, services, MCP write layer, DSSE, Rekor, or new review lane.
- `.pyc` and `__pycache__`.

## Scope Boundary

This is an alpha Source Intake / Capture-Provenance hardening slice. Passing this package means the scanner/validator slice is stronger; it does not mean source truth, evidence support, reviewed knowledge, or action readiness.
