# r11 P0 Fix Notes

## P0-1: ZIP Directory Entries Skipped Exact-Stream Inspection

Fixed in `tools/inspect_source_snapshot.py`.

Directory entries are no longer allowed to bypass payload safety checks. The scanner now records every supported ZIP entry in the payload-inspection queue before deciding whether it enters manifest identity.

Directory entries now receive:

- encryption-bit checks
- compression-method checks
- local/central header consistency checks
- exact-stream validation for STORED and DEFLATE

Directory entries still do not become manifest entries, but they must be safety-clean before an archive can be admitted.

Regression coverage:

- DEFLATE directory stream actually decompresses to `EVIL` while headers declare empty directory.
- encrypted directory entry.
- BZIP2 directory entry.
- LZMA directory entry.
- legal STORED empty directory.
- legal DEFLATE empty directory.

## P0-2: DEFLATE Output Budget Was Applied After Allocation

Fixed in `tools/inspect_source_snapshot.py`.

DEFLATE validation no longer calls unbounded `decompress(chunk)`. It now uses bounded output reads:

```python
decompressor.decompress(data, max_length=remaining_budget + 1)
```

The active budget is the minimum of:

- remaining entry-size budget
- remaining archive total-size budget
- compression-ratio budget

Final `flush()` is also bounded. If the scanner sees one byte beyond the budget, it emits `ARCHIVE_ENTRY_SIZE_LIMIT_EXCEEDED`, stops further payload decompression, and produces a quarantined blob bundle.

Regression coverage:

- central directory declares a tiny output while actual DEFLATE output is larger.
- `--max-entry-size 1024` reports an exact-validation size finding at `actual_size = 1025`, showing the scanner stops at budget + 1 instead of materializing the full output.

## Package Scope

No architecture changes were made. Source/Revision/Snapshot/Capture, the three product files, and the bundle validator direction remain unchanged.
