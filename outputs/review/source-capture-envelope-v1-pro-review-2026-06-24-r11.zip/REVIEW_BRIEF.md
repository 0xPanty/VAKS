# VAKS Source Capture Envelope v1.0-rc1 r11 Review Brief

This package is a focused hardening patch for the Source Intake / Capture-Provenance alpha slice.

Architecture is intentionally unchanged:

- Source != Revision != Snapshot != Capture
- Source Card remains a stable identity pointer
- Capture Envelope records one observation
- Snapshot Manifest records deterministic logical content
- Hygiene Statement records versioned facts bound to the snapshot/blob digest

r11 scope is only ZIP scanner hardening for the two residual r10 P0 classes:

1. ZIP directory entries skipped payload, encryption, compression, and exact-stream validation.
2. DEFLATE exact-stream validation could allocate decompressed output before applying the configured output budget.

r11 does not create reviewed knowledge, evidence support, action basis, a database, a service, a review lane, DSSE, or Rekor anchoring.

## r10 Verdict Addressed

r10 fixed ordinary file ZIP payload/header consistency, but failed on directory entry and decompression-budget hardening:

- Directory entries could carry hidden compressed payload, encryption flags, or unsupported compression and still be admitted because directory processing continued before exact-stream checks.
- Malformed DEFLATE entries could expand far beyond `--max-entry-size` before the scanner reported quarantine.

## r11 Changes

- ZIP directory entries now pass through the same safety preflight as files:
  - encryption bit check
  - supported compression check
  - local/central header consistency check
  - exact compressed-stream validation
- Directory entries remain excluded from manifest identity, but they are included in archive safety inspection.
- Directory exact-stream validation requires:
  - actual uncompressed size is zero
  - actual CRC32 is zero
  - DEFLATE reaches EOF
  - all declared compressed bytes are consumed
  - no unused or unconsumed compressed data remains
- DEFLATE validation now uses bounded output calls:
  - `decompress(..., max_length=remaining_budget + 1)`
  - bounded `flush(...)`
  - budget is constrained by entry-size, archive-total-size, and compression-ratio budgets
- Once a ZIP exact-stream hazard is found, the scanner stops further payload decompression and emits a quarantined blob bundle.
- The previous r9/r10 hardening remains in place:
  - ZIP path representation reconciliation
  - DOS/Unix type evidence reconciliation
  - duplicate JSON key rejection
  - local/central header checks
  - staging bundle validation before final output
  - POSIX package checksum paths

## Verification Summary

- `python tools/selftest_source_capture.py`: 63/63 pass
- `python tools/validate_source_capture_envelope.py`: 63/63 pass
- `python tools/validate_source_intake_failure_matrix.py`: 42/42 pass
- `python tools/validate_source_intake_contract.py`: 0 warnings / 0 errors for package-scoped contract set
- `python -m py_compile tools/inspect_source_snapshot.py tools/validate_source_capture_bundle.py tools/selftest_source_capture.py`: pass
- Smoke bundle `smoke-linxiv`: validator pass, admitted with warnings only
- Smoke bundle `smoke-generic-blob`: validator pass, admitted
- Package checksum: pass
- `sha256sum -c PACKAGE_SHA256SUMS.txt`: pass

The broader repository still contains pre-existing unrelated VAKS worktree debt. This package is scoped to Source Capture Envelope v1 review artifacts only.
