# Prompt To Send Pro

Please review r11 / VAKS Source Capture Envelope v1.0-rc1 hardening package.

Package:

`source-capture-envelope-v1-pro-review-2026-06-24-r11.zip`

r10 verdict was fail. r11 does not change the architecture; it only addresses the two residual r10 P0 scanner classes:

1. ZIP directory entries bypassed encryption/compression/payload exact-stream validation.
2. DEFLATE exact-stream validation applied size limits after allocating decompressed output.

Please focus on these checks:

- all ZIP entries, including directories, receive safety checks before type-specific manifest handling.
- directory entries may stay out of manifest identity, but they must participate in archive safety inspection.
- directory exact-stream validation requires actual uncompressed size 0, CRC32 0, decompressor EOF, all declared compressed bytes consumed, and no unused/unconsumed data.
- encrypted directories quarantine.
- BZIP2/LZMA directories quarantine until exact validation exists.
- legal STORED and DEFLATE empty directories remain admitted.
- DEFLATE uses bounded `decompress(..., max_length=remaining_budget + 1)` and bounded `flush(...)`.
- the effective output budget is constrained by entry-size, archive-total-size, and compression-ratio budgets.
- after the first exact-stream size/integrity hazard, scanner stops further payload decompression and emits a quarantined blob.
- existing r9/r10 fixes remain intact: ZIP path representations, DOS/Unix type evidence, duplicate JSON key rejection, local/central header reconciliation, archive-safety profile, staging validator, POSIX checksum paths.
- smoke-linxiv and smoke-generic-blob still validate.
- `sha256sum -c PACKAGE_SHA256SUMS.txt` should work directly from the package directory using POSIX paths.

Included package results:

- selftest: 63/63 pass
- compatibility wrapper selftest: 63/63 pass
- failure matrix: 42/42 pass
- contract lint: 0 warning / 0 error
- py_compile: pass
- smoke-linxiv: pass
- smoke-generic-blob: pass
- package checksum: pass
- `sha256sum -c PACKAGE_SHA256SUMS.txt`: pass
- package contains no `.pyc` / `__pycache__`

Please return:

1. verdict: mergeable / pass-with-changes / fail
2. whether any P0 remains
3. if not mergeable, the minimal required fixes
4. whether architecture changes are needed, or only scanner / validator hardening
