# VAKS Source Capture Store v1 PR-B1 Review Package

Generated: 2026-06-24T19:38:03.825565+00:00
Base commit: b636cac6c001f3ee379a9fdd34c8edd251b0ef9a
Current local tag source-capture-envelope-v1.0-alpha.1: b636cac6c001f3ee379a9fdd34c8edd251b0ef9a

Purpose:
- PR-B1 follow-up after Source Capture Envelope v1.0-alpha.1.
- Adds a local filesystem Capture Store for validated Raw Capture artifacts.
- Scope is init + validated put + raw blob CAS + storage receipt + validation context + idempotent duplicate + capture conflict + verify-capture.

Changed files:
- SCHEMA.md
- SOURCE_INTAKE.md
- docs/source-capture-store-v1.md
- schemas/capture-storage-receipt-v1.schema.json
- schemas/source-capture-store-v1.schema.json
- tools/store_source_capture.py
- tools/selftest_source_capture_store.py

Explicitly out of scope:
- index rebuild / verify-store
- GC / delete / retention policy
- remote store / database / service
- candidate, reviewed, evidence-support, or action artifacts

Package contents:
- README_FOR_PRO.md
- TEST_RESULTS.md
- PATCH.diff
- DIFF_STAT.txt
- DIFF_NAME_STATUS.txt
- CHANGED_FILES.txt
- changed-files/<repo path copies>

Notes:
- No commit has been created from this package.
- Review zip is not intended to be committed.
