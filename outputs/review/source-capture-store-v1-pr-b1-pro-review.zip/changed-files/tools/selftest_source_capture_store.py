#!/usr/bin/env python
"""Self-test Source Capture Store v1 PR-B1 behavior."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent.parent
INSPECTOR = ROOT / "tools" / "inspect_source_snapshot.py"
STORE_TOOL = ROOT / "tools" / "store_source_capture.py"


def run_json(args: list[str], *, expect: int = 0) -> dict[str, Any]:
    result = subprocess.run(args, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != expect:
        raise AssertionError(
            f"command returned {result.returncode}, expected {expect}\n"
            f"args={args}\nstdout={result.stdout}\nstderr={result.stderr}"
        )
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise AssertionError(f"command did not emit JSON\nargs={args}\nstdout={result.stdout}\nstderr={result.stderr}") from exc


def write_zip(path: Path, entries: list[tuple[str, bytes]]) -> None:
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name, data in entries:
            info = zipfile.ZipInfo(name)
            info.date_time = (2026, 1, 1, 0, 0, 0)
            zf.writestr(info, data)


def make_bundle(tmp: Path, name: str, entries: list[tuple[str, bytes]], *extra: str) -> tuple[Path, Path, dict[str, Any]]:
    source = tmp / f"{name}.zip"
    out_dir = tmp / f"{name}-bundle"
    write_zip(source, entries)
    cmd = [
        sys.executable,
        str(INSPECTOR),
        str(source),
        "--out",
        str(out_dir),
        "--source-kind",
        "archive",
        "--capture-method",
        "archive_file",
        *extra,
    ]
    result = run_json(cmd)
    envelope = json.loads((out_dir / "capture-envelope.json").read_text(encoding="utf-8"))
    return source, out_dir, envelope


def store_init(store: Path, *, expect: int = 0) -> dict[str, Any]:
    return run_json([sys.executable, str(STORE_TOOL), "init", "--store-root", str(store)], expect=expect)


def store_put(store: Path, bundle: Path, raw_blob: Path | None = None, *, expect: int = 0) -> dict[str, Any]:
    cmd = [
        sys.executable,
        str(STORE_TOOL),
        "put",
        "--store-root",
        str(store),
        "--bundle-dir",
        str(bundle),
    ]
    if raw_blob is not None:
        cmd.extend(["--raw-blob", str(raw_blob)])
    return run_json(cmd, expect=expect)


def store_verify_capture(store: Path, capture_id: str, *, expect: int = 0) -> dict[str, Any]:
    return run_json(
        [
            sys.executable,
            str(STORE_TOOL),
            "verify-capture",
            "--store-root",
            str(store),
            "--capture-id",
            capture_id,
        ],
        expect=expect,
    )


def capture_dir(store: Path, capture_id: str) -> Path:
    return store / "captures" / capture_id.split("urn:uuid:", 1)[1].lower()


def test_init_rejects_nonempty_without_store_json(tmp: Path) -> None:
    store = tmp / "store"
    store.mkdir()
    (store / "stray.txt").write_text("stray", encoding="utf-8")
    result = store_init(store, expect=1)
    assert result["status"] == "fail"
    assert result["code"] == "STORE_ROOT_NOT_EMPTY"


def test_put_retains_raw_blob_and_is_idempotent(tmp: Path) -> None:
    store = tmp / "store"
    assert store_init(store)["status"] == "pass"
    source, bundle, envelope = make_bundle(tmp, "clean", [("repo/a.txt", b"a")])
    first = store_put(store, bundle, source)
    assert first["status"] == "pass"
    assert first["result"] == "stored"
    assert first["raw_blob_retention_state"] == "retained"
    receipt_path = store / first["receipt"]
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    assert receipt["capture_id"] == envelope["capture_id"]
    assert receipt["raw_blob"]["retention_state"] == "retained"
    assert (store / receipt["raw_blob"]["store_path"]).is_file()
    assert (capture_dir(store, envelope["capture_id"]) / "bundle" / "capture-envelope.json").is_file()
    assert (capture_dir(store, envelope["capture_id"]) / "validation-context" / "raw-intake-policy.json").is_file()
    verify = store_verify_capture(store, envelope["capture_id"])
    assert verify["status"] == "pass"
    duplicate = store_put(store, bundle, source)
    assert duplicate["status"] == "pass"
    assert duplicate["result"] == "already_retained"


def test_put_without_raw_blob_records_not_retained(tmp: Path) -> None:
    store = tmp / "store"
    assert store_init(store)["status"] == "pass"
    _source, bundle, envelope = make_bundle(tmp, "no-raw", [("repo/a.txt", b"a")])
    result = store_put(store, bundle)
    assert result["status"] == "pass"
    receipt = json.loads((capture_dir(store, envelope["capture_id"]) / "capture-storage-receipt.json").read_text(encoding="utf-8"))
    assert receipt["raw_blob"]["retention_state"] == "not_retained"
    assert receipt["raw_blob"]["expected_digest"] == envelope["observation"]["blob"]["digest"]
    assert store_verify_capture(store, envelope["capture_id"])["status"] == "pass"


def test_raw_blob_mismatch_does_not_create_capture(tmp: Path) -> None:
    store = tmp / "store"
    assert store_init(store)["status"] == "pass"
    _source, bundle, envelope = make_bundle(tmp, "mismatch", [("repo/a.txt", b"a")])
    wrong = tmp / "wrong.zip"
    wrong.write_bytes(b"wrong")
    result = store_put(store, bundle, wrong, expect=1)
    assert result["code"] == "RAW_BLOB_DIGEST_MISMATCH"
    assert not capture_dir(store, envelope["capture_id"]).exists()


def test_capture_id_conflict_is_not_overwritten(tmp: Path) -> None:
    store = tmp / "store"
    assert store_init(store)["status"] == "pass"
    source, bundle, envelope = make_bundle(tmp, "first", [("repo/a.txt", b"a")])
    assert store_put(store, bundle, source)["status"] == "pass"
    source2, bundle2, _envelope2 = make_bundle(
        tmp,
        "second",
        [("repo/b.txt", b"b")],
        "--capture-id",
        envelope["capture_id"],
    )
    result = store_put(store, bundle2, source2, expect=1)
    assert result["code"] == "CAPTURE_ID_CONFLICT"
    stored = json.loads((capture_dir(store, envelope["capture_id"]) / "bundle" / "capture-envelope.json").read_text(encoding="utf-8"))
    assert stored["snapshot"]["snapshot_id"] == envelope["snapshot"]["snapshot_id"]


def test_existing_corrupt_cas_blob_is_rejected(tmp: Path) -> None:
    store = tmp / "store"
    assert store_init(store)["status"] == "pass"
    source, bundle, envelope = make_bundle(tmp, "cas-corrupt", [("repo/a.txt", b"a")])
    expected = envelope["observation"]["blob"]["digest"].split(":", 1)[1]
    target = store / "blobs" / "sha256" / expected[:2] / expected
    target.parent.mkdir(parents=True)
    target.write_bytes(b"corrupt")
    result = store_put(store, bundle, source, expect=1)
    assert result["code"] == "STORE_BLOB_FIXITY_MISMATCH"
    assert target.read_bytes() == b"corrupt"


def test_verify_capture_detects_tampering(tmp: Path) -> None:
    store = tmp / "store"
    assert store_init(store)["status"] == "pass"
    source, bundle, envelope = make_bundle(tmp, "tamper", [("repo/a.txt", b"a")])
    assert store_put(store, bundle, source)["status"] == "pass"
    stored_manifest = capture_dir(store, envelope["capture_id"]) / "bundle" / "snapshot-manifest.jsonl"
    stored_manifest.write_text(stored_manifest.read_text(encoding="utf-8") + "\n", encoding="utf-8")
    result = store_verify_capture(store, envelope["capture_id"], expect=1)
    assert result["code"] == "STORE_BUNDLE_FIXITY_MISMATCH"


def main() -> int:
    tests = [
        test_init_rejects_nonempty_without_store_json,
        test_put_retains_raw_blob_and_is_idempotent,
        test_put_without_raw_blob_records_not_retained,
        test_raw_blob_mismatch_does_not_create_capture,
        test_capture_id_conflict_is_not_overwritten,
        test_existing_corrupt_cas_blob_is_rejected,
        test_verify_capture_detects_tampering,
    ]
    with tempfile.TemporaryDirectory(prefix="vaks-source-capture-store-test-") as tmp_raw:
        tmp = Path(tmp_raw)
        for test in tests:
            case_dir = tmp / test.__name__
            if case_dir.exists():
                shutil.rmtree(case_dir)
            case_dir.mkdir()
            test(case_dir)
    print(json.dumps({"passed": len(tests), "tests": [test.__name__ for test in tests]}, allow_nan=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
