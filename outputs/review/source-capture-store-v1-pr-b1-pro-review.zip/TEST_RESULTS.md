# Test Results

Passed:
- python -m py_compile tools\store_source_capture.py tools\selftest_source_capture_store.py tools\inspect_source_snapshot.py tools\validate_source_capture_bundle.py
- python -m json.tool schemas\source-capture-store-v1.schema.json
- python -m json.tool schemas\capture-storage-receipt-v1.schema.json
- python tools\selftest_source_capture_store.py => 7/7
- python tools\selftest_source_capture.py => 99/99
- python tools\validate_source_capture_envelope.py => 99/99
- python tools\validate_source_intake_failure_matrix.py => 45/45
- python tools\validate_source_intake_contract.py => 0 warning / 0 error
- git diff --check -- PR-B1 target files => pass

New PR-B1 store coverage:
- init rejects non-empty directory without store.json.
- put retains raw blob in SHA256 CAS and stores bundle/validation-context/receipt.
- repeated identical put returns already_retained without overwrite.
- put without raw blob records not_retained with expected digest/size.
- raw blob digest mismatch fails and does not create a capture directory.
- same capture_id with different bundle fails CAPTURE_ID_CONFLICT.
- existing corrupt CAS object fails STORE_BLOB_FIXITY_MISMATCH and is not overwritten.
- verify-capture detects stored bundle tampering.

Boundary assertions:
- Store persists Raw Capture artifacts only.
- Receipt attests local retention/fixity only.
- Store does not create source trust, evidence support, reviewed knowledge, or action authorization.
- Index rebuild and verify-store are intentionally deferred to PR-B2.

Additional package replay:
- Extracted PATCH.diff from this zip.
- Applied it to a sparse clean worktree at base HEAD b636cac6c001f3ee379a9fdd34c8edd251b0ef9a.
- Ran py_compile for store tools.
- Ran tools/selftest_source_capture_store.py in that isolated sparse worktree => 7/7.
