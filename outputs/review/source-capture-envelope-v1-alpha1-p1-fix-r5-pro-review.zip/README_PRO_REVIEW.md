# VAKS Source Capture Alpha1 P1 Fix R5 Review Package

Base commit under review: `b06747bb`
Existing local tag still points to failed base commit: `source-capture-envelope-v1.0-alpha.1`
This package contains a working-tree patch only. It has NOT been committed and the tag has NOT been moved.

Fix scope included in this full patch from b06747bb:
1. P1-1 implementation manifest requires the exact 6 component set and exact runtime python/3.10.
2. P1-2 runtime policy must match the policy component pinned by the implementation manifest.
3. P1-3 enterprise validator replays policy decision exactly and requires reason_codes to equal unsafe finding codes.
4. Media-type hint-state hardening:
   - source.kind=pdf with non-PDF detected media requires SOURCE_KIND_FORMAT_MISMATCH/hazard and quarantine by policy replay.
   - hint_match=matched requires locator hint equal detected media type.
   - hint_match=mismatch requires locator hint present and different.
   - hint_match=no_hint forbids locator hint.
   - hint_match=not_comparable is rejected by enterprise-alpha1 because the pinned scanner does not produce it.
   - detection_basis=locator_hint is rejected by enterprise-alpha1 because the pinned scanner does not produce it.
   - mismatch requires MEDIA_TYPE_HINT_MISMATCH/warning.
5. Content-type/snapshot binding:
   - container_parser => archive media type only.
   - magic_signature => application/pdf only.
   - fallback => application/octet-stream only.
   - tree snapshot => detection_basis=container_parser and archive media type.
   - admitted blob => must not use detection_basis=container_parser.
   - detection_basis=container_parser => hygiene profiles must include archive-safety/v1.
   - scanner records archive-safety/v1 whenever its content_type used container_parser, including quarantined source-kind mismatches.
6. New R5 scanner/validator alignment:
   - inspect_path applies --input-profile blob before content_type detection when there is no archive intent.
   - valid ZIP + source_kind=file + capture_method=local_file + input_profile=blob now produces an admitted blob with fallback/application-octet-stream and MEDIA_TYPE_HINT_MISMATCH warning.
   - enterprise-alpha1 staging validator accepts that supported CLI path.

New R5 regression test:
- valid ZIP + --source-kind file + --capture-method local_file + --input-profile blob => exit 0, admitted blob, fallback/application-octet-stream, MEDIA_TYPE_HINT_MISMATCH warning, enterprise validator pass.

Verification run locally after this patch:
- py_compile: pass
- implementation manifest --check: pass
- selftest: 82/82 pass
- compatibility wrapper: 82/82 pass
- failure matrix: 45/45 pass
- source intake contract lint: 0 warning / 0 error
- git diff --check: pass, with only a line-ending warning for tools/selftest_source_capture.py

Review request:
Please verify whether this R5 full patch closes P1-1/P1-2/P1-3, the content-type state-machine blocker, and the --input-profile blob scanner/validator drift. If pass, advise whether to create a follow-up commit and retag `source-capture-envelope-v1.0-alpha.1` to that new commit.
