---
type: pro_review_brief
status: package
created_at: 2026-06-05
project: verified-action-knowledge-system
truth_boundary: review brief only
---

# Pro Review Brief

## Current Claim

VAKS v0.2.13 should keep the minimal mainline rule:

```text
For action_basis and significant promotion / decision use, make support visible:
state the action-facing claim, point-specific anchored evidence, non-circular warrant,
scope / assumptions, known challenges or gaps, and current residual review status.
Diagrams, notation, source counts, tool counts, vendor pages, and confidence labels
do not increase support, independence, or action readiness.
```

## Why It Was Landed

The v0.2.12 spine already had:

```text
Raw Source
-> Source Routing Overlay
-> Candidate Pattern Bank
-> Project Borrowing Ledger / Workspace
-> Evidence-Aware Review
-> Decision / Action Basis
```

The gap exposed by assurance-case / GSN / SACM / CAE material was not "VAKS needs full assurance cases".

The real gap was:

```text
important action-facing claims can have evidence lists without making the evidence-to-claim warrant explicit.
```

So v0.2.13 only landed a final-gate rule, not a new subsystem.

## What Was Tested

Tests completed:

```text
dual-project reuse validation
no-upgrade validation
real promotion validation
landed-rule operational test
expansion sandbox test
```

Key result:

```text
light intake stayed light
medium candidate/project borrowing stayed pre-decision
heavy action use required non-circular warrant
fake support shortcuts were blocked
```

## Seven Expansion Candidates

The seven non-landed expansion candidates:

```text
new schema
new template
formal project development workspace directory
new pattern
GSN / SACM system
tool adoption
all intake heavier
```

Sandbox result:

```text
new schema: reject_for_now
new template: keep_sandboxed
formal project development workspace directory: keep_sandboxed
new pattern: reject_for_now
GSN / SACM system: reject_for_now
tool adoption: reject_for_now
all intake heavier: reject_for_now
```

## What We Need Pro To Judge

Please judge:

```text
1. Is the minimal mainline landing appropriate, or should even that remain sandbox-only?
2. Is the landed wording still too object-like / assurance-case-like?
3. Are the seven expansion verdicts right?
4. Should "new template" remain sandboxed, or should a tiny checklist be promoted later?
5. Should "formal development workspace directory" remain sandboxed, or should it graduate with stronger labels?
6. Did the operational tests actually prove the rule does not burden ordinary intake?
7. What exact wording, if any, should be revised before commit?
```

## Preferred Review Verdict Format

Please answer with:

```text
Verdict: accept_minimal | revise_minimal | rollback_to_candidate | expand_more | reject

Mainline wording:
- keep / revise / rollback

Seven expansion candidates:
- new schema:
- new template:
- formal development workspace directory:
- new pattern:
- GSN / SACM system:
- tool adoption:
- all intake heavier:

Critical risks:

Required next test before commit:

Suggested wording patch if needed:
```

