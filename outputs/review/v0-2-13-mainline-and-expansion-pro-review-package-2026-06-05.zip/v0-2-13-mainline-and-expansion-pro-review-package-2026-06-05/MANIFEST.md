---
type: package_manifest
status: package
created_at: 2026-06-05
project: verified-action-knowledge-system
truth_boundary: manifest only
---

# Manifest

## Root Package Files

```text
00_README.md
MANIFEST.md
UPLOAD_TO_PRO_PROMPT.md
PRO_REVIEW_BRIEF.md
```

## Mainline Materials

```text
materials/mainline/FUSION_ARCHITECTURE_V0_2_DRAFT.md
materials/mainline/ARCHITECTURE_PRINCIPLES.md
materials/mainline/MAINLINE_DIFF.patch
```

Purpose:

```text
Show exactly where the minimal v0.2.13 rule landed.
```

## Recovery / Handoff

```text
materials/handoff/2026-06-05-vaks-v0-2-13-action-support-visibility-handoff.md
materials/review/2026-06-05-v0-2-13-revised-next-window-memory-alignment.md
```

Purpose:

```text
Show current operating status and next-window recovery state.
```

## Core v0.2.13 Review / Test Files

```text
materials/review/2026-06-05-v0-2-13-pro-review-response-revise-candidate.md
materials/review/2026-06-05-v0-2-13-structured-action-basis-envelope-revised-candidate-patch.md
materials/review/2026-06-05-v0-2-13-structured-action-basis-envelope-revised-test.md
materials/review/2026-06-05-v0-2-13-revised-pressure-test-suite.md
materials/review/2026-06-05-v0-2-13-revised-real-action-basis-trial.md
materials/review/2026-06-05-v0-2-13-revised-nonmeta-action-basis-trials.md
materials/review/2026-06-05-v0-2-13-light-medium-heavy-alignment.md
materials/review/2026-06-05-v0-2-13-dual-project-reuse-validation.md
materials/review/2026-06-05-v0-2-13-no-upgrade-validation.md
materials/review/2026-06-05-v0-2-13-real-promotion-validation.md
materials/review/2026-06-05-v0-2-13-landed-rule-operational-test.md
materials/review/2026-06-05-v0-2-13-usage-guide.md
materials/review/2026-06-05-v0-2-13-main-architecture-obsidian-test.md
```

Purpose:

```text
Show the path from Pro's revise_candidate response to landed minimal rule and operational tests.
```

## Expansion Sandbox

```text
materials/expansion_sandbox/00_README.md
materials/expansion_sandbox/EXPANSION_CANDIDATES.md
materials/expansion_sandbox/SANDBOX_TEST_REPORT.md
```

Purpose:

```text
Show the seven non-landed expansion candidates and sandbox verdicts.
```

## Source Basis / Earlier Context

```text
materials/review/2026-06-05-v0-2-12-gsn-assurance-case-cluster-deep-read.md
materials/review/2026-06-05-v0-2-12-intake-trial-scsc-tools.md
materials/review/2026-06-05-v0-2-12-reference-sweep-triage.md
materials/review/2026-06-05-cross-project-borrowing-v0-2-12-delta-test.md
```

Purpose:

```text
Show why assurance-case / GSN / SACM material was treated as support for a small action-basis rule,
not as reason to adopt a full assurance-case system.
```

## Excluded

Not included:

```text
raw source corpus
all old intake files
git commit
push
release tag
```

Reason:

```text
This is a focused v0.2.13 review package, not a full vault archive.
```

