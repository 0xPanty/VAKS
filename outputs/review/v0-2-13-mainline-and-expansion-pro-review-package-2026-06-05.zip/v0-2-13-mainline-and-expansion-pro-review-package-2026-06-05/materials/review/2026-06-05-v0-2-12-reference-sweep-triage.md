---
type: reference_sweep_triage
status: candidate
created_at: 2026-06-05
project: verified-action-knowledge-system
scope: v0.2.12-reference-sweep
input_file: C:\Users\Administrator\.codex\attachments\f0b31ccd-b179-4c3a-856c-6062fe163cf7\pasted-text.txt
formalization_status: candidate-only
truth_boundary: not reviewed knowledge, not architecture decision, not action basis
---

# v0.2.12 Reference Sweep Triage

## Executive Verdict

This pasted batch is not 166 independent references. It is mostly a search-result sweep around sources already examined:

```text
PROV / Web Annotation
GRADE / EtD / NICE / Cochrane
TOGAF Architecture Repository
ADR
GraphRAG / LlamaIndex / Letta
GSN / assurance cases
```

The only clearly new high-value cluster is:

```text
GSN / assurance case / SACM / claims-arguments-evidence tooling and review.
```

That cluster may strengthen VAKS future evidence-aware review / action-basis workbench thinking, but it should remain candidate-only.

## Already Covered: Do Not Re-Deep-Read

| Source / Cluster | Status | Why |
|---|---|---|
| W3C PROV-O | already processed | Already used for provenance = route/derivation, not truth. |
| W3C Web Annotation Data Model | already processed | Already used for overlay/body-target/selector anchor boundary. |
| GRADE Handbook / GRADE Book | already processed | Already used for evidence certainty vs recommendation/decision separation. |
| ILCOR GRADE EtD PDF | already processed | Already used for EtD-lite before decision/action basis. |
| Cochrane Handbook Chapter 5 | already processed | Already used for source_family / anti-double-counting. |
| QualiWare TOGAF Architecture Repository | already processed | Already used for Reference Library vs Standards vs Landscape vs Governance Log. |
| Microsoft GraphRAG docs/blog | already processed | Already used for retrieval/graph/community summaries as activation, not truth. |
| ADR.github.io | already processed | Already used for Borrowing Ledger != ADR. |
| Microsoft / Google ADR | already processed from prior batch | Already used for ADR graduation boundary. |
| LlamaIndex CitationQueryEngine | already processed | Already used for citation node traceability, not evidence support. |
| Letta docs / article | already processed | Already used for memory blocks / archival memory quarantine. |

## Strong New Candidate Cluster

### GSN / Assurance Case / SACM

Representative entries from the pasted sweep:

```text
SCSC GSN / Tools / GSN Standard
OMG Structured Assurance Case Metamodel (SACM)
Claims-Arguments-Evidence material
York / NASA / Rushby assurance case introductions
Assurance-case tool pages such as ASCE, AdvoCATE, NOR-STA, SafeTbox, Socrates
```

Why this matters for VAKS:

```text
It may strengthen the future action-basis / evidence-aware-review surface.
It gives vocabulary for claim / argument / evidence / counterargument / assurance case.
It may help distinguish "evidence organized for review" from "truth already established".
```

Boundary:

```text
Do not turn VAKS into a full assurance-case system.
Do not introduce GSN/SACM as a mainline schema.
Do not make diagrams or argument nodes into reviewed truth.
Do not treat tool catalogues as endorsement or conformance validation.
```

Next deep-read candidates:

| Priority | Candidate | Reason |
|---|---|---|
| 1 | SCSC GSN Standard / GSN overview pages | Closest to the SCSC Tools intake trial and likely primary GSN context. |
| 2 | OMG SACM | Strong formal reference for structured assurance cases; useful boundary source. |
| 3 | Claims-Arguments-Evidence theory / Adelard guide | Could clarify CAE vs GSN and evidence organization. |
| 4 | Rushby / NASA assurance case intro | Useful conceptual support, but likely heavier and more academic. |
| 5 | Tool vendor pages | Discovery only; do not use as independent support for adoption. |

## Medium Support: Optional, Not Urgent

| Cluster | Treatment |
|---|---|
| PROV-DM / PROV-N / PROV rationale papers | Support existing PROV boundary; not needed unless Pro asks for provenance depth. |
| PAV ontology | Could support provenance/authorship/versioning, but likely overkill for current lightweight overlay. |
| Readium / annotation profiles | Support Web Annotation subset/profile idea; not needed now. |
| NICE evidence review pages | Useful official support for evidence summary vs committee decision; already partly covered by UK NSC/GRADE. |
| NHMRC evidence-to-decision pages | Useful parallel to GRADE EtD; likely support-only. |
| Open Group official TOGAF Library / Standards Info Base pages | Stronger primary-source support than blogs; useful if Pro asks for TOGAF precision. |
| GDS Way / codeopinion ADR posts | Support ADR-as-log; not needed after ADR.github.io, Microsoft, Google. |

## Weak / Skip Unless Needed

| Cluster | Reason |
|---|---|
| Wikipedia pages | Orientation only; not evidence for VAKS design. |
| Medium / Dev.to / LinkedIn ADR or TOGAF blogs | Mostly repeat already-covered boundaries. |
| Scribd / SlideShare / random PDF mirrors | Access/quality risk; avoid unless original is unavailable. |
| Reddit threads | Anecdotal only; not useful for current Pro package. |
| Vendor product listings / certification product pages | Discovery only; can introduce endorsement bias. |
| Search-result snippets without direct source URL | Do not treat as source. |

## Impact on Current v0.2.12

No change to core v0.2.12 yet.

Current v0.2.12 still stands:

```text
Raw Source
-> Source Routing Overlay
-> Candidate Pattern Bank
-> Project Borrowing Ledger
-> Evidence-Aware Review / EtD-lite
-> Decision / Action Basis
```

Possible future addition after deep-reading GSN/SACM:

```text
Evidence-aware review may borrow "structured assurance case" as a review/workbench inspiration.
```

But that should not become:

```text
new truth layer
new mandatory diagram layer
new mainline schema
automatic action-basis generator
```

## Recommended Next Move

Deep-read only the GSN / assurance-case cluster next.

Suggested order:

```text
1. SCSC GSN Standard / GSN overview
2. OMG SACM
3. Claims-Arguments-Evidence / Adelard guide
4. Rushby or NASA assurance case intro
5. only then tool vendor pages, as discovery not endorsement
```

Everything else in the pasted batch can be treated as already covered or support-only.
