---
type: delta_test_report
status: candidate
created_at: 2026-06-05
project: verified-action-knowledge-system
scope: cross-project-borrowing-v0-2-12-delta-test
baseline: v0.2.0 three-layer pilot
variant: v0.2.12 post-Pro boundary patch
test_items: 4
formalization_status: candidate-only
truth_boundary: not reviewed knowledge, not architecture decision, not action basis
---

# Cross-Project Borrowing v0.2.12 Delta Test

## 结论先说

v0.2.12 比 v0.2.0 更强，但强在**防污染和减误读**，不是强在多建层。

用同一批 4 个样本复测后，判断是：

```text
v0.2.0:
  能跑通三层拆分。
  证明 source / pattern / ledger 分开有用。
  但会放过一些边界漏写。

v0.2.12:
  仍能跑通。
  能抓出 overlay 写项目姿态、pattern slug 漂移、弱路由过多、ledger 伪 ADR 这些问题。
  但还没有用一条全新资料做真实 intake 速度测试。
```

所以当前 verdict：

```text
Better for boundary safety: yes.
Better for source-card lightness: likely yes, if applied lazily.
Better for operational speed: not proven yet.
Ready for mainline merge: no.
Ready for next real intake trial: yes.
```

## 本次测试怎么做

不回改旧 raw source card，不改模板，不改主线。

复用旧试点的 4 个样本：

| Test | Source | Type |
|---|---|---|
| T1 | `raw/videos/2026-06-04-bilibili-rag-failure-chunking-rerank-prompt-source.md` | short video |
| T2 | `raw/videos/2026-06-04-bilibili-raglab-17-rag-visual-canvas-source.md` | visual-heavy video |
| T3 | `raw/repos/2026-06-04-langchain-miniopenclaw-source.md` | repo |
| T4 | `raw/papers/2026-06-04-rf-mem-recollection-familiarity-source.md` | paper |

对照规则：

```text
v0.2.0 success:
  source -> routing -> pattern -> VAKS ledger 能跑通。

v0.2.12 added checks:
  1. raw source 不回写项目采用判断。
  2. source routing overlay 只写 transferable candidates、constraints、pattern routes、possible_project_ledgers。
  3. overlay 不写 watch / prototype / adapt / reject。
  4. 每个 transferable candidate 尽量有 target anchor。
  5. candidate pattern route 必须用 canonical slug 或明确 alias。
  6. source_family 只防重复，不给 support 加分。
  7. pattern bank 不是 standards，不写 adopted / approved / reviewed。
  8. project borrowing ledger 是 pre-ADR，不写正式 architecture decision。
  9. 真要采用前，需要 evidence-aware review / EtD-lite。
```

## T1: RAG 翻车短视频

### v0.2.0 结果

旧版能跑通：

```text
Source -> Source Routing -> Candidate Pattern -> VAKS Ledger
```

它成功把“固定字数切分、rerank/query expansion、prompt 边界”从 source card 里抽出来。

### v0.2.12 复测

新版更强的地方是 anchor 和弱路由控制。

可用 anchors：

| Candidate | Anchor | Route |
|---|---|---|
| source structure before chunking | `00:41-01:08` | `source-structure-first-rag` |
| rerank / query expansion as retrieval quality tools | `01:40-02:08` | `retrieval-is-activation-not-truth` |
| prompt boundary as answer constraint | `02:08-02:42` | `retrieval-is-activation-not-truth` |

v0.2.12 会做的减法：

```text
simple-first-retrieval-baseline:
  weak route for this sample.
  这条视频没有明确 BM25 / SQLite / FTS baseline。
  更适合停在 local note，不必强行进 pattern route / ledger。
```

结论：

```text
v0.2.12 wins.
原因：少一个弱 pattern route，并且每个候选点能指回时间段。
```

## T2: RAGLab 视觉工作台视频

### v0.2.0 结果

旧版能处理高信息量视频，也证明一个 source 可以路由到多个 pattern。

风险是：路由太容易膨胀。

### v0.2.12 复测

可用 anchors：

| Candidate | Anchor | Route |
|---|---|---|
| visual retrieval workbench | `00:00-01:30`, visual overview | `visual-workbench-for-retrieval-diagnostics` |
| table/source structure affects chunking | `03:00`, Markdown table frame | `source-structure-first-rag` |
| RAGAS/eval is diagnostic, not truth | `04:30-05:10` | `retrieval-is-activation-not-truth` |
| GraphRAG/entity/relation as candidate context | `13:30-15:00` | `graph-and-ontology-as-candidate-context` |
| document hierarchy / PageIndex | `15:30-16:10` | `source-structure-first-rag` |
| source preview / clickback | `16:30` | supports anchor/traceability, not truth |

v0.2.12 会做的减法：

```text
search-to-analysis-before-answer:
  weak route in this sample.
  RAGLab 展示了 retrieval pipeline，但不一定明确展示“先分析再回答”的方法。
  可以保留为 note，不升强路由。
```

结论：

```text
v0.2.12 wins.
原因：它把“多路由”变成“强路由 + 弱路由不升格”，减少 pattern bank 名词堆风险。
```

## T3: miniopenclaw repo

### v0.2.0 结果

旧版能把 repo 拆成：

```text
file-first workbench
skills/prompts as files
memory quarantine
visual inspector
```

### v0.2.12 复测

可用 anchors：

| Candidate | Anchor | Route |
|---|---|---|
| prompt / skill / memory as visible files | `backend/graph/prompt_builder.py`, `backend/tools/skills_scanner.py` | `skills-and-prompts-as-visible-files` |
| memory index as rebuildable cache | `backend/graph/memory_indexer.py` | `memory-granularity-and-quarantine` |
| retrieval cards are activation, not support | `backend/tools/search_knowledge_tool.py` | `retrieval-is-activation-not-truth` |
| inspector/workbench visibility | `frontend/src/components/editor/InspectorPanel.tsx`, `frontend/src/components/chat/ChatPanel.tsx` | `file-first-agent-workbench`, `visual-workbench-for-retrieval-diagnostics` |
| terminal tool safety gap | `backend/tools/terminal_tool.py` | source-bound constraint, not adoption basis |

v0.2.12 抓到一个旧版问题：

```text
source routing ledger 里引用了:
  agent-memory-quarantine

但 candidate pattern bank 里的 canonical slug 是:
  memory-granularity-and-quarantine
```

这说明 v0.2.12 的 canonical slug / alias lint 是有必要的。

结论：

```text
v0.2.12 wins.
原因：它能抓出 pattern 命名漂移；旧版会让近义词慢慢堆成多个假 pattern。
```

## T4: RF-Mem paper

### v0.2.0 结果

旧版能把论文实验结果限制在 activation / retrieval-depth pattern，不把 benchmark 数字当 VAKS truth。

### v0.2.12 复测

可用 anchors：

| Candidate | Anchor | Route |
|---|---|---|
| familiarity fast path | source card `方法结构` / probe-route section | `adaptive-retrieval-depth` |
| recollection slow path | source card `方法结构` / Recollection section | `adaptive-retrieval-depth` |
| similarity/entropy as uncertainty proxy | source card `原文补充点` / limitations | `retrieval-is-activation-not-truth` |
| sensitive memory resurfacing risk | source card `VAKS 候选价值` / risk item | `memory-granularity-and-quarantine` |

v0.2.12 的额外价值：

```text
论文指标可以提高 review priority / design pressure。
论文指标不能变成:
  support strength
  truth confidence
  VAKS action basis
  adoption decision
```

结论：

```text
v0.2.12 slightly wins.
原因：旧版已经边界清楚；新版只是把 EtD-lite / no benchmark-as-support 说得更硬。
```

## 对照总表

| Test Area | v0.2.0 | v0.2.12 | Delta |
|---|---|---|---|
| 三层能否跑通 | pass | pass | unchanged |
| raw source 是否不回改 | pass | pass | unchanged |
| overlay 是否只做路由 | partial | better rule; existing file fails | improvement with required patch |
| overlay 是否有项目 posture 泄漏 | fail: `VAKS: watch/adapt` | caught | clear win |
| candidate 是否有 source anchor | partial | required lightweight anchor | win |
| pattern 路由是否过多 | risk | weaker routes can stay local | win |
| canonical slug | fail on `agent-memory-quarantine` | caught by alias/lint rule | clear win |
| pattern bank 是否像 standards | risk | explicit no-standards boundary | win |
| ledger 是否像 ADR | risk noted | graduation boundary clearer | win |
| source_family 是否防重复 | present | clearer anti-double-count rule | small win |
| 正式采用前 gate | vague review/decision | EtD-lite / ADR graduation | win |
| 操作负担 | low | slightly higher | risk |

## 按新版看，旧文件哪里不合格

这些不是要求马上修，只是 delta test 的发现。

### 1. Source Routing Overlay 写了项目姿态

当前 overlay 表头有：

```text
Project Ledger Routes
```

里面出现：

```text
VAKS: watch/adapt
VAKS: adapt
VAKS: design-only watch
```

按 v0.2.12，应该变成：

```text
possible_project_ledgers: [VAKS]
```

也就是说，source 层只说“可能送去 VAKS ledger 看”，不说 VAKS 的姿态。

### 2. Pattern slug 漂移

当前 overlay 出现：

```text
agent-memory-quarantine
```

但 bank 里的 canonical pattern 是：

```text
memory-granularity-and-quarantine
```

按 v0.2.12，这应该由 alias registry 或 slug lint 抓出来。

### 3. 部分弱路由应降级

示例：

```text
T1 -> simple-first-retrieval-baseline
T2 -> search-to-analysis-before-answer
```

不是完全错，但证据不够强。v0.2.12 更倾向于：

```text
弱路由留在 source note / local note。
只有清楚解决同一个 problem 的路线，才进 pattern route。
```

### 4. 旧 raw source card 里仍有项目化语言

这轮不回改旧卡。

但未来新 intake 应避免把下面这些写成 raw source 的正式结论：

```text
适合 VAKS
不适合 VAKS
VAKS 应采用
Direct use / Adapt / Reject
```

可以写 candidate comprehension 和 candidate points；项目姿态留给 project borrowing ledger。

## 新版最小形态

v0.2.12 不需要把 source card 写重。最小 overlay 行可以是：

```yaml
source_id:
source_family_id:
transferable_candidates:
  - candidate:
    target_anchor:
      anchor_type: time_range | code_path | text_section | page_section
      anchor_value:
    candidate_pattern_routes:
    source_bound_constraints:
possible_project_ledgers:
  - VAKS
notes:
  - routing only; no support strength; no project disposition
```

注意：

```text
possible_project_ledgers 不是 watch/adapt。
candidate_pattern_routes 不是 support strength。
source_family_id 不是独立支持数。
target_anchor 不是 reviewed evidence。
```

## Verdict

v0.2.12 比 v0.2.0 强。

但强的方式很具体：

```text
不是更复杂。
不是多一堆目录。
不是 pattern 更多。

而是：
  更少项目姿态泄漏；
  更少漂亮名词；
  更少把 retrieval/eval/graph 当 truth；
  更清楚何时需要 ADR；
  更清楚何时必须过 evidence-aware review。
```

当前最小下一步：

```text
拿一条全新 source 做 v0.2.12 intake trial。

测试目标不是“能不能写完整报告”，而是：
  source card 是否更轻；
  overlay 是否只写路由和 anchor；
  pattern 是否没有乱增；
  VAKS ledger 是否集中记录项目姿态；
  全程是否没有 mainline / truth / ADR 污染。
```

在这个测试完成前，v0.2.12 应继续留在 `outputs/review`，不要合并主线。
