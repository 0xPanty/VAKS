---
type: intake_trial_report
status: candidate
created_at: 2026-06-05
project: verified-action-knowledge-system
scope: v0.2.12-real-intake-trial
source_id: scsc-tools-gsn-tool-list
source_url: https://scsc.uk/tools
source_type: web_resource
formalization_status: candidate-only
truth_boundary: not reviewed knowledge, not architecture decision, not action basis
---

# v0.2.12 Intake Trial: SCSC GSN Tools Page

## 结论先说

这条新资料适合测试 v0.2.12，因为它自己就有一个强边界：

```text
SCSC 列出 GSN 工具，但声明这不是 endorsement、recommendation 或 conformance validation。
```

按旧 v0.2，很容易把它写成：

```text
这些 GSN 工具适合 VAKS / VAKS 可以借 GSN 工具链。
```

按 v0.2.12，正确结果是：

```text
这是一条外部工具目录 source。
它提供工具发现和设计压力。
它不证明工具好用、合规、适合 VAKS。
它不直接新增 pattern。
它只产生 possible_project_ledgers: [VAKS]。
```

本次 verdict：

```text
v0.2.12 intake trial: pass with useful restraint.

source card lightness: pass.
overlay-only routing: pass.
no new pattern from one source: pass.
no project disposition in overlay: pass.
anchor discipline: pass, using page section/tool-name anchors.
operational burden: acceptable, but still should be lazy.
```

## Source Record: Lightweight

```yaml
source_id: scsc-tools-gsn-tool-list
source_url: https://scsc.uk/tools
source_title: Tools
publisher: Safety-Critical Systems Club
source_type: web_resource
topic: Goal Structuring Notation tools / assurance case tools
captured_at: 2026-06-05
access_boundary: public_no_cookies
page_last_updated: 2025-05-30
capture_note:
  - browser/web open showed verification loader
  - public HTML was retrievable without login/cookies via local HTTP request
  - no tool vendor pages were deeply reviewed in this trial
```

## Candidate Comprehension

The page is a SCSC signposting list of known tools that support GSN, where a GSN tool is described as something that helps develop, present, or maintain an assurance argument using Goal Structuring Notation.

The page explicitly says the list is not an endorsement, recommendation, or validation of conformance with the GSN standard. It also says the list is not complete and may not be up to date.

Tools listed include:

```text
AdvoCATE
ASCE
Astah System Safety
D-Case Editor
gsn2x
NOR-STA
SafeTbox
Socrates
```

The tool descriptions repeatedly mention assurance cases, structured arguments, evidence artifacts, modular GSN, patterns, traceability, baselines, role-based collaboration, integration with evidence repositories, and multiple views of assurance cases.

## Candidate Points

1. External tool catalogues are useful for discovery, but must not be treated as adoption guidance.

2. Assurance case tools commonly combine argument structure, evidence links, project artifacts, and change/history management. This is relevant to VAKS future evidence-aware review or action-basis workbench ideas.

3. Provider-supplied tool descriptions are candidate claims, not independent evaluations. Vendor claims about conformance, maturity, feature coverage, or adoption require primary docs and later review.

4. GSN-related tooling separates argument structure from evidence artifacts. That maps well to VAKS's boundary: evidence support and decision/action basis require explicit review, not tool display.

5. Tool status varies. Some entries mention old tooling, unclear standard versions, unsigned binaries, commercial plugins, or partial support. Version/status metadata must stay as source-bound constraints.

## Source-Bound Constraints

```text
- This page is a signposting catalogue, not a review.
- Many tool capability summaries appear to come from tool providers or marketing material.
- The page is not complete and may not track latest releases.
- SCSC's listing does not validate GSN conformance.
- This trial did not inspect each linked vendor page.
- This source is about GSN / assurance cases, not directly about VAKS source intake or RAG.
```

## v0.2.12 Source Routing Overlay

```yaml
source_id: scsc-tools-gsn-tool-list
source_family_id: sf-assurance-case-tooling
possible_project_ledgers:
  - VAKS
project_disposition_in_overlay: none
support_strength: none
truth_confidence: none
```

| Transferable Candidate | Target Anchor | Candidate Pattern Route | Source-Bound Constraint |
|---|---|---|---|
| Tool directory as discovery, not endorsement | page intro: "not endorsement / recommendation / validation" statement | no existing pattern; anti-pollution rule only | catalogue is not evidence review |
| Assurance argument workbench links claims, evidence, hazards, requirements, and verification artifacts | `AdvoCATE` section | possible future pattern pressure: `structured-assurance-case-workbench`; do not create yet | NASA page not reviewed in this trial |
| Mature assurance case environments can manage structured argument and evidence communication | `ASCE` section | possible future pattern pressure only | vendor claim; commercial product; conformance claim needs independent check |
| Safety/system modelling tool can connect requirements, system models, and GSN/D-Case diagrams | `Astah System Safety` section | possible future pattern pressure only | unclear GSN standard version |
| Argument tooling can include consistency/type checks and monitoring hooks | `D-Case Editor` section | possible future pattern pressure only | appears old; not current adoption evidence |
| File/CLI rendering of GSN can be simple and reproducible | `gsn2x` section | weak route to `file-first-agent-workbench`? rejected as too weak | rendering GSN is not VAKS workbench architecture |
| Assurance case management can include history, baselines, RBAC, evidence repository integration, and APIs | `NOR-STA` section | possible future pattern pressure: `review-ledger-with-baselines` | tool-specific architecture; no adoption decision |
| Assurance case tools may model dialectic/confidence/uncertainty arguments | `SafeTbox` / `Socrates` sections | possible future pattern pressure: `challenge-aware-review-workbench` | terminology differs from VAKS truth/review model |

## Candidate Pattern Bank Decision

Do not add a new pattern from this one source.

Reason:

```text
The page is a catalogue, not a method source.
It gives a cluster of design pressures:
  - structured assurance cases
  - evidence links
  - baselines/history
  - modular arguments
  - confidence/challenge views

But one catalogue page is not enough to promote a canonical pattern.
```

If future sources repeat the same mechanism, possible candidate pattern names could be:

```text
structured-assurance-case-workbench
review-ledger-with-baselines
challenge-aware-review-workbench
```

Current decision:

```text
new_pattern_created: no
existing_pattern_modified: no
alias_registry_change: no
```

## Project Borrowing Ledger Decision

Do not add a VAKS ledger row yet.

Reason:

```text
There is no canonical candidate pattern to borrow yet.
This source only says "VAKS may want to inspect assurance-case tooling as a future reference family."
```

Allowed v0.2.12 route:

```yaml
possible_project_ledgers:
  - VAKS
```

Not allowed in overlay:

```text
VAKS: watch
VAKS: adapt
VAKS should use GSN tools
VAKS should adopt assurance cases
```

## What v0.2.12 Did Better Than v0.2

### 1. It prevented endorsement leakage

The source itself says the list is not an endorsement or validation. v0.2.12 preserves that.

This page therefore becomes:

```text
external discovery source
```

not:

```text
tool recommendation
project decision
architecture standard
```

### 2. It avoided a weak new pattern

Old workflow pressure might create a nice-sounding pattern immediately, such as:

```text
assurance-case-tooling-for-vaks
```

v0.2.12 says no. Park it as pattern pressure until more sources exist.

### 3. It kept project posture out of source routing

The overlay only says:

```text
possible_project_ledgers: [VAKS]
```

It does not say:

```text
VAKS: watch/adapt
```

### 4. It made anchors cheap

A web page does not need heavy citation machinery. The usable anchors are:

```text
page intro
tool section name
specific tool entry
page last-updated note
```

This is enough for routing. It is not evidence review.

### 5. It caught scope fit

This source is not about RAG, vector retrieval, GraphRAG, or Obsidian. It should not be forced into the existing 10 RAG/memory/workbench patterns.

Its real value is later:

```text
evidence-aware review surface
action-basis assurance
decision support / challenge structure
review workbench design
```

## Intake Burden Check

This intake stayed light:

```text
raw/source record: short
candidate comprehension: short
candidate points: 5
overlay routes: anchored, but no project posture
pattern bank change: none
ledger change: none
mainline change: none
```

The extra work v0.2.12 adds is mostly judgment:

```text
Should this create a pattern? no.
Should this create a ledger row? no.
Is this source endorsement? no.
Can it anchor to source sections? yes.
```

That is useful work, not bureaucracy.

## Final Verdict

This real intake trial supports v0.2.12.

The strongest result is not that it extracted more. It extracted less, more cleanly:

```text
1 source captured.
0 raw source rewrites.
0 new patterns.
0 ledger dispositions.
0 mainline changes.
1 clear future reference family: assurance-case tooling.
```

Recommended next step:

```text
Keep this as outputs/review candidate-only.
Do not merge into mainline.
If more GSN / assurance-case sources arrive, test whether a sparse candidate pattern is warranted.
```
