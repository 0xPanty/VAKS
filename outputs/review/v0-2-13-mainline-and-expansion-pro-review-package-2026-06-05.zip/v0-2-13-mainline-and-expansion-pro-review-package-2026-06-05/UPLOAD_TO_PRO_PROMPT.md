请复核这个 VAKS v0.2.13 包。

我需要你重点判断：

1. v0.2.13 最小主线规则是否应该保留：
   `Evidence is not enough; show the non-circular warrant.`

2. 这个规则是否仍然太像新对象 / assurance-case 系统。

3. 七个未落地扩展项的沙盒结论是否合理：
   - new schema
   - new template
   - formal project development workspace directory
   - new pattern
   - GSN / SACM system
   - tool adoption
   - all intake heavier

4. 当前测试是否足够支持“最小规则可以留，但扩展继续沙盒”。

请优先阅读：

```text
00_README.md
PRO_REVIEW_BRIEF.md
MANIFEST.md
materials/mainline/MAINLINE_DIFF.patch
materials/review/2026-06-05-v0-2-13-landed-rule-operational-test.md
materials/expansion_sandbox/SANDBOX_TEST_REPORT.md
materials/handoff/2026-06-05-vaks-v0-2-13-action-support-visibility-handoff.md
```

请按这个格式回复：

```text
Verdict: accept_minimal | revise_minimal | rollback_to_candidate | expand_more | reject

One-sentence reason:

Mainline minimal rule:

Seven expansion candidates:
- new schema:
- new template:
- formal development workspace directory:
- new pattern:
- GSN / SACM system:
- tool adoption:
- all intake heavier:

What is still overreach:

What is under-specified:

What should be tested before commit:

Suggested wording patch:
```

