---
type: pro_review_package_readme
status: package
created_at: 2026-06-05
project: verified-action-knowledge-system
scope: v0.2.13-minimal-mainline-rule-and-expansion-sandbox
truth_boundary: review package only; not reviewed knowledge; not release tag; not action basis
---

# VAKS v0.2.13 Mainline + Expansion Sandbox Pro Review Package

## One-Sentence Summary

VAKS v0.2.13 landed only the minimal mainline rule:

```text
Evidence is not enough; show the non-circular warrant.
```

Everything larger was kept out of mainline and tested in a sandbox.

## What Actually Landed

Landed into main architecture docs:

```text
FUSION_ARCHITECTURE_V0_2_DRAFT.md
ARCHITECTURE_PRINCIPLES.md
```

Landed content:

```text
Action Support Visibility
non-circular warrant for action_basis / significant promotion / decision
evidence list is not action basis by itself
tool/vendor/diagram/source-count/confidence-label shortcuts do not increase support
ordinary capture and ordinary query stay light
```

Plain meaning:

```text
When a claim is about to support action, decision, or important promotion,
VAKS must expose why the anchored evidence supports that claim under scope.
```

## What Did Not Land

These seven expansion options were not landed:

```text
new schema
new template
formal project development workspace directory
new pattern
GSN / SACM system
tool adoption
all intake heavier
```

They were placed into:

```text
materials/expansion_sandbox/
```

Sandbox verdict:

```text
new schema: reject_for_now
new template: keep_sandboxed
formal development workspace directory: keep_sandboxed
new pattern: reject_for_now
GSN / SACM system: reject_for_now
tool adoption: reject_for_now
all intake heavier: reject_for_now
```

## Current Operating Model

```text
light = searchable / source-grounded / recoverable
medium = reusable candidate knowledge + project borrowing workspace
heavy = action / decision / promotion with explicit warrant
```

v0.2.13 applies only to heavy use.

## Package Question For Pro

Please review whether the current split is correct:

```text
minimal rule in mainline: keep or revise?
seven expansions in sandbox: correct, too conservative, or still overreaching?
template / development workspace: should either graduate later, and under what gate?
```

## Important Boundary

This package is not asking Pro to approve a full assurance-case system.

It asks whether VAKS has correctly borrowed only the small useful part:

```text
action-facing support needs visible claim -> evidence -> warrant -> scope -> challenge/status.
```

