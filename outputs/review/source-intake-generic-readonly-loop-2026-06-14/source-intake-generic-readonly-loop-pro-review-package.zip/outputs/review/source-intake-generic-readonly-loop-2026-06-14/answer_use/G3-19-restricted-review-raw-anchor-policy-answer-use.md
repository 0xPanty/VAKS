---
status: allowed_readonly
case_id: G3-19-restricted-review-raw-anchor-policy
decision: allowed_readonly
final_support_refs:
- raw/articles/2026-06-13-flexnote-docs-source/inspected-pages.md
final_support_anchor_refs:
- raw/articles/2026-06-13-flexnote-docs-source/inspected-pages.md#Extracted Source Facts
writeback_attempted: false
promotion_attempted: false
truth_mutation_attempted: false
live_llm_used: false
live_local_lexical_retrieval_used: true
retrieval_scope: local_markdown_corpus_lexical_retrieval
live_tool_runtime_used: false
support_boundary: local_markdown_lexical_retrieval_to_pack_to_answer_use_no_writeback
artifact_kind: live_readonly_test_artifact
retrieval_exclusion: true
default_retrieval: false
indexing_policy: exclude_from_default_retrieval_graph_pack_support
truth_mutation_allowed: false
action_basis_allowed: false
record_kind: runtime_test_artifact
---

# Answer / Use Draft: G3-19-restricted-review-raw-anchor-policy

Allowed read-only answer/use path: final support is restricted to resolved raw/stable source anchors. Candidate, overlay, and rank-selected materials remain orientation or review input.

## Final Support

- `raw/articles/2026-06-13-flexnote-docs-source/inspected-pages.md` anchor=`raw/articles/2026-06-13-flexnote-docs-source/inspected-pages.md#Extracted Source Facts`

## Warnings
