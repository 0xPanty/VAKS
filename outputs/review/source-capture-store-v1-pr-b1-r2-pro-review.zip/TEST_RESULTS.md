# Test Results

Passed in the working tree:
- python -m py_compile tools/store_source_capture.py tools/selftest_source_capture_store.py tools/inspect_source_snapshot.py tools/validate_source_capture_bundle.py
- python tools/selftest_source_capture_store.py => 15/15
- python tools/selftest_source_capture.py => 99/99
- python tools/validate_source_capture_envelope.py => 99/99
- python tools/validate_source_intake_failure_matrix.py => 45/45
- python tools/validate_source_intake_contract.py => 0 warning / 0 error
- python -m json.tool schemas/source-capture-store-v1.schema.json
- python -m json.tool schemas/capture-storage-receipt-v1.schema.json
- git diff --check for the PR-B1 file scope => pass, with existing CRLF warnings for SCHEMA.md and SOURCE_INTAKE.md only

New r2 regression coverage:
- Store root parent symlink/reparse path is rejected.
- Dynamic CAS prefix symlink/reparse path is rejected and cannot write outside the store.
- Stored policy must match the policy component pinned by the stored implementation manifest.
- verify-capture replays stored policy and rejects policy-listed warning admitted bundles.
- Receipt validation-context store_path values must match canonical capture-local paths.
- Receipt retained raw_blob.store_path must match canonical CAS path.
- Concurrent identical put returns stored + already_retained.
- Concurrent conflicting put returns stored + CAPTURE_ID_CONFLICT.

Boundary assertions:
- No index rebuild / verify-store added.
- No GC/delete/retention policy added.
- No database/service/remote store added.
- No candidate/reviewed/evidence-support/action artifacts added.


Additional package replay:
- Extracted PATCH.diff from this zip.
- Applied it to a sparse clean worktree at base HEAD b636cac6c001f3ee379a9fdd34c8edd251b0ef9a.
- Ran py_compile for store tools.
- Ran tools/selftest_source_capture_store.py in that isolated sparse worktree => 15/15.
