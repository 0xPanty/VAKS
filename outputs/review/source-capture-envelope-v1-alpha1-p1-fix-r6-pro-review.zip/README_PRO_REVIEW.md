# VAKS Source Capture Alpha1 P1 Fix R6 Review Package

Base commit under review: `b06747bb`
Existing local tag still points to failed base commit: `source-capture-envelope-v1.0-alpha.1`
This package contains a working-tree patch only. It has NOT been committed and the tag has NOT been moved.

Fix scope included in this full patch from b06747bb:
1. P1-1 implementation manifest requires the exact 6 component set and exact runtime python/3.10.
2. P1-2 runtime policy must match the policy component pinned by the implementation manifest.
3. P1-3 enterprise validator replays policy decision exactly and requires reason_codes to equal unsafe finding codes.
4. Media-type hint-state hardening:
   - source.kind=pdf with non-PDF detected media requires SOURCE_KIND_FORMAT_MISMATCH/hazard and quarantine by policy replay.
   - hint_match=matched requires locator hint equal detected media type.
   - hint_match=mismatch requires locator hint present and different.
   - hint_match=no_hint forbids locator hint.
   - hint_match=not_comparable is rejected by enterprise-alpha1 because the pinned scanner does not produce it.
   - detection_basis=locator_hint is rejected by enterprise-alpha1 because the pinned scanner does not produce it.
   - mismatch requires MEDIA_TYPE_HINT_MISMATCH/warning.
5. Content-type/snapshot binding:
   - container_parser => archive media type only.
   - magic_signature => application/pdf only.
   - fallback => application/octet-stream only.
   - tree snapshot => detection_basis=container_parser and archive media type.
   - admitted blob => must not use detection_basis=container_parser.
   - detection_basis=container_parser => hygiene profiles must include archive-safety/v1.
   - scanner records archive-safety/v1 whenever its content_type used container_parser, including quarantined source-kind mismatches.
6. Scanner/validator alignment:
   - inspect_path applies --input-profile blob before content_type detection when there is no archive intent.
   - valid ZIP + source_kind=file + capture_method=local_file + input_profile=blob produces admitted blob with fallback/application-octet-stream and MEDIA_TYPE_HINT_MISMATCH warning.
7. New R6 policy/path closure:
   - Raw admission policy unsafe matching is fail-closed: unsafe if finding severity is policy-unsafe OR finding code is policy-unsafe.
   - Unknown hazard/error findings cannot be admitted.
   - Policy-listed unsafe codes cannot be admitted even if a malicious bundle downgrades severity to warning.
   - PATH_TOO_LONG remains a repo-portability warning, not a hard manifest validation failure.
   - Validator requires PATH_TOO_LONG/warning when manifest paths exceed recorded max_path_length, but does not reject admitted tree bundles solely for that portability warning.

New R6 regression tests:
- unknown hazard + admitted => enterprise validator fail.
- ARCHIVE_ZIP_STREAM_INTEGRITY_FAILED downgraded to warning + admitted => enterprise validator fail.
- valid archive path > max_path_length => scanner exit 0, admitted tree, PATH_TOO_LONG/warning, enterprise validator pass.

Verification run locally after this patch:
- py_compile: pass
- implementation manifest --check: pass
- selftest: 85/85 pass
- compatibility wrapper: 85/85 pass
- failure matrix: 45/45 pass
- source intake contract lint: 0 warning / 0 error
- git diff --check: pass, with only a line-ending warning for tools/selftest_source_capture.py

Review request:
Please verify whether this R6 full patch closes the remaining Raw admission policy fail-open and PATH_TOO_LONG portability-warning blocker, while preserving all previous P1 closures. If pass, advise whether to create a follow-up commit and retag `source-capture-envelope-v1.0-alpha.1` to that new commit.
