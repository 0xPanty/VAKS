# Source Capture Store PR-B2.1 r4 Pro Review Packet

Baseline: 359614b05ba7 (`source-capture-store-v1-pr-b1`)

Scope: implement Full Store Verification only. This packet does not implement deterministic index rebuild, conformance corpus, repair, GC, retention policy, database, service, candidate/reviewed/action writes, or Source Capture Envelope changes.

r4 closes the r3 finding:
- `verify_store_root()` now performs no-follow/reparse precheck and captures `start_inventory` before `load_store()` reads `store.json`;
- store changes between the initial inventory and `load_store()` are now detected as `STORE_CHANGED_DURING_SCAN` / `indeterminate`;
- a dedicated regression monkeypatches `store_source_capture.load_store()` to mutate `store.json` after loading the old metadata and before verification continues.

Previously closed r2 findings remain covered:
- file inventory includes sha256 digests, so same-size CAS/capture/store.json replacement with restored mtime is detected;
- Store root and `blobs/` parent additions during scan are detected;
- malformed / duplicate-key / missing-field `store.json` returns structured JSON error, not traceback;
- report paths are UTF-8 percent-encoded Store-relative POSIX paths and messages sanitize the Store root path.

Review focus:
1. Can `store.json` changes between initial inventory and `load_store()` still false-pass?
2. Does the pre-inventory path still reject Store root symlink/reparse components before traversal?
3. Did any r2/r3 behavior regress: same-size mutation detection, structured root errors, path encoding, historical `verify_stored_capture()` reuse, orphan vs missing referenced blob handling?
4. Does PR-B2.1 remain read-only and scoped only to full Store verification?