# VAKS Source Capture Alpha1 P1 Fix R3 Review Package

Base commit under review: `b06747bb`
Existing local tag still points to failed base commit: `source-capture-envelope-v1.0-alpha.1`
This package contains a working-tree patch only. It has NOT been committed and the tag has NOT been moved.

Fix scope:
1. P1-1 implementation manifest now requires the exact 6 component set and exact runtime python/3.10.
2. P1-2 runtime policy must match the policy component pinned by the implementation manifest.
3. P1-3 enterprise validator replays policy decision exactly and requires reason_codes to equal unsafe finding codes.
4. Media-type contract hardening:
   - source.kind=pdf with non-PDF detected media requires SOURCE_KIND_FORMAT_MISMATCH/hazard and quarantine by policy replay.
   - hint_match=matched requires locator hint equal detected media type.
   - hint_match=mismatch requires locator hint present and different.
   - hint_match=no_hint forbids locator hint.
   - hint_match=not_comparable is rejected by enterprise-alpha1 because the pinned scanner does not produce it.
   - detection_basis=locator_hint is rejected by enterprise-alpha1 because the pinned scanner does not produce it.
   - mismatch requires MEDIA_TYPE_HINT_MISMATCH/warning.

New since R2:
- Enterprise validator rejects not_comparable so it cannot hide a PDF/ZIP hint mismatch warning.
- Enterprise validator rejects not_comparable even when the hint equals the detected media type.
- Enterprise validator rejects detection_basis=locator_hint, including locator_hint + no_hint contradictions.

Verification run locally after this patch:
- py_compile: pass
- implementation manifest --check: pass
- selftest: 76/76 pass
- compatibility wrapper: 76/76 pass
- failure matrix: 45/45 pass
- source intake contract lint: 0 warning / 0 error
- git diff --check: pass, with only a line-ending warning for tools/selftest_source_capture.py

Review request:
Please verify whether these narrow fixes close P1-1/P1-2/P1-3 and the content-type state-machine blocker. If pass, advise whether to create a follow-up commit and retag `source-capture-envelope-v1.0-alpha.1` to that new commit.
