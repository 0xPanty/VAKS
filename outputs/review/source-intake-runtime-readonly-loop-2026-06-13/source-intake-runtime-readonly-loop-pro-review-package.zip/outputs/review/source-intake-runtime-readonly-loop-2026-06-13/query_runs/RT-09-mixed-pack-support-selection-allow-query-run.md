---
record_kind: query_run_trace
artifact_kind: runtime_test_artifact
status: runtime_fixture
knowledge_status: candidate
retrieval_exclusion: true
default_retrieval: false
indexing_policy: exclude_from_default_retrieval_graph_pack_support
retrieval_policy:
  policy_kind: orientation_only
  pack_allowed: none
  action_basis_allowed: false
  warning_code: context_pack_not_action_basis
query_id: RT-09-mixed-pack-support-selection-allow
query_time: '2026-06-14T01:37:48+00:00'
question_summary: In a mixed pack, can the answer keep only the legal raw anchor as
  support?
verbatim_input: In a mixed pack, can the answer keep only the legal raw anchor as
  support?
query_mode: action
active_project: vaks-source-intake-runtime-readonly
requested_authority_bucket: reviewed_support_or_raw_anchor_only
included_buckets:
- raw_anchor
- candidate_context
excluded_buckets:
- reviewed_writeback
- promotion
retrieval_filters:
  include_candidates: true
  include_overlays: active_project_only
  read_only: true
  writeback_allowed: false
  promotion_allowed: false
selected_items:
- ref: raw/articles/2026-06-13-flexnote-docs-source/inspected-pages.md#Extracted Source
    Facts
  record_kind: source_card
  knowledge_status: raw
  pack_role: support
  warning_code: raw_is_provenance_only
  action_basis_allowed: false
  independent_anchor_ref: raw/articles/2026-06-13-flexnote-docs-source/inspected-pages.md#Extracted
    Source Facts
  selected_by:
    lexical: true
    semantic: false
    graph: false
    metadata: false
    rank: false
    dashboard: false
    legacy_raw_metadata: false
- ref: outputs/review/2026-06-11-AxDSan-mnemosyne-candidate-distillation.md#candidate-points
  record_kind: candidate_distillation
  knowledge_status: candidate
  pack_role: review_input
  warning_code: candidate_not_action_basis
  action_basis_allowed: false
  independent_anchor_ref: ''
  selected_by:
    lexical: false
    semantic: true
    graph: false
    metadata: false
    rank: true
    dashboard: false
    legacy_raw_metadata: false
- ref: outputs/review/project_overlays/vaks/example-confirmed-overlay.md#borrow-scope
  record_kind: project_overlay
  knowledge_status: candidate
  pack_role: review_input
  warning_code: overlay_not_authority
  action_basis_allowed: false
  independent_anchor_ref: ''
  selected_by:
    lexical: false
    semantic: false
    graph: false
    metadata: true
    rank: false
    dashboard: false
    legacy_raw_metadata: false
- ref: raw/articles/2026-01-thinking-os-with-ai-vault-source.md#graph-neighborhood-context
  record_kind: source_card
  knowledge_status: raw
  pack_role: orientation
  warning_code: raw_is_provenance_only
  action_basis_allowed: false
  independent_anchor_ref: graph_path:source->candidate->theme
  selected_by:
    lexical: false
    semantic: false
    graph: true
    metadata: false
    rank: false
    dashboard: false
    legacy_raw_metadata: false
- ref: raw/articles/2026-01-thinking-os-with-ai-vault-source.md#ranked-hit
  record_kind: source_card
  knowledge_status: raw
  pack_role: orientation
  warning_code: raw_is_provenance_only
  action_basis_allowed: false
  independent_anchor_ref: retrieval_rank:0.99
  selected_by:
    lexical: false
    semantic: true
    graph: false
    metadata: false
    rank: true
    dashboard: false
    legacy_raw_metadata: false
support_checks:
- claim_ref: mixed pack final support uses only real raw source anchor
  independent_anchor_ref: raw/articles/2026-06-13-flexnote-docs-source/inspected-pages.md#Extracted
    Source Facts
  support_check_stage: pre_validation_fixture_input
  result_semantics: proposed_fixture_input_not_evaluated_verdict
  proposed_support_result: supported
human_confirmation_required: false
runtime_boundary:
  read_only: true
  writeback_attempted: false
  promotion_attempted: false
  truth_mutation_attempted: false
---

# Query Run Trace

Read-only runtime boundary fixture. This trace is not a reviewed record.

