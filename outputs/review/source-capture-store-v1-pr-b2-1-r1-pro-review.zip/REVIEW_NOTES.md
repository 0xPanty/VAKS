# Source Capture Store PR-B2.1 r1 Pro Review Packet

Baseline: 359614b05ba7 (`source-capture-store-v1-pr-b1`)

Scope: implement Full Store Verification only. This packet does not implement deterministic index rebuild, conformance corpus, repair, GC, retention policy, database, service, candidate/reviewed/action writes, or Source Capture Envelope changes.

Implemented:
- `tools/verify_source_capture_store.py` read-only full Store verifier.
- `schemas/source-capture-store-verification-report-v1.schema.json`.
- `store_source_capture.verify_stored_capture()` wrapper reusing existing historical capture verification.
- Report `assurance_scope` explicitly limits output to local retention/fixity.
- `pass`, `pass_with_warnings`, `fail`, and `indeterminate` Store statuses.
- Valid orphan CAS blob warning; missing referenced blob error.
- `.staging` residue and scan inventory drift are indeterminate.
- Relative POSIX report paths.

Review focus:
1. Does verify-store really call the existing historical capture verification for every valid capture?
2. Is there any skip-invalid or false pass path?
3. Are orphan CAS blobs and missing referenced blobs correctly separated?
4. Can concurrent Store mutation produce a false pass?
5. Are report paths always relative and non-authoritative?
6. Does the report schema or wording accidentally imply source trust, evidence support, review, action readiness, or repair?
