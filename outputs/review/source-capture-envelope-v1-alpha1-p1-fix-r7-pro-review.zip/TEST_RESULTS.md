# Test Results

All commands were run in the working tree with unrelated pre-existing dirty files present, but scoped source-capture checks targeted the four changed files.

Passed:
- python -m py_compile tools\inspect_source_snapshot.py tools\validate_source_capture_bundle.py tools\selftest_source_capture.py tools\validate_source_capture_envelope.py tools\validate_source_intake_contract.py tools\validate_source_intake_failure_matrix.py tools\build_source_capture_implementation_manifest.py
- python tools\build_source_capture_implementation_manifest.py --root . --check => {"components": 6, "status": "pass"}
- python tools\selftest_source_capture.py => 86/86
- python tools\validate_source_capture_envelope.py => 86/86
- python tools\validate_source_intake_failure_matrix.py => 45/45
- python tools\validate_source_intake_contract.py => 0 warning / 0 error
- git diff --check -- tools\inspect_source_snapshot.py tools\validate_source_capture_bundle.py tools\selftest_source_capture.py tools\source_capture_implementation_manifest.json => pass

Additional local adversarial checks:
- unknown hazard injected into admitted bundle => enterprise validator rejects
- policy-listed unsafe code downgraded to warning in admitted bundle => enterprise validator rejects
- unlisted ordinary warning in admitted bundle => enterprise validator passes
- long manifest path with PATH_TOO_LONG removed => enterprise validator rejects
- long manifest path with unrelated PATH_TOO_LONG path => enterprise validator rejects

New r7 extra hardening beyond Pro's two P1s:
- PATH_TOO_LONG warning must bind to the actual over-limit manifest path.
- Root-stripped manifest paths are matched against original archive finding paths by exact match or single-root suffix match.
