# Source Capture Store PR-B2.1 r3 Pro Review Packet

Baseline: 359614b05ba7 (`source-capture-store-v1-pr-b1`)

Scope: implement Full Store Verification only. This packet does not implement deterministic index rebuild, conformance corpus, repair, GC, retention policy, database, service, candidate/reviewed/action writes, or Source Capture Envelope changes.

r3 closes the prior r2 findings:
- inventory starts at Store root and covers root, blobs parent, store.json, captures, blobs/sha256, .staging, and actual entries;
- file fingerprints include sha256 digest, so same-size content replacement with restored mtime is detected;
- malformed / duplicate-key / missing-field store.json returns structured JSON error, not traceback;
- captures directory shape/IO errors are structured;
- report paths are UTF-8 percent-encoded Store-relative POSIX paths;
- report messages sanitize the Store root path;
- selftests validate report schema shape for generated reports.

Review focus:
1. Can same-size CAS, capture artifact, or store.json changes with restored mtime still false-pass?
2. Can unknown Store root entries or unsupported blob algorithm dirs added during scan still false-pass?
3. Does malformed / duplicate-key / missing-field store.json still traceback?
4. Can malicious path names make the report violate its schema or leak absolute Store paths?
5. Does verify-store still call historical verify_stored_capture for valid captures?
6. Are orphan vs missing referenced blobs and assurance_scope boundaries still correct?
