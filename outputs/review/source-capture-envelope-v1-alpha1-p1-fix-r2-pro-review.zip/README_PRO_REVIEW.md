# VAKS Source Capture Alpha1 P1 Fix R2 Review Package

Base commit under review: `b06747bb`
Existing local tag still points to failed base commit: `source-capture-envelope-v1.0-alpha.1`
This package contains a working-tree patch only. It has NOT been committed and the tag has NOT been moved.

Fix scope:
1. P1-1 implementation manifest now requires the exact 6 component set and exact runtime python/3.10.
2. P1-2 runtime policy must match the policy component pinned by the implementation manifest.
3. P1-3 enterprise validator replays policy decision exactly and requires reason_codes to equal unsafe finding codes.
4. Media-type contract hardening:
   - source.kind=pdf with non-PDF detected media requires SOURCE_KIND_FORMAT_MISMATCH/hazard and quarantine by policy replay.
   - hint_match=matched requires locator hint equal detected media type.
   - hint_match=mismatch requires locator hint present and different.
   - hint_match=no_hint forbids locator hint.
   - hint_match=not_comparable requires locator hint.
   - mismatch requires MEDIA_TYPE_HINT_MISMATCH/warning.

Verification run locally after this patch:
- py_compile: pass
- implementation manifest --check: pass
- selftest: 73/73 pass
- compatibility wrapper: 73/73 pass
- failure matrix: 45/45 pass
- source intake contract lint: 0 warning / 0 error

Review request:
Please verify whether these narrow fixes close P1-1/P1-2/P1-3 and D. If pass, advise whether to create a follow-up commit and retag `source-capture-envelope-v1.0-alpha.1` to that new commit.
