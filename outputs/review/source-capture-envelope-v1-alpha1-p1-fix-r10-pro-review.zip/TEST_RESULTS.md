# Test Results

Passed:
- python -m py_compile tools\inspect_source_snapshot.py tools\validate_source_capture_bundle.py tools\selftest_source_capture.py tools\validate_source_capture_envelope.py tools\validate_source_intake_contract.py tools\validate_source_intake_failure_matrix.py tools\build_source_capture_implementation_manifest.py
- python tools\build_source_capture_implementation_manifest.py --root . --check => {"components": 6, "status": "pass"}
- python tools\selftest_source_capture.py => 94/94
- python tools\validate_source_capture_envelope.py => 94/94
- python tools\validate_source_intake_failure_matrix.py => 45/45
- python tools\validate_source_intake_contract.py => 0 warning / 0 error
- git diff --check -- policies\source-capture\raw-intake-default-v1.json tools\inspect_source_snapshot.py tools\validate_source_capture_bundle.py tools\selftest_source_capture.py tools\source_capture_implementation_manifest.json => pass

New r10 regression coverage:
- 100 ZIP paths over max_path_length => admitted/pass, no truncation marker
- 101 ZIP paths over max_path_length => admitted/pass, HYGIENE_FINDINGS_TRUNCATED PATH_TOO_LONG=1
- 1000 ZIP paths over max_path_length => admitted/pass, HYGIENE_FINDINGS_TRUNCATED PATH_TOO_LONG=900
- 101 TAR paths over max_path_length => admitted/pass, HYGIENE_FINDINGS_TRUNCATED PATH_TOO_LONG=1
- 1000 TAR paths over max_path_length => admitted/pass, HYGIENE_FINDINGS_TRUNCATED PATH_TOO_LONG=900

Validator behavior:
- Explicit PATH_TOO_LONG findings must still bind to real over-limit manifest paths.
- If some over-limit manifest paths are not explicitly bound, their missing count must exactly match HYGIENE_FINDINGS_TRUNCATED.details.truncated_by_code.PATH_TOO_LONG.
- No truncation marker means every over-limit path must be explicitly bound.
- Truncation count must not be larger or smaller than actual missing over-limit path count.
- HYGIENE_FINDINGS_TRUNCATED must use warning severity.

Not claimed in this package:
- The external 1008-combination enumerator was not rerun locally in this turn; Pro should rerun it if desired.
