# VAKS Source Capture Envelope v1.0-alpha.1 P1 Fix r8 Review Package

Generated: 2026-06-24T13:50:13.279086+00:00
Base commit: b06747bb0474261fc835d50c482a6317bb78dfb8
Current local tag source-capture-envelope-v1.0-alpha.1: b06747bb0474261fc835d50c482a6317bb78dfb8

Purpose:
- Narrow follow-up package for Pro review before any final commit or tag move.
- Addresses the latest two P1 blockers:
  1. Enterprise validator now binds policy and implementation descriptor to the pinned implementation manifest.
  2. Extremely long archive paths now have defined scanner/validator behavior instead of staging traceback.

Changed files:
- policies/source-capture/raw-intake-default-v1.json
- tools/inspect_source_snapshot.py
- tools/validate_source_capture_bundle.py
- tools/selftest_source_capture.py
- tools/source_capture_implementation_manifest.json

Package contents:
- README_FOR_PRO.md
- TEST_RESULTS.md
- PATCH.diff
- DIFF_STAT.txt
- DIFF_NAME_STATUS.txt
- CHANGED_FILES.txt
- changed-files/<repo path copies>

Notes:
- No commit has been created from this package.
- The local alpha tag still points to the base commit at package time.
- The policy file is included because the new ARCHIVE_PATH_LENGTH_LIMIT_EXCEEDED hazard must be unsafe under the pinned raw policy.
- The package intentionally excludes an extracted review directory to avoid duplicate content drift.
