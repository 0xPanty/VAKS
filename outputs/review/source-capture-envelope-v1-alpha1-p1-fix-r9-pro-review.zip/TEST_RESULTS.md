# Test Results

Passed:
- python -m py_compile tools\inspect_source_snapshot.py tools\validate_source_capture_bundle.py tools\selftest_source_capture.py tools\validate_source_capture_envelope.py tools\validate_source_intake_contract.py tools\validate_source_intake_failure_matrix.py tools\build_source_capture_implementation_manifest.py
- python tools\build_source_capture_implementation_manifest.py --root . --check => {"components": 6, "status": "pass"}
- python tools\selftest_source_capture.py => 92/92
- python tools\validate_source_capture_envelope.py => 92/92
- python tools\validate_source_intake_failure_matrix.py => 45/45
- python tools\validate_source_intake_contract.py => 0 warning / 0 error
- git diff --check -- policies\source-capture\raw-intake-default-v1.json tools\inspect_source_snapshot.py tools\validate_source_capture_bundle.py tools\selftest_source_capture.py tools\source_capture_implementation_manifest.json => pass

New r9 regression coverage:
- repo/provider_archive with raw path r/<259 chars> succeeds as admitted tree after root stripping; no PATH_TOO_LONG warning is emitted because manifest path is within max_path_length.
- pdf + ZIP long path succeeds as quarantined blob with unavailable manifest; PATH_TOO_LONG warning is allowed without complete-manifest binding.

Previously retained r8 coverage:
- fake producer/checker implementation descriptor fails enterprise validation
- unpinned policy file fails enterprise validation
- policy missing hazard/error unsafe severities fails scanner/validator policy loading
- archive path exactly 16384 chars remains PATH_TOO_LONG warning + admitted tree
- archive path 16385 chars becomes structured ARCHIVE_PATH_LENGTH_LIMIT_EXCEEDED hazard + quarantined blob
- archive path near ZIP name limit becomes structured quarantine without staging validator traceback
- PATH_TOO_LONG warning must bind to the actual over-limit complete manifest path

Not claimed in this package:
- The external 1008-combination enumerator was not rerun locally in this turn; Pro should rerun it if desired.
