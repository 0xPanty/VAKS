# VAKS Source Capture Alpha1 P1 Fix Review Package

Base commit under review: `b06747bb`
Existing tag currently points to the failed base commit: `source-capture-envelope-v1.0-alpha.1`

This package contains a working-tree patch only. It has NOT been committed and the tag has NOT been moved.

Fix scope:
1. P1-1 implementation manifest cannot shrink to unrelated files.
   - Runtime loader now requires the exact 6 expected components.
   - Runtime block must be exactly python / 3.10.
2. P1-2 runtime policy must be the policy pinned by implementation manifest.
   - `--policy-file` outside or different from the pinned policy component fails before capture.
3. P1-3 enterprise validator replays policy/media-type contract.
   - No unsafe finding => disposition must be admitted and reason_codes empty.
   - Unsafe finding codes must exactly equal reason_codes.
   - `source.kind=pdf` with non-PDF detected media type requires SOURCE_KIND_FORMAT_MISMATCH.

Verification run locally after this patch:
- py_compile: pass
- implementation manifest --check: pass
- selftest: 72/72 pass
- compatibility wrapper: 72/72 pass
- failure matrix: 45/45 pass
- source intake contract lint: 0 warning / 0 error

Review request:
Please verify whether these narrow fixes close the three P1 blockers. If pass, advise whether to create a follow-up commit and retag `source-capture-envelope-v1.0-alpha.1` to that new commit.
