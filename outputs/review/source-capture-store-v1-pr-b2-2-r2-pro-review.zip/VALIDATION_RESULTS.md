# Validation Results

Baseline: 10e7be9ac4630730473f3c6c30622b31dabab998

Commands run:

- `python -m py_compile tools\rebuild_source_snapshot_index.py tools\store_source_capture.py tools\verify_source_capture_store.py tools\selftest_source_capture_store.py` -> pass
- `git diff --check -- tools/rebuild_source_snapshot_index.py schemas/source-snapshot-index-v1.schema.json tools/selftest_source_capture_store.py docs/source-capture-store-v1.md SCHEMA.md` -> pass
- `python tools\selftest_source_capture_store.py` -> pass, 62/62
- `python tools\selftest_source_capture.py` -> pass, 99/99
- `python tools\validate_source_intake_failure_matrix.py` -> pass, 45/45
- `python tools\build_source_capture_implementation_manifest.py --root . --check` -> pass, 6 components
- `python tools\validate_source_intake_contract.py --scope contract --root . --out-dir <temp>` -> pass, 11 validated, 0 warnings, 0 errors

Changes since r1:

- Adds `collect_store_truth_inventory()` that covers Store truth roots while excluding `indexes/`.
- Writes the new index to a temp file, then performs a final Store truth inventory check before `os.replace`.
- If Store truth changes after build/final window, returns `STORE_CHANGED_DURING_INDEX_REBUILD` / `indeterminate` and preserves the old index.
- Adds regression `test_rebuild_index_detects_store_change_after_final_inventory_before_replace`.

Scope:

- Adds deterministic `indexes/source-snapshot-index.jsonl` rebuild/check tooling.
- Reuses B2.1 full Store verification before projection.
- Orphan CAS blobs remain warnings and are not indexed.
- Invalid capture or unstable Store blocks rebuild and preserves old index.
- `--check` is read-only.
- No repair, GC, database, service, candidate/reviewed/action writes, or trust elevation.
