# VAKS Source Capture Envelope v1.0-alpha.1 PR-A Review Package

Commit: `b06747bb`
Tag: `source-capture-envelope-v1.0-alpha.1`
Baseline: `9e976120 Add Source Capture Envelope v1 alpha`

Scope:
- PR-A operational hardening only.
- Includes raw input blob limit, scanner-selected content type, implementation manifest pinning, real Raw intake policy digest/decision replay, and provider object ID alias contract.
- Does not include Capture Store, Conformance Corpus, database, MCP write layer, DSSE/Rekor, full vault migration, review lane changes, or automatic evidence review.

Package contents:
- `COMMIT_NAME_STATUS.txt`: commit summary and changed file list.
- `COMMIT_DIFF.patch`: full binary-safe commit patch.
- `CHANGED_FILE_LIST.txt`: exact files changed by the commit.
- `verification/source_capture_alpha1_closing_summary.json`: verification summary from the commit.
- `changed-files/`: exact changed files as committed.

Verification already run by Codex:
- py_compile: pass
- implementation manifest check: pass
- selftest: 68/68
- compatibility wrapper: 68/68
- failure matrix: 45/45
- source intake contract lint: 0 warnings / 0 errors
- git diff --cached --check before commit: pass
- isolated worktree verification: pass

Review request:
Please verify whether PR-A can remain merged/tagged as `source-capture-envelope-v1.0-alpha.1`, and only raise blocking issues if they are reproducible P0/P1 within this PR-A scope.
