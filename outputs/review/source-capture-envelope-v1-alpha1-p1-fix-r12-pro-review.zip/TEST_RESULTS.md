# Test Results

Passed:
- python -m py_compile tools\inspect_source_snapshot.py tools\validate_source_capture_bundle.py tools\selftest_source_capture.py tools\validate_source_capture_envelope.py tools\validate_source_intake_contract.py tools\validate_source_intake_failure_matrix.py tools\build_source_capture_implementation_manifest.py
- python tools\build_source_capture_implementation_manifest.py --root . --check => {"components": 6, "status": "pass"}
- python tools\selftest_source_capture.py => 99/99
- python tools\validate_source_capture_envelope.py => 99/99
- python tools\validate_source_intake_failure_matrix.py => 45/45
- python tools\validate_source_intake_contract.py => 0 warning / 0 error
- git diff --check -- policies\source-capture\raw-intake-default-v1.json tools\inspect_source_snapshot.py tools\validate_source_capture_bundle.py tools\selftest_source_capture.py tools\source_capture_implementation_manifest.json => pass

New r12 regression coverage:
- 101 PATH_TOO_LONG manifest paths + tampered hygiene.parameters.max_findings_per_code=1 + one explicit PATH_TOO_LONG + marker=100 => enterprise validator rejects.

Retained r11 regression coverage:
- HYGIENE_FINDINGS_TRUNCATED claiming ARCHIVE_PATH_TRAVERSAL while bundle remains admitted => enterprise validator rejects.
- 101 PATH_TOO_LONG manifest paths with all explicit PATH_TOO_LONG findings deleted and marker=101 => enterprise validator rejects.
- PATH_TOO_LONG warning for x/P no longer suffix-binds manifest path P; exact path binding is required.
- Multiple HYGIENE_FINDINGS_TRUNCATED markers => enterprise validator rejects.

Validator behavior:
- Enterprise alpha1 pins hygiene.parameters.max_findings_per_code to the scanner constant 100.
- HYGIENE_FINDINGS_TRUNCATED may appear at most once and must use warning severity.
- Marker counts must be positive and each marked code must retain exactly max_findings_per_code explicit findings.
- For complete manifests, PATH_TOO_LONG explicit findings must exactly equal sorted(over-limit manifest paths)[:max_findings_per_code].
- PATH_TOO_LONG marker count must exactly equal max(0, over-limit path count - max_findings_per_code).
- Marker codes listed as policy-unsafe participate in policy replay and cannot remain admitted.

Not claimed in this package:
- The external 1008-combination enumerator was not rerun locally in this turn; Pro should rerun it if desired.
