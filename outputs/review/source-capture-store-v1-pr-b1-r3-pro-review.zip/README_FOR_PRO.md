# VAKS Source Capture Store v1 PR-B1 r3 Review Package

Generated: 2026-06-24T21:24:56Z
Base commit: b636cac6c001f3ee379a9fdd34c8edd251b0ef9a
Current local tag source-capture-envelope-v1.0-alpha.1: b636cac6c001f3ee379a9fdd34c8edd251b0ef9a

Purpose:
- PR-B1 follow-up after Source Capture Envelope v1.0-alpha.1.
- Adds a local filesystem Capture Store for validated Raw Capture artifacts.
- r3 specifically closes the r2 Pro finding: verify-capture must run historical enterprise-alpha1 semantics, not only base validation.

Scope:
- Store init.
- Validated put.
- Raw blob CAS retention.
- Capture storage receipt.
- Stored validation context.
- Idempotent duplicate put.
- Capture ID conflict rejection.
- verify-capture with stored-context historical enterprise-alpha1 state validation.

Explicitly out of scope:
- Index rebuild / verify-store.
- GC / delete / retention policy.
- Remote store / database / service.
- Candidate, reviewed, evidence-support, or action artifacts.

Changed files:
- SCHEMA.md
- SOURCE_INTAKE.md
- docs/source-capture-store-v1.md
- schemas/capture-storage-receipt-v1.schema.json
- schemas/source-capture-store-v1.schema.json
- tools/store_source_capture.py
- tools/selftest_source_capture_store.py


Package contents:
- PATCH.diff
- changed-files/<repo-path>
- TEST_RESULTS.md
- DIFF_STAT.txt
- DIFF_NAME_STATUS.txt
- CHANGED_FILES.txt

Notes:
- No commit has been created from this package.
- Review zip is not intended to be committed.
- Store receipt remains retention/fixity only; it is not source trust, evidence support, review status, or action authorization.
