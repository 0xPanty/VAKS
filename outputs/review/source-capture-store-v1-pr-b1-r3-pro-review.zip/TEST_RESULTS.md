# Test Results

Passed in the working tree:
- python -m py_compile tools/store_source_capture.py tools/selftest_source_capture_store.py
- python tools/selftest_source_capture_store.py => 19/19
- python tools/selftest_source_capture.py => 99/99
- python tools/validate_source_capture_envelope.py => 99/99
- python tools/validate_source_intake_failure_matrix.py => 45/45
- python tools/validate_source_intake_contract.py => 0 warning / 0 error
- python -m json.tool schemas/source-capture-store-v1.schema.json
- python -m json.tool schemas/capture-storage-receipt-v1.schema.json
- git diff --check for the PR-B1 file scope => pass, with existing CRLF warnings for SCHEMA.md and SOURCE_INTAKE.md only

Existing PR-B1 regression coverage retained:
- Store root parent symlink/reparse path is rejected.
- Dynamic CAS prefix symlink/reparse path is rejected and cannot write outside the store.
- Stored policy must match the policy component pinned by the stored implementation manifest.
- verify-capture replays stored policy and rejects policy-listed warning admitted bundles.
- Receipt validation-context store_path values must match canonical capture-local paths.
- Receipt retained raw_blob.store_path must match canonical CAS path.
- Concurrent identical put returns stored + already_retained.
- Concurrent conflicting put returns stored + CAPTURE_ID_CONFLICT.

New r3 historical enterprise-alpha1 regression coverage:
- Stored tree capture tampered to observation.content_type.detection_basis=magic_signature and application/pdf is rejected by verify-capture.
- Stored hygiene parameters.max_findings_per_code changed to 1 is rejected by verify-capture.
- Stored content_type.hint_match=not_comparable is rejected by verify-capture.
- Stored content_type.detection_basis=locator_hint is rejected by verify-capture.

Boundary assertions:
- No index rebuild / verify-store added.
- No GC/delete/retention policy added.
- No database/service/remote store added.
- No candidate/reviewed/evidence-support/action artifacts added.


Additional package replay:
- Extracted PATCH.diff from this zip.
- Applied it to a sparse clean worktree at base HEAD b636cac6c001f3ee379a9fdd34c8edd251b0ef9a.
- Ran py_compile for store tools.
- Ran tools/selftest_source_capture_store.py in that isolated sparse worktree => 19/19.
