# Evidence Packet AVERITEC-005
marker: EVIDENCE_AVERITEC-005_ANCHOR
claim: After the police shooting of Jacob Blake, Gov. Tony Evers & Lt. Gov. Mandela Barnes did not call for peace or encourage calm.
evidence: Inn a video statement posted the next day, Evers urged people planning to protest to peacefully. In a news release later that day, Evers said "Tonight, and in the days ahead, if you are going to protest, please do so peacefully and safely. Please do not allow the actions of a few distract us from the work we must do together to demand justice, equity, and accountability." This proves that the claim made by Senator Howard Marklein is incorrect that the Gov. did not ask for peace.
