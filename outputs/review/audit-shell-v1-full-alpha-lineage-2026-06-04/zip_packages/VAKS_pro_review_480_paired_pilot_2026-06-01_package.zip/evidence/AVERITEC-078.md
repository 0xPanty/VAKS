# Evidence Packet AVERITEC-078
marker: EVIDENCE_AVERITEC-078_ANCHOR
claim: Drinking traditional Chinese medicine (TCM) or steroids, along with antibiotics at the onset of symptoms cures COVID-19.
evidence: No Scientists around the world are working to find and develop treatments for COVID-19. Home remedies and traditional medicine do not cure Covid-19. Dexamethasone is a corticosteroid that can help reduce the length of time on a ventilator and save lives of patients with severe and critical illness. Steroids can help treat the symptoms of Covid-19 but they do not cure it.
