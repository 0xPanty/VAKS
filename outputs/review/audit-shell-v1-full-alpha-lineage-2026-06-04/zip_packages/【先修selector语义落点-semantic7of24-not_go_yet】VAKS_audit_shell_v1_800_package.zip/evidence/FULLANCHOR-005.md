# Evidence FULLANCHOR-005
marker: EVIDENCE_FULLANCHOR-005_REAL_SNAPSHOT
quote: d not call for peace, calm after Blake shooting goes too far 25 captures 29 Aug 2020 - 05 Dec 2025 Mar APR May 28 2020 2021 2022 success fail About this capture COLLECTED BY Collec
url: https://web.archive.org/web/20210428162642/https://www.politifact.com/factchecks/2020/aug/28/howard-marklein/claim-evers-barnes-did-not-call-peace-calm-after-b/
snapshot_kind: live_urllib_retry
quote_strategy: body_window
semantic_selector_success: false
boilerplate_quote: true
