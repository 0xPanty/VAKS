# Evidence FULLANCHOR-015
marker: EVIDENCE_FULLANCHOR-015_REAL_SNAPSHOT
quote: ill to allow officers arrest without a warrant? Yes! – Dubawa 15 captures 06 Oct 2020 - 18 Feb 2026 Apr MAY Jun 13 2020 2021 2022 success fail About this capture COLLECTED BY Organ
url: https://web.archive.org/web/20210513172441/https://dubawa.org/did-president-buhari-sign-a-new-police-bill-to-allow-officers-to-arrest-without-a-warrant-yes/
snapshot_kind: live_urllib_retry
quote_strategy: body_window
semantic_selector_success: false
boilerplate_quote: true
