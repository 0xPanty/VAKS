# Evidence FULLANCHOR-018
marker: EVIDENCE_FULLANCHOR-018_REAL_SNAPSHOT
quote: likely to kill than be killed by a criminal in 2019 30 captures 27 Aug 2020 - 05 Dec 2025 Mar APR May 19 2020 2021 2022 success fail About this capture COLLECTED BY Organization: A
url: https://web.archive.org/web/20210419235356/https://www.politifact.com/factchecks/2020/aug/27/chris-larson/yes-police-were-208-more-likely-kill-be-killed-cri/
snapshot_kind: live_urllib_retry
quote_strategy: body_window
semantic_selector_success: false
boilerplate_quote: true
