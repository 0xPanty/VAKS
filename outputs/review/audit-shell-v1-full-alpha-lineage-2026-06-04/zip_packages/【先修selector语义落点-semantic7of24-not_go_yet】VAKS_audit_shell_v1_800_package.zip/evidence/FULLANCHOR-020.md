# Evidence FULLANCHOR-020
marker: EVIDENCE_FULLANCHOR-020_REAL_SNAPSHOT
quote: ad Misinformation At RNC 2020 13 captures 27 Aug 2020 - 17 Jan 2026 Jan FEB Mar 24 2020 2021 2022 success fail About this capture COLLECTED BY Collection: Common Crawl Web crawl da
url: https://web.archive.org/web/20210224210242/https://www.boomlive.in/world/president-donald-trump-republicans-spread-misinformation-at-rnc-2020-9501
snapshot_kind: live_urllib_retry
quote_strategy: body_window
semantic_selector_success: false
boilerplate_quote: true
