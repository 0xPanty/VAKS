# Evidence FULLANCHOR-006
marker: EVIDENCE_FULLANCHOR-006_REAL_SNAPSHOT
quote: nt of CLAT 2020 is False 6 captures 22 Sep 2020 - 07 Dec 2024 Aug SEP Oct 22 2019 2020 2021 success fail About this capture COLLECTED BY Collection: Common Crawl Web crawl data fro
url: https://web.archive.org/web/20200922100752/https://newsmeter.in/viral-claim-about-postponement-of-clat-2020-is-false/
snapshot_kind: live_urllib_retry
quote_strategy: body_window
