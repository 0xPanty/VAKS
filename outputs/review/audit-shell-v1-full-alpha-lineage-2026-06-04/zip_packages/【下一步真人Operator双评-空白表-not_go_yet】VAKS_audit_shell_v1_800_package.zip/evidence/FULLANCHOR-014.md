# Evidence FULLANCHOR-014
marker: EVIDENCE_FULLANCHOR-014_REAL_SNAPSHOT
quote: Joe Biden and support for wars 37 captures 27 Aug 2020 - 13 Feb 2026 Apr MAY Jun 06 2020 2021 2022 success fail About this capture COLLECTED BY Collection: web_domain_tests WARCs f
url: https://web.archive.org/web/20210506070632/https://www.politifact.com/factchecks/2020/aug/26/rand-paul/fact-checking-rand-paul-joe-biden-and-support-wars/
snapshot_kind: live_urllib_retry
quote_strategy: body_window
