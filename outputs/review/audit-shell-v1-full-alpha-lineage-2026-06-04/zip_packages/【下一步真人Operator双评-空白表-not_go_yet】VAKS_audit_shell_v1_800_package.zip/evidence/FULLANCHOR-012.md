# Evidence FULLANCHOR-012
marker: EVIDENCE_FULLANCHOR-012_REAL_SNAPSHOT
quote: his numbers on government revenue share in Nigeria - Africa Check 12 captures 07 Mar 2021 - 24 Jun 2024 Feb MAR Apr 07 2020 2021 2022 success fail About this capture COLLECTED BY
url: https://web.archive.org/web/20210307003741/https://africacheck.org/fact-checks/reports/kenyas-ex-prime-minister-odinga-mangles-his-numbers-government-revenue-share
snapshot_kind: live_urllib_retry
quote_strategy: body_window
