# Evidence FULLANCHOR-019
marker: EVIDENCE_FULLANCHOR-019_REAL_SNAPSHOT
quote: ate, claims Make It 16 – Australian Associated Press 6 captures 31 Aug 2020 - 30 May 2024 Aug SEP Oct 24 2019 2020 2021 success fail About this capture COLLECTED BY Collection: Com
url: https://web.archive.org/web/20200924204255/https://www.aap.com.au/lower-voting-age-higher-participation-rate-claims-make-it-16/
snapshot_kind: live_urllib_retry
quote_strategy: body_window
