# Evidence FULLANCHOR-001
marker: EVIDENCE_FULLANCHOR-001_REAL_SNAPSHOT
quote: ght of the 2020 RNC 17 captures 29 Aug 2020 - 10 Feb 2026 Dec JAN Feb 11 2020 2021 2022 success fail About this capture COLLECTED BY Organization: Archive Team Formed in 2009, the
url: https://web.archive.org/web/20210111003633/https://www.politifact.com/article/2020/aug/26/fact-checking-second-night-2020-rnc/
snapshot_kind: live_urllib_retry
quote_strategy: body_window
