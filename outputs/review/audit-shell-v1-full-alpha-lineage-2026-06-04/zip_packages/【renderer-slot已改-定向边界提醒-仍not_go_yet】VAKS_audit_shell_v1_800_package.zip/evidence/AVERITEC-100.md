# Evidence AVERITEC-100
marker: EVIDENCE_AVERITEC-100_ANCHOR
quote: No Yes
