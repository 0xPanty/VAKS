# Evidence AVERITEC-115
marker: EVIDENCE_AVERITEC-115_ANCHOR
quote: Yes Yes
