# Evidence FEVER-080
marker: EVIDENCE_FEVER-080_ANCHOR
quote: Ambegaon_-LRB-Vidhan_Sabha_constituency-RRB- | 3 | It is a part of the Shirur -LRB- Lok Sabha constituency -RRB- in the Pune district along with five other assembly constituencies , viz Junnar , Khed Alandi , Shirur , Bh
