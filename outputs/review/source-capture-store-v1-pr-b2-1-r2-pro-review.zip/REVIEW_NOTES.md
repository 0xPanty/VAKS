# Source Capture Store PR-B2.1 r2 Pro Review Packet

Baseline: 359614b05ba7 (`source-capture-store-v1-pr-b1`)

Scope: implement Full Store Verification only. This packet does not implement deterministic index rebuild, conformance corpus, repair, GC, retention policy, database, service, candidate/reviewed/action writes, or Source Capture Envelope changes.

r2 closes the prior r1 review findings:
- removed `--output`; report is stdout-only, so verifier does not write report files;
- inventory now includes `store.json` and file identity/size/mtime metadata;
- `validation-context/` is exact-shape checked;
- malformed receipt / duplicate key / expected IO validation errors become structured findings and scanning continues;
- Store root unknown entries and unsupported blob algorithm directories are rejected.

Review focus:
1. Does removing `--output` fully close Store clobber and symlink overwrite?
2. Can same-path CAS, capture artifact, or store.json changes during scan still false-pass?
3. Is validation-context exact-shape complete?
4. Does malformed JSON/receipt become a structured finding while other captures continue?
5. Are orphan vs missing referenced blobs still correctly separated?
6. Are report paths relative and is assurance_scope still non-trust / non-review / non-action?
