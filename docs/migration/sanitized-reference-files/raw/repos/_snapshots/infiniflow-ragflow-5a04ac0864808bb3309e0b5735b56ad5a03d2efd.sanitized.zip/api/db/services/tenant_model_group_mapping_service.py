#
#  Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#
from api.db.db_models import DB, TenantModelGroupMapping
from api.db.services.common_service import CommonService


class TenantModelGroupMappingService(CommonService):
    model = TenantModelGroupMapping

    @classmethod
    @DB.connection_context()
    def get_by_composite_id(cls, group_id, provider_id, instance_id, model_id):
        return cls.model.get_or_none(
            cls.model.group_id == group_id,
            cls.model.provider_id == provider_id,
            cls.model.instance_id == instance_id,
            cls.model.model_id == model_id,
        )