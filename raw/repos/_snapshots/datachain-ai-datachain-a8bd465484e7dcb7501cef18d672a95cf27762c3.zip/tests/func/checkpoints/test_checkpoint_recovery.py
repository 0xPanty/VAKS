from collections.abc import Iterator

import pytest

import datachain as dc
from datachain import func
from datachain.lib.file import File
from tests.utils import reset_session_job_state, skip_if_not_sqlite


@pytest.fixture(autouse=True)
def mock_is_script_run(monkeypatch):
    monkeypatch.setattr("datachain.query.session.is_script_run", lambda: True)


@pytest.fixture
def nums_dataset(test_session):
    return dc.read_values(num=[1, 2, 3, 4, 5, 6], session=test_session).save("nums")


@pytest.fixture
def nums_letters(test_session):
    nums_data = [1, 2, 3, 4, 5, 6]
    letters_data = ["A", "A", "B", "B", "C", "C"]
    return dc.read_values(
        num=nums_data, letter=letters_data, session=test_session
    ).save("nums_letters")


@pytest.mark.parametrize(
    "batch_size,fail_after_count",
    [
        (2, 3),  # batch_size=2: Fail after 3 rows
        (3, 4),  # batch_size=3: Fail after 4 rows
        (5, 3),  # batch_size=5: Fail after 3 rows
    ],
)
def test_udf_signals_continue_from_partial(
    test_session_tmpfile,
    monkeypatch,
    nums_dataset,
    batch_size,
    fail_after_count,
):
    """Test continuing UDF execution from partial output table.

    Tests with different batch sizes to ensure partial results are correctly handled
    regardless of batch boundaries.
    """
    test_session = test_session_tmpfile
    processed_nums = []

    dc.read_values(num=[1, 2, 3, 4, 5, 6], session=test_session).save("nums")

    def process_buggy(num) -> int:
        if len(processed_nums) >= fail_after_count:
            raise Exception(f"Simulated failure after {len(processed_nums)} rows")
        processed_nums.append(num)
        return num * 10

    chain = dc.read_dataset("nums", session=test_session).settings(
        batch_size=batch_size
    )

    # -------------- FIRST RUN (FAILS WITH BUGGY UDF) -------------------
    reset_session_job_state()

    with pytest.raises(Exception, match="Simulated failure after"):
        chain.map(result=process_buggy, output=int).save("results")

    assert len(processed_nums) == fail_after_count

    # -------------- SECOND RUN (FIXED UDF) -------------------
    reset_session_job_state()

    processed_nums.clear()

    # Use same function name so partial hash matches (simulates fixing the bug)
    def process_buggy(num) -> int:
        processed_nums.append(num)
        return num * 10

    chain.map(result=process_buggy, output=int).save("results")

    result = dc.read_dataset("results", session=test_session).to_list("result")
    assert sorted(result) == [(10,), (20,), (30,), (40,), (50,), (60,)]

    # Continuation must skip already-processed inputs, not reprocess all 6
    assert 0 < len(processed_nums) < 6


@pytest.mark.parametrize(
    "batch_size,fail_after_count",
    [
        (2, 2),  # batch_size=2: Fail after 2 inputs (4 outputs → 2 batches saved)
        (3, 4),  # batch_size=3: Fail after 4 inputs
        (10, 3),  # batch_size=10: Fail after 3 inputs
    ],
)
def test_udf_generator_continue_from_partial(
    test_session,
    monkeypatch,
    batch_size,
    fail_after_count,
):
    processed_nums = []

    dc.read_values(num=[1, 2, 3, 4, 5, 6], session=test_session).save("nums")

    def buggy_generator(num) -> Iterator[int]:
        if len(processed_nums) >= fail_after_count:
            raise Exception(f"Simulated failure after {len(processed_nums)} inputs")
        processed_nums.append(num)
        yield num * 10
        yield num * num

    chain = dc.read_dataset("nums", session=test_session).settings(
        batch_size=batch_size
    )

    # -------------- FIRST RUN (FAILS WITH BUGGY GENERATOR) -------------------
    reset_session_job_state()

    with pytest.raises(Exception, match="Simulated failure after"):
        chain.gen(value=buggy_generator, output=int).save("gen_results")

    assert len(processed_nums) == fail_after_count

    # -------------- SECOND RUN (FIXED GENERATOR) -------------------
    reset_session_job_state()

    processed_nums.clear()

    def buggy_generator(num) -> Iterator[int]:
        processed_nums.append(num)
        yield num * 10
        yield num * num

    chain.gen(value=buggy_generator, output=int).save("gen_results")

    result = sorted(
        dc.read_dataset("gen_results", session=test_session).to_list("value")
    )
    expected = sorted(
        [
            (1,),
            (10,),
            (4,),
            (20,),
            (9,),
            (30,),
            (16,),
            (40,),
            (25,),
            (50,),
            (36,),
            (60,),
        ]
    )

    assert result == expected

    # Continuation must skip already-processed inputs, not reprocess all 6
    assert 0 < len(processed_nums) < 6


def test_generator_incomplete_input_recovery(test_session):
    """Test full recovery flow from incomplete inputs.

    Tests the complete checkpoint recovery mechanism:
    1. First run fails, leaving some inputs incomplete (missing final row)
    2. Second run detects incomplete inputs
    3. Filters out partial results from incomplete inputs
    4. Re-processes incomplete inputs
    5. Final results are correct (no duplicates, no missing values)
    """
    processed_inputs = []
    run_count = [0]
    numbers = list(range(1, 9))

    def gen_multiple(num) -> Iterator[int]:
        processed_inputs.append(num)
        for i in range(5):
            if num == 8 and i == 2 and run_count[0] == 0:
                raise Exception("Simulated crash")
            yield num * 100 + i

    dc.read_values(num=numbers, session=test_session).save("nums")

    # -------------- FIRST RUN (FAILS) -------------------
    reset_session_job_state()
    processed_inputs.clear()

    with pytest.raises(Exception, match="Simulated crash"):
        (
            dc.read_dataset("nums", session=test_session)
            .settings(batch_size=1)
            .gen(result=gen_multiple, output=int)
            .save("results")
        )

    # -------------- SECOND RUN (RECOVERS) -------------------
    reset_session_job_state()
    processed_inputs.clear()
    run_count[0] += 1

    (
        dc.read_dataset("nums", session=test_session)
        .settings(batch_size=1)
        .gen(result=gen_multiple, output=int)
        .save("results")
    )

    # Input 8 (which crashed mid-yield) must be re-processed
    assert 8 in processed_inputs

    result = (
        dc.read_dataset("results", session=test_session)
        .order_by("result")
        .to_list("result")
    )

    expected = sorted([(num * 100 + i,) for num in numbers for i in range(5)])
    actual = sorted(result)

    assert actual == expected, (
        f"Should have all 20 outputs with no duplicates or missing.\n"
        f"Expected: {expected}\n"
        f"Actual: {actual}"
    )

    # Verify each input has exactly 5 outputs
    result_by_input = {}
    for (val,) in result:
        input_id = val // 100
        result_by_input.setdefault(input_id, []).append(val)

    for input_id in numbers:
        assert len(result_by_input.get(input_id, [])) == 5, (
            f"Input {input_id} should have exactly 5 outputs"
        )

    # Verify no duplicates
    all_results = [val for (val,) in result]
    assert len(all_results) == len(set(all_results)), "Should have no duplicate results"


def test_generator_yielding_nothing(test_session, monkeypatch, nums_dataset):
    """Test that generator correctly handles inputs that yield zero outputs.

    Uses fail_after_count=4 so that regardless of DB row ordering, at least
    one odd input (which yields nothing) is processed before the failure.
    With 6 inputs (3 odd, 3 even), any 4 must include at least 1 odd.
    """
    fail_after_count = 4
    processed = []
    skipped = []
    call_count = [0]

    def selective_generator(num) -> Iterator[int]:
        processed.append(num)
        call_count[0] += 1
        if call_count[0] > fail_after_count:
            raise Exception("Simulated failure")
        if num % 2 == 0:  # Only even numbers yield outputs
            yield num * 10
        else:
            skipped.append(num)

    # First run - fails after processing 4 inputs
    reset_session_job_state()
    chain = dc.read_dataset("nums", session=test_session).gen(
        value=selective_generator, output=int
    )

    with pytest.raises(Exception, match="Simulated failure"):
        chain.save("results")

    assert len(processed) == fail_after_count + 1  # 4 succeeded + 1 failed
    skipped_first_run = list(skipped)
    assert skipped_first_run, "Expected at least one empty-yield input"

    # Second run - should continue from checkpoint
    reset_session_job_state()
    processed.clear()
    skipped.clear()
    call_count[0] = 0
    chain.save("results")

    # Empty-yield inputs from first run must not be re-processed
    assert not set(skipped_first_run) & set(processed), (
        f"Empty-yield inputs {set(skipped_first_run) & set(processed)} "
        f"were re-processed despite being checkpointed"
    )
    assert len(processed) == 2
    # Final result: all even numbers yield output
    result = sorted(dc.read_dataset("results", session=test_session).to_list("value"))
    assert result == [(20,), (40,), (60,)]


def test_empty_dataset_checkpoint(test_session):
    processed = []

    def mapper(num) -> int:
        processed.append(num)
        return num * 10

    dc.read_values(num=[], session=test_session).save("empty_nums")

    reset_session_job_state()
    chain = dc.read_dataset("empty_nums", session=test_session).map(
        result=mapper, output=int
    )
    chain.save("results")

    assert len(processed) == 0

    # Second run should also work (checkpoint reuse with empty result)
    reset_session_job_state()
    processed.clear()
    chain.save("results")

    assert len(processed) == 0

    result = dc.read_dataset("results", session=test_session).to_list("result")
    assert result == []


def test_single_row_dataset_checkpoint(test_session):
    processed = []
    run_count = {"value": 0}

    def mapper(num) -> int:
        processed.append(num)
        if run_count["value"] == 0:
            raise Exception("First run failure")
        return num * 10

    dc.read_values(num=[42], session=test_session).save("single_num")

    reset_session_job_state()
    chain = (
        dc.read_dataset("single_num", session=test_session)
        .settings(
            batch_size=10  # Batch size larger than dataset
        )
        .map(result=mapper, output=int)
    )

    with pytest.raises(Exception, match="First run failure"):
        chain.save("results")

    assert len(processed) == 1

    reset_session_job_state()
    processed.clear()
    run_count["value"] += 1

    chain.save("results")

    result = dc.read_dataset("results", session=test_session).to_list("result")
    assert result == [(420,)]


def test_multiple_consecutive_failures(test_session):
    """Test checkpoint recovery across multiple consecutive failures.

    Scenario: fail at row 3, then fail at row 5, then succeed.
    Each run should continue from where the previous one left off.
    """
    processed = []
    run_count = {"value": 0}

    def flaky_mapper(num) -> int:
        processed.append(num)
        if run_count["value"] == 0 and len(processed) >= 3:
            raise Exception("First failure at row 3")
        if run_count["value"] == 1 and len(processed) >= 3:
            raise Exception("Second failure at row 3 (of remaining)")
        return num * 10

    dc.read_values(num=[1, 2, 3, 4, 5, 6, 7, 8], session=test_session).save("nums")

    chain = dc.read_dataset("nums", session=test_session).settings(batch_size=2)

    # -------------- FIRST RUN: Fails after processing 3 rows -------------------
    reset_session_job_state()

    with pytest.raises(Exception, match="First failure"):
        chain.map(result=flaky_mapper, output=int).save("results")

    first_run_processed = len(processed)
    assert first_run_processed == 3

    # -------------- SECOND RUN: Continues but fails again -------------------
    reset_session_job_state()
    processed.clear()
    run_count["value"] += 1

    with pytest.raises(Exception, match="Second failure"):
        chain.map(result=flaky_mapper, output=int).save("results")

    second_run_processed = len(processed)
    # Should process some rows (continuing from first run's checkpoint)
    assert second_run_processed > 0

    # -------------- THIRD RUN: Finally succeeds -------------------
    reset_session_job_state()
    processed.clear()
    run_count["value"] += 1

    chain.map(result=flaky_mapper, output=int).save("results")

    # Verify final result is correct
    result = dc.read_dataset("results", session=test_session).to_list("result")
    assert sorted(result) == [(10,), (20,), (30,), (40,), (50,), (60,), (70,), (80,)]


def test_generator_multiple_consecutive_failures(test_session):
    processed = []
    run_count = {"value": 0}

    fail_on = {0: 3, 1: 5}  # run_count -> num that triggers failure

    def flaky_generator(num) -> Iterator[int]:
        processed.append(num)
        target = fail_on.get(run_count["value"])
        if target is not None and num == target:
            raise Exception(f"Failure on num={num}")
        yield num * 10
        yield num * 100

    dc.read_values(num=[1, 2, 3, 4, 5, 6], session=test_session).save("nums")

    chain = (
        dc.read_dataset("nums", session=test_session)
        .order_by("num")
        .settings(batch_size=2)
    )

    # -------------- FIRST RUN: Fails on num=3 -------------------
    reset_session_job_state()

    with pytest.raises(Exception, match="Failure on num=3"):
        chain.gen(result=flaky_generator, output=int).save("results")

    # -------------- SECOND RUN: Continues, may or may not hit num=5 -------------------
    reset_session_job_state()
    processed.clear()
    run_count["value"] += 1

    try:
        chain.gen(result=flaky_generator, output=int).save("results")
    except Exception:  # noqa: BLE001
        reset_session_job_state()
        processed.clear()
        run_count["value"] += 1
        chain.gen(result=flaky_generator, output=int).save("results")

    # Verify final result is correct (each input produces 2 outputs)
    result = dc.read_dataset("results", session=test_session).to_list("result")
    expected = [(i * 10,) for i in range(1, 7)] + [(i * 100,) for i in range(1, 7)]
    assert sorted(result) == sorted(expected)

    # Verify no duplicates
    values = [r[0] for r in result]
    assert len(values) == len(set(values))


def test_multiple_udf_chain_continue(test_session):
    """Test continuing from partial with multiple UDFs in chain.

    When mapper fails, only mapper's partial table exists. On retry, mapper
    completes and gen runs from scratch.
    """
    map_processed = []
    gen_processed = []
    fail_once = [True]  # Mutable flag to track if we should fail

    dc.read_values(num=[1, 2, 3, 4, 5, 6], session=test_session).save("nums")

    def mapper(num: int) -> int:
        map_processed.append(num)
        # Fail before processing the 4th row in first run only
        if fail_once[0] and len(map_processed) == 3:
            fail_once[0] = False
            raise Exception("Map failure")
        return num * 2

    def doubler(doubled) -> Iterator[int]:
        gen_processed.append(doubled)
        yield doubled
        yield doubled

    # First run - fails in mapper
    # batch_size=2: processes [1,2] (commits), then [3,4] (fails on 4)
    reset_session_job_state()
    chain = (
        dc.read_dataset("nums", session=test_session)
        .settings(batch_size=2)
        .map(doubled=mapper)
        .gen(value=doubler, output=int)
    )

    with pytest.raises(Exception, match="Map failure"):
        chain.save("results")

    # Second run - completes successfully
    # Mapper continues from partial checkpoint
    reset_session_job_state()
    chain.save("results")

    # Verify mapper processed some rows (continuation working)
    # First run: 3 rows attempted
    # Second run: varies by warehouse (0-6 rows depending on batching/buffer behavior)
    # Total: 6-9 calls (some rows may be reprocessed if not saved to partial)
    assert 6 <= len(map_processed) <= 9, "Expected 6-9 total mapper calls"

    assert len(gen_processed) == 6

    result = sorted(dc.read_dataset("results", session=test_session).to_list("value"))
    assert sorted([v[0] for v in result]) == sorted(
        [2, 2, 4, 4, 6, 6, 8, 8, 10, 10, 12, 12]
    )


def test_file_udf_continue_from_partial(test_session, tmp_dir):
    """Test checkpoint continuation with File objects (file downloading UDFs).

    Ensures that File objects are correctly reconstructed from the checkpoint's
    input table on the second run (regression test for bytes vs str path issue).
    """
    # Create test files
    file_names = [f"file_{i}.txt" for i in range(6)]
    for name in file_names:
        (tmp_dir / name).write_text(f"content of {name}", encoding="utf-8")

    processed_files = []

    def process_file(file: File) -> int:
        if len(processed_files) >= 3:
            raise Exception("Simulated failure after 3 files")
        data = file.read()
        processed_files.append(file.path)
        return len(data)

    chain = (
        dc.read_storage(tmp_dir.as_uri(), session=test_session)
        .order_by("file.path")
        .settings(batch_size=2)
    )

    # -------------- FIRST RUN (FAILS AFTER 3 FILES) -------------------
    reset_session_job_state()

    with pytest.raises(Exception, match="Simulated failure after 3 files"):
        chain.map(file_size=process_file).save("file_results")

    assert len(processed_files) == 3

    # -------------- SECOND RUN (CONTINUES FROM CHECKPOINT) -------------------
    reset_session_job_state()
    processed_files.clear()

    def process_file_fixed(file: File) -> int:
        data = file.read()
        processed_files.append(file.path)
        return len(data)

    chain.map(file_size=process_file_fixed).save("file_results")

    result = dc.read_dataset("file_results", session=test_session).to_list("file_size")
    assert len(result) == 6

    # Second run should only process remaining files
    assert 0 < len(processed_files) <= 6


def test_skip_udf_fallback_when_output_table_missing(test_session):
    call_count = {"value": 0}

    def mapper(num) -> int:
        call_count["value"] += 1
        return num * 10

    dc.read_values(num=[1, 2, 3, 4, 5, 6], session=test_session).save("nums")
    chain = dc.read_dataset("nums", session=test_session).map(result=mapper, output=int)

    # -------------- FIRST RUN -------------------
    reset_session_job_state()
    assert chain.count() == 6
    assert call_count["value"] == 6

    catalog = test_session.catalog

    # Drop all UDF output tables from first run
    for table_name in catalog.warehouse.db.list_tables(pattern="udf_%"):
        if "_output" in table_name and "_partial" not in table_name:
            table = catalog.warehouse.db.get_table(table_name)
            catalog.warehouse.db.drop_table(table, if_exists=True)

    # -------------- SECOND RUN -------------------
    reset_session_job_state()
    call_count["value"] = 0

    result = chain.order_by("num").to_list("result")

    # UDF should have been re-executed from scratch (fallback from skip)
    assert call_count["value"] == 6
    assert result == [(10,), (20,), (30,), (40,), (50,), (60,)]


def test_continue_udf_fallback_when_partial_table_missing(test_session):
    fail_flag = [True]

    def mapper(num) -> int:
        if fail_flag[0] and num >= 4:
            raise RuntimeError("Simulated failure")
        return num * 10

    dc.read_values(num=[1, 2, 3, 4, 5, 6], session=test_session).save("nums")
    chain = dc.read_dataset("nums", session=test_session).settings(batch_size=2)

    # -------------- FIRST RUN (FAILS) -------------------
    reset_session_job_state()
    with pytest.raises(RuntimeError, match="Simulated failure"):
        chain.map(result=mapper, output=int).save("results")

    catalog = test_session.catalog
    test_session.get_or_create_job()

    # Drop all partial output tables from first run
    for table_name in catalog.warehouse.db.list_tables(pattern="udf_%"):
        if "_partial" in table_name:
            table = catalog.warehouse.db.get_table(table_name)
            catalog.warehouse.db.drop_table(table, if_exists=True)

    # -------------- SECOND RUN -------------------
    reset_session_job_state()
    fail_flag[0] = False

    chain.map(result=mapper, output=int).save("results")

    # UDF should have been re-executed from scratch (fallback from continue)
    result = dc.read_dataset("results", session=test_session).to_list("result")
    assert sorted(result) == [(10,), (20,), (30,), (40,), (50,), (60,)]


def test_aggregator_continue_from_partial(test_session, nums_letters):
    fail_after_count = 2
    processed_partitions = []
    should_fail = True

    def aggregator(letter, num) -> Iterator[tuple[str, int]]:
        """
        Aggregator that fails on the (fail_after_count+1)th partition when
        should_fail is True. Simulates a bug fix by toggling the flag.
        """
        if should_fail and len(processed_partitions) >= fail_after_count:
            raise Exception(
                f"Simulated failure after {len(processed_partitions)} partitions"
            )
        nums_list = list(num)
        processed_partitions.append(nums_list)
        # Yield tuple of (letter, sum) to preserve partition key in output
        yield letter[0], sum(n for n in nums_list)

    # -------------- FIRST RUN (FAILS WITH BUGGY AGGREGATOR) -------------------
    reset_session_job_state()

    chain = dc.read_dataset("nums_letters", session=test_session).settings(batch_size=1)
    with pytest.raises(Exception, match="Simulated failure after"):
        chain.agg(
            total=aggregator,
            partition_by="letter",
        ).save("agg_results")

    first_run_count = len(processed_partitions)
    assert first_run_count == fail_after_count

    # -------------- SECOND RUN (FIXED AGGREGATOR) -------------------
    reset_session_job_state()
    processed_partitions.clear()
    should_fail = False

    # Now use the same aggregator with bug "fixed" - should continue from partial
    chain.agg(
        total=aggregator,
        partition_by="letter",
    ).save("agg_results")

    second_run_count = len(processed_partitions)

    # Verify final results: 3 partitions (A, B, C) with correct sums
    # Column names are total_0 (letter) and total_1 (sum) from the tuple
    result = sorted(
        dc.read_dataset("agg_results", session=test_session).to_list(
            "total_0", "total_1"
        )
    )
    expected = sorted(
        [
            ("A", 3),  # group A: 1 + 2 = 3
            ("B", 7),  # group B: 3 + 4 = 7
            ("C", 11),  # group C: 5 + 6 = 11
        ]
    )

    # Should have exactly 3 outputs (no duplicates)
    assert result == expected

    # Second run should only process the remaining partition(s), not all 3
    assert second_run_count < 3
    assert first_run_count + second_run_count == 3


def test_aggregator_continue_from_partial_same_job(test_session, nums_letters):
    """Retry a partition_by aggregator inside the same job after a partial failure.

    The partial checkpoint is created in job X; when we retry without
    resetting the session job, `job.id` still equals the partial's `job_id`,
    so the partition table is reused directly (no cross-job copy).
    """
    processed_partitions = []
    should_fail = True

    def aggregator(letter, num) -> Iterator[tuple[str, int]]:
        if should_fail and len(processed_partitions) >= 2:
            raise Exception("Simulated failure")
        processed_partitions.append(list(num))
        yield letter[0], sum(num)

    reset_session_job_state()
    chain = dc.read_dataset("nums_letters", session=test_session).settings(batch_size=1)

    with pytest.raises(Exception, match="Simulated failure"):
        chain.agg(total=aggregator, partition_by="letter").save("agg_results")

    first_run_count = len(processed_partitions)
    assert first_run_count == 2

    # Retry in the SAME job — no reset_session_job_state.
    processed_partitions.clear()
    should_fail = False
    chain.agg(total=aggregator, partition_by="letter").save("agg_results")

    second_run_count = len(processed_partitions)
    assert second_run_count < 3
    assert first_run_count + second_run_count == 3

    result = sorted(
        dc.read_dataset("agg_results", session=test_session).to_list(
            "total_0", "total_1"
        )
    )
    assert result == sorted([("A", 3), ("B", 7), ("C", 11)])


def test_aggregator_skip_completed(test_session, nums_letters):
    call_count = []

    def aggregator_func(letter, num) -> Iterator[tuple[str, int]]:
        """Aggregator that sums numbers by partition."""
        call_count.append(letter[0])
        nums_list = list(num)
        yield letter[0], sum(nums_list)

    # -------------- FIRST RUN (COMPLETE) -------------------
    reset_session_job_state()

    chain = dc.read_dataset("nums_letters", session=test_session)
    chain.agg(
        total=aggregator_func,
        partition_by="letter",
    ).save("agg_results")

    first_run_count = len(call_count)
    assert first_run_count == 3  # Processed all 3 partitions

    result = sorted(
        dc.read_dataset("agg_results", session=test_session).to_list(
            "total_0", "total_1"
        )
    )
    expected = [("A", 3), ("B", 7), ("C", 11)]
    assert result == expected

    # -------------- SECOND RUN (SKIP) -------------------
    reset_session_job_state()
    call_count.clear()

    # Run same aggregator again - should skip execution
    chain.agg(
        total=aggregator_func,
        partition_by="letter",
    ).save("agg_results")

    assert len(call_count) == 0

    # Verify results are still correct
    result = sorted(
        dc.read_dataset("agg_results", session=test_session).to_list(
            "total_0", "total_1"
        )
    )
    assert result == expected


def test_aggregator_fallback_when_partition_table_missing(test_session):
    """If partition table is missing on continuation, fall back to run from scratch."""
    processed = []

    dc.read_values(
        num=[1, 2, 3, 4, 5, 6],
        letter=["A", "A", "B", "B", "C", "C"],
        session=test_session,
    ).save("nums_letters")

    def buggy_agg(letter, num) -> Iterator[tuple[str, int]]:
        nums_list = list(num)
        processed.append(nums_list)
        if any(n > 4 for n in nums_list):
            raise Exception("Simulated failure")
        yield letter[0], sum(nums_list)

    chain = dc.read_dataset("nums_letters", session=test_session).settings(batch_size=1)

    # -------------- FIRST RUN (crashes) -------------------
    reset_session_job_state()
    with pytest.raises(Exception, match="Simulated failure"):
        chain.agg(
            total=buggy_agg,
            partition_by="letter",
        ).save("agg_results")

    first_job_id = test_session.get_or_create_job().id

    # Delete partition tables to simulate them being cleaned up
    warehouse_db = test_session.catalog.warehouse.db
    for table_name in warehouse_db.list_tables(f"udf_{first_job_id}%"):
        if "_partition" in table_name:
            warehouse_db.drop_table(warehouse_db.get_table(table_name), if_exists=True)

    # -------------- SECOND RUN (should fall back to from scratch) -------------------
    reset_session_job_state()
    processed.clear()

    def buggy_agg(letter, num) -> Iterator[tuple[str, int]]:
        nums_list = list(num)
        processed.append(nums_list)
        yield letter[0], sum(nums_list)

    chain.agg(
        total=buggy_agg,
        partition_by="letter",
    ).save("agg_results")

    # All partitions should be processed (fell back to from scratch)
    assert len(processed) == 3

    result = sorted(
        dc.read_dataset("agg_results", session=test_session).to_list(
            "total_0", "total_1"
        )
    )
    assert result == [("A", 3), ("B", 7), ("C", 11)]


def test_aggregator_without_partition_by_runs_from_scratch(test_session):
    """Non-partitioned aggregator runs from scratch on re-run, not continue."""
    processed = []

    dc.read_values(num=[1, 2, 3, 4, 5, 6], session=test_session).save("nums")

    def buggy_agg(num) -> Iterator[int]:
        processed.extend(num)
        if any(n > 3 for n in num):
            raise Exception("Simulated failure")
        yield sum(num)

    # -------------- FIRST RUN (crashes) -------------------
    reset_session_job_state()
    with pytest.raises(Exception, match="Simulated failure"):
        dc.read_dataset("nums", session=test_session).agg(
            total=buggy_agg,
            output=int,
        ).save("agg_results")

    assert len(processed) > 0

    # -------------- SECOND RUN (fixed) -------------------
    reset_session_job_state()
    processed.clear()

    def buggy_agg(num) -> Iterator[int]:
        processed.extend(num)
        yield sum(num)

    dc.read_dataset("nums", session=test_session).agg(
        total=buggy_agg,
        output=int,
    ).save("agg_results")

    # All inputs processed — no partial continuation for non-partitioned aggregators
    assert sorted(processed) == [1, 2, 3, 4, 5, 6]

    result = dc.read_dataset("agg_results", session=test_session).to_list("total")
    assert result == [(21,)]


@skip_if_not_sqlite
def test_continue_udf_preserves_sys_ids(test_session_tmpfile):
    """sys__id must be preserved when copying partial output table on continuation.

    If sys__id is stripped during copy, fresh sequential IDs are generated that
    don't match the input table's IDs, causing wrong result-to-input pairings
    in the join performed by create_result_query.
    """
    test_session = test_session_tmpfile
    processed = []

    dc.read_values(num=[1, 2, 3, 4, 5, 6], session=test_session).save("nums")

    def process_buggy(num) -> int:
        if len(processed) >= 3:
            raise Exception("Simulated failure")
        processed.append(num)
        return num * 10

    chain = dc.read_dataset("nums", session=test_session).settings(batch_size=1)

    # -------------- FIRST RUN (crashes after 3 rows) -------------------
    reset_session_job_state()
    with pytest.raises(Exception, match="Simulated failure"):
        chain.map(result=process_buggy, output=int).save("results")

    assert len(processed) == 3

    # Scramble sys__id to non-sequential values so that the test is deterministic.
    # If sys__id is stripped during copy, fresh IDs (1,2,3) won't match the input
    # table's scrambled IDs (100,200,300,400,500,600), causing continuation to
    # reprocess all rows instead of skipping processed ones.
    job = test_session.get_or_create_job()
    warehouse_db = test_session.catalog.warehouse.db
    all_tables = list(
        set(
            warehouse_db.list_tables(f"udf_{job.id}%")
            + warehouse_db.list_tables(f"udf_{job.run_group_id}%")
        )
    )
    for table_name in all_tables:
        if "_input" in table_name or "_output_partial" in table_name:
            tbl = warehouse_db.get_table(table_name)
            for i in range(1, 7):
                warehouse_db.execute(
                    tbl.update().where(tbl.c.sys__id == i).values(sys__id=i * 100)
                )

    # -------------- SECOND RUN (fixed UDF, same function name) -------------------
    reset_session_job_state()
    processed.clear()

    def process_buggy(num) -> int:
        processed.append(num)
        return num * 10

    chain.map(result=process_buggy, output=int).save("results")

    result = dc.read_dataset("results", session=test_session).to_list("result")
    assert sorted(result) == [(10,), (20,), (30,), (40,), (50,), (60,)]
    # Continuation should skip already-processed rows (3 out of 6)
    assert len(processed) < 6, (
        f"Expected continuation to skip rows, but all {len(processed)} were processed"
    )


def test_udf_continue_after_group_by(test_session_tmpfile):
    """UDF continuation works correctly when group_by precedes the UDF.

    group_by produces a query with GROUP BY clause that has no sys__id.
    The UDF input table gets fresh IDs. On continuation, the partial output
    table's sys__id must still match the input table's IDs.
    """
    test_session = test_session_tmpfile
    processed = []

    dc.read_values(
        category=["a", "a", "b", "b", "c", "c"],
        value=[1, 2, 3, 4, 5, 6],
        session=test_session,
    ).save("data")

    def process_buggy(total) -> int:
        if len(processed) >= 2:
            raise Exception("Simulated failure")
        processed.append(total)
        return total * 10

    chain = (
        dc.read_dataset("data", session=test_session)
        .group_by(total=func.sum("value"), partition_by="category")
        .settings(batch_size=1)
    )

    # -------------- FIRST RUN (crashes after 2 rows) -------------------
    reset_session_job_state()
    with pytest.raises(Exception, match="Simulated failure"):
        chain.map(result=process_buggy, output=int).save("results")

    assert len(processed) == 2

    # -------------- SECOND RUN (fixed UDF) -------------------
    reset_session_job_state()
    processed.clear()

    def process_buggy(total) -> int:
        processed.append(total)
        return total * 10

    chain.map(result=process_buggy, output=int).save("results")

    result = dc.read_dataset("results", session=test_session).to_list("result")
    # group a: 1+2=3 -> 30, group b: 3+4=7 -> 70, group c: 5+6=11 -> 110
    assert sorted(result) == [(30,), (70,), (110,)]
