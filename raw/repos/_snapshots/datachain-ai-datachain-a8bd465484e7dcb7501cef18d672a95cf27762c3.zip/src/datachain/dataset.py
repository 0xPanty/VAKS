import builtins
import re
from dataclasses import dataclass, field, fields
from datetime import datetime
from typing import (
    Any,
    NewType,
    TypeVar,
)
from uuid import uuid4

from packaging.specifiers import SpecifierSet
from packaging.version import Version

from datachain import json, semver
from datachain.error import (
    DatasetStateNotLoadedError,
    DatasetVersionNotFoundError,
    InvalidDatasetNameError,
)
from datachain.namespace import Namespace
from datachain.project import Project
from datachain.sql.types import NAME_TYPES_MAPPING, SQLType

T = TypeVar("T", bound="DatasetRecord")
LT = TypeVar("LT", bound="DatasetListRecord")
V = TypeVar("V", bound="DatasetVersion")
LV = TypeVar("LV", bound="DatasetListVersion")
DD = TypeVar("DD", bound="DatasetDependency")

DATASET_PREFIX = "ds://"
QUERY_DATASET_PREFIX = "ds_query_"
LISTING_PREFIX = "lst__"

DEFAULT_DATASET_VERSION = "1.0.0"
DATASET_NAME_RESERVED_CHARS = [".", "@"]
DATASET_NAME_REPLACEMENT_CHAR = "_"


# StorageURI represents a normalized URI to a valid storage location
# (full bucket or absolute local path).
# Valid examples: s3://foo, file:///var/data
# Invalid examples: s3://foo/, s3://foo/bar, file://~
StorageURI = NewType("StorageURI", str)


def parse_dataset_uri(
    uri: str,
) -> tuple[str | None, str | None, str, str | None]:
    """
    Parse a dataset URI of the form:

        ds://[<namespace>.][<project>.]<name>[@v<semver>]

    Returns:
        (namespace, project, name, version)
    """

    if not uri.startswith("ds://"):
        raise ValueError(f"Invalid dataset URI: {uri}")

    body = uri[len("ds://") :]

    # Split off optional @v<version>
    match = re.match(r"^(?P<name>.+?)(?:@v(?P<version>\d+\.\d+\.\d+))?$", body)
    if not match:
        raise ValueError(f"Invalid dataset URI format: {uri}")

    dataset_name = match.group("name")
    version = match.group("version")

    namespace, project, name = parse_dataset_name(dataset_name)

    return namespace, project, name, version


def create_dataset_uri(
    name: str, namespace: str, project: str, version: str | None = None
) -> str:
    """
    Creates a dataset uri based on namespace, project, dataset name and optionally
    version.
    Example:
        Input: dev, clothes, zalando, 3.0.1
        Output: ds//dev.clothes.zalando@v3.0.1
    """
    uri = f"{DATASET_PREFIX}{namespace}.{project}.{name}"
    if version:
        uri += f"@v{version}"

    return uri


def create_dataset_full_name(
    namespace: str, project: str, name: str, version: str
) -> str:
    """
    Creates a full dataset name including namespace, project and version.
    Example:
        Input: dev, clothes, zalando, 3.0.1
        Output: dev.clothes.zalando@3.0.1
    """
    return f"{namespace}.{project}.{name}@{version}"


def parse_dataset_name(name: str) -> tuple[str | None, str | None, str]:
    """Parses dataset name and returns namespace, project and name"""
    if not name:
        raise InvalidDatasetNameError("Name must be defined to parse it")
    split = name.split(".")
    if len(split) > 3:
        raise InvalidDatasetNameError(f"Invalid dataset name {name}")
    name = split[-1]
    project_name = split[-2] if len(split) > 1 else None
    namespace_name = split[-3] if len(split) > 2 else None

    return namespace_name, project_name, name


def parse_dataset_with_version(dataset_input: str) -> tuple[str, str | None]:
    """Parse an optional ``@version`` suffix from a dataset name.

    Supports exact versions (``"1.2.3"``), PEP 440 specifiers
    (``">=1.0.0,<2.0.0"``), and legacy integer versions (``"1"``).
    Returns the bare name and the version string, or ``(dataset_input, None)``
    if no version suffix is present.
    """
    parts = dataset_input.rsplit("@", 1)

    if len(parts) == 2 and parts[0] and parts[1]:
        return parts[0], parts[1]
    return dataset_input, None


def parse_schema(ct: dict[str, Any]) -> dict[str, SQLType | type[SQLType]]:
    """Parse dataset schema from dictionary representation.

    Args:
        ct: Dictionary with column definitions

    Returns:
        Dictionary mapping column names to SQL types

    Raises:
        TypeError: If schema format is invalid
        ValueError: If column type is not defined or not supported
    """
    if not isinstance(ct, dict):
        raise TypeError("Schema definition must be a dictionary")
    res = {}
    for c_name, c_type in ct.items():
        if not isinstance(c_type, dict):
            raise TypeError(f"Schema column '{c_name}' type must be a dictionary")
        if "type" not in c_type:
            raise ValueError(f"Schema column '{c_name}' type is not defined")
        if c_type["type"] not in NAME_TYPES_MAPPING:
            raise ValueError(
                f"Schema column '{c_name}' type '{c_type['type']}' is not supported"
            )
        try:
            res[c_name] = NAME_TYPES_MAPPING[c_type["type"]].from_dict(c_type)  # type: ignore [attr-defined]
        except Exception as e:
            raise ValueError(
                f"Schema column '{c_name}' type '{c_type['type']}' parsing error: {e}"
            ) from e
    return res


class DatasetDependencyType:
    DATASET = "dataset"
    STORAGE = "storage"


@dataclass
class DatasetDependency:
    # TODO put `DatasetRecord` instead of name + version which will
    # simplify codebase in various places
    id: int
    type: str
    namespace: str
    project: str
    name: str
    version: str
    created_at: datetime
    dependencies: list["DatasetDependency | None"]

    def to_dict(self) -> dict[str, Any]:
        return {
            f.name: [
                d.to_dict() if d is not None else None for d in getattr(self, f.name)
            ]
            if f.name == "dependencies"
            else getattr(self, f.name)
            for f in fields(self)
        }

    @property
    def dataset_name(self) -> str:
        """Returns clean dependency dataset name"""
        from datachain.lib.listing import parse_listing_uri

        if self.type == DatasetDependencyType.DATASET:
            return self.name

        list_dataset_name, _, _ = parse_listing_uri(self.name.strip("/"))
        assert list_dataset_name
        return list_dataset_name

    @classmethod
    def parse(
        cls: builtins.type[DD],
        namespace_name: str,
        project_name: str,
        id: int,
        dataset_id: int | None,
        dataset_version_id: int | None,
        dataset_name: str | None,
        dataset_version: str | None,
        dataset_version_created_at: datetime | None,
    ) -> "DatasetDependency | None":
        from datachain.lib.listing import is_listing_dataset

        if not dataset_id:
            return None

        assert dataset_name is not None

        return cls(
            id,
            (
                DatasetDependencyType.STORAGE
                if is_listing_dataset(dataset_name)
                else DatasetDependencyType.DATASET
            ),
            namespace_name,
            project_name,
            dataset_name,
            dataset_version or None,  # type: ignore[arg-type]
            dataset_version_created_at,  # type: ignore[arg-type]
            [],
        )

    @property
    def is_dataset(self) -> bool:
        return self.type == DatasetDependencyType.DATASET

    def __eq__(self, other):
        if not isinstance(other, DatasetDependency):
            return False

        return (
            self.type == other.type
            and self.name == other.name
            and self.version == other.version
        )

    def __hash__(self):
        return hash(f"{self.type}_{self.name}_{self.version}")


class DatasetStatus:
    CREATED = 1
    PENDING = 2
    FAILED = 3
    COMPLETE = 4
    STALE = 6
    REMOVING = 7


@dataclass
class DatasetVersion:
    id: int
    uuid: str
    dataset_id: int
    version: str
    status: int
    feature_schema: dict
    created_at: datetime
    finished_at: datetime | None
    error_message: str
    error_stack: str
    script_output: str
    schema: dict[str, SQLType | type[SQLType]]
    num_objects: int | None
    size: int | None
    # Preview arrives as a raw JSON string from the database because the
    # metastore double-encodes it (json.dumps into a JSON column).  We keep
    # the raw string here and decode lazily in the ``preview`` property so
    # that serialization paths (to_dict / msgpack) can pass it through
    # without an unnecessary decode-then-re-encode round-trip.
    _preview_data: str | list[dict] | None = field(
        default=None, metadata={"alias": "preview"}
    )
    _preview_loaded: bool = field(kw_only=True)
    sources: str = ""
    query_script: str = ""
    job_id: str | None = None
    content_hash: str | None = None

    @classmethod
    def parse(  # noqa: PLR0913
        cls,
        id: int,
        uuid: str,
        dataset_id: int,
        version: str,
        status: int,
        feature_schema: str | None,
        created_at: datetime,
        finished_at: datetime | None,
        error_message: str,
        error_stack: str,
        script_output: str,
        num_objects: int | None,
        size: int | None,
        preview: str | list[dict] | None,
        schema: str | dict[str, SQLType | type[SQLType]],
        sources: str = "",
        query_script: str = "",
        job_id: str | None = None,
        content_hash: str | None = None,
        *,
        preview_loaded: bool = True,
    ):
        if isinstance(schema, str):
            schema_parsed = parse_schema(json.loads(schema) if schema else {})
        else:
            schema_parsed = schema

        return cls(
            id=id,
            uuid=uuid,
            dataset_id=dataset_id,
            version=version,
            status=status,
            feature_schema=json.loads(feature_schema) if feature_schema else {},
            created_at=created_at,
            finished_at=finished_at,
            error_message=error_message,
            error_stack=error_stack,
            script_output=script_output,
            schema=schema_parsed,
            num_objects=num_objects,
            size=size,
            _preview_data=preview,
            sources=sources,
            query_script=query_script,
            job_id=job_id,
            content_hash=content_hash,
            _preview_loaded=preview_loaded,
        )

    @property
    def version_value(self) -> int:
        return semver.value(self.version)

    def __eq__(self, other):
        if not isinstance(other, DatasetVersion):
            return False
        return self.version == other.version and self.dataset_id == other.dataset_id

    def __lt__(self, other):
        if not isinstance(other, DatasetVersion):
            return False
        return self.version_value < other.version_value

    def __hash__(self):
        return hash(f"{self.dataset_id}_{self.version}")

    def is_final_status(self) -> bool:
        return self.status in [
            DatasetStatus.FAILED,
            DatasetStatus.COMPLETE,
            DatasetStatus.STALE,
            DatasetStatus.REMOVING,
        ]

    def update(self, **kwargs):
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)

    @property
    def preview(self) -> list[dict] | None:
        if not self._preview_loaded:
            raise DatasetStateNotLoadedError(
                "Dataset preview was not loaded. Fetch the dataset with "
                "include_preview=True before accessing preview."
            )
        if isinstance(self._preview_data, str):
            self._preview_data = json.loads(self._preview_data)
        return self._preview_data or None  # type: ignore[return-value]

    def to_dict(self) -> dict[str, Any]:
        result = {}
        for f in fields(self):
            value = object.__getattribute__(self, f.name)
            result[f.metadata.get("alias", f.name)] = value
        return result

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "DatasetVersion":
        if "_preview_data" in d:
            raise ValueError(
                "Serialized dataset version must use 'preview', not '_preview_data'"
            )
        kwargs = {
            f.name: d[f.name]
            for f in fields(cls)
            if f.name in d and f.name != "_preview_data"
        }
        kwargs["_preview_data"] = d["preview"]
        return cls(**kwargs)


@dataclass
class DatasetListVersion:
    id: int
    uuid: str
    dataset_id: int
    version: str
    status: int
    created_at: datetime
    finished_at: datetime | None
    error_message: str
    error_stack: str
    num_objects: int | None
    size: int | None
    query_script: str = ""
    job_id: str | None = None

    @classmethod
    def parse(
        cls,
        id: int,
        uuid: str,
        dataset_id: int,
        version: str,
        status: int,
        created_at: datetime,
        finished_at: datetime | None,
        error_message: str,
        error_stack: str,
        num_objects: int | None,
        size: int | None,
        query_script: str = "",
        job_id: str | None = None,
        **kwargs,
    ):
        return cls(
            id,
            uuid,
            dataset_id,
            version,
            status,
            created_at,
            finished_at,
            error_message,
            error_stack,
            num_objects,
            size,
            query_script,
            job_id,
        )

    def to_dict(self) -> dict[str, Any]:
        return {f.name: getattr(self, f.name) for f in fields(self)}

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "DatasetListVersion":
        kwargs = {f.name: d[f.name] for f in fields(cls) if f.name in d}
        return cls(**kwargs)

    def __hash__(self):
        return hash(f"{self.dataset_id}_{self.version}")

    @property
    def version_value(self) -> int:
        return semver.value(self.version)


@dataclass
class DatasetRecord:
    id: int
    name: str
    project: Project
    description: str | None
    attrs: list[str]
    schema: dict[str, SQLType | type[SQLType]]
    feature_schema: dict
    uuid: str = field(kw_only=True, default_factory=lambda: str(uuid4()))
    _versions: list[DatasetVersion] = field(
        default_factory=list, metadata={"alias": "versions"}
    )
    status: int = DatasetStatus.CREATED
    created_at: datetime | None = None
    finished_at: datetime | None = None
    error_message: str = ""
    error_stack: str = ""
    script_output: str = ""
    sources: str = ""
    query_script: str = ""
    _versions_loaded: bool = field(kw_only=True)

    @property
    def versions(self) -> list[DatasetVersion]:
        if not self._versions_loaded:
            raise DatasetStateNotLoadedError(
                "Dataset versions were not loaded. Fetch the dataset with "
                "versions=None or an explicit versions=[...] before accessing versions."
            )
        return self._versions

    @versions.setter
    def versions(self, value: list[DatasetVersion]) -> None:
        self._versions = value
        self._versions_loaded = True

    def __hash__(self):
        return hash(f"{self.id}")

    @staticmethod
    def validate_name(name: str) -> None:
        """Throws exception if name has reserved characters"""
        for c in DATASET_NAME_RESERVED_CHARS:
            if c in name:
                raise InvalidDatasetNameError(
                    f"Character {c} is reserved and not allowed in dataset name"
                )

    @classmethod
    def parse(  # noqa: PLR0913
        cls,
        namespace_id: int,
        namespace_uuid: str,
        namespace_name: str,
        namespace_description: str | None,
        namespace_created_at: datetime,
        project_id: int,
        project_uuid: str,
        project_name: str,
        project_description: str | None,
        project_created_at: datetime,
        project_namespace_id: int,
        dataset_id: int,
        dataset_uuid: str,
        dataset_project_id: int,
        name: str,
        description: str | None,
        attrs: str,
        status: int,
        feature_schema: str | None,
        created_at: datetime,
        finished_at: datetime | None,
        error_message: str,
        error_stack: str,
        script_output: str,
        sources: str,
        query_script: str,
        schema: str,
        version_id: int | None = None,
        version_uuid: str | None = None,
        version_dataset_id: int | None = None,
        version: str | None = None,
        version_status: int | None = None,
        version_feature_schema: str | None = None,
        version_created_at: datetime | None = None,
        version_finished_at: datetime | None = None,
        version_error_message: str | None = None,
        version_error_stack: str | None = None,
        version_script_output: str | None = None,
        version_num_objects: int | None = None,
        version_size: int | None = None,
        version_preview: str | None = None,
        version_sources: str | None = None,
        version_query_script: str | None = None,
        version_schema: str | None = None,
        version_job_id: str | None = None,
        version_content_hash: str | None = None,
        *,
        versions_loaded: bool = True,
        preview_loaded: bool = True,
    ) -> "DatasetRecord":
        attrs_lst: list[str] = json.loads(attrs) if attrs else []
        schema_dct: dict[str, Any] = json.loads(schema) if schema else {}

        namespace = Namespace(
            namespace_id,
            namespace_uuid,
            namespace_name,
            namespace_description,
            namespace_created_at,
        )

        project = Project(
            project_id,
            project_uuid,
            project_name,
            project_description,
            project_created_at,
            namespace,
        )

        if version_id is None:
            # No version columns in the row (lightweight query)
            versions_list: list[DatasetVersion] = []
        else:
            assert version_uuid is not None
            assert version_dataset_id is not None
            assert version is not None
            assert version_status is not None
            assert version_created_at is not None
            assert version_error_message is not None
            assert version_error_stack is not None
            assert version_script_output is not None
            assert version_schema is not None

            dataset_version = DatasetVersion.parse(
                version_id,
                version_uuid,
                version_dataset_id,
                version,
                version_status,
                version_feature_schema,
                version_created_at,
                version_finished_at,
                version_error_message,
                version_error_stack,
                version_script_output,
                version_num_objects,
                version_size,
                version_preview,
                version_schema,
                version_sources or "",
                version_query_script or "",
                version_job_id,
                version_content_hash,
                preview_loaded=preview_loaded,
            )
            versions_list = [dataset_version]

        return cls(
            id=dataset_id,
            uuid=dataset_uuid,
            name=name,
            project=project,
            description=description,
            attrs=attrs_lst,
            schema=parse_schema(schema_dct),  # type: ignore[arg-type]
            feature_schema=json.loads(feature_schema) if feature_schema else {},
            _versions=versions_list,
            status=status,
            created_at=created_at,
            finished_at=finished_at,
            error_message=error_message,
            error_stack=error_stack,
            script_output=script_output,
            sources=sources,
            query_script=query_script,
            _versions_loaded=versions_loaded,
        )

    @property
    def full_name(self) -> str:
        return f"{self.project.namespace.name}.{self.project.name}.{self.name}"

    def get_schema(self, version: str) -> dict[str, SQLType | type[SQLType]]:
        return self.get_version(version).schema if version else self.schema

    def update(self, **kwargs):
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)

    def has_version(self, version: str) -> bool:
        return version in [v.version for v in self.versions]

    def is_valid_next_version(self, version: str) -> bool:
        """
        Checks if a number can be a valid next latest version for dataset.
        The only rule is that it cannot be lower than current latest version
        """
        if not self.versions:
            return True

        return not (
            self.latest_version
            and semver.value(self.latest_version) >= semver.value(version)
        )

    def get_version(self, version: str) -> DatasetVersion:
        if not self.has_version(version):
            raise DatasetVersionNotFoundError(
                f"Dataset {self.name} does not have version {version}"
            )
        return next(v for v in self.versions if v.version == version)

    def get_version_by_uuid(self, uuid: str) -> DatasetVersion:
        try:
            return next(v for v in self.versions if v.uuid == uuid)
        except StopIteration:
            raise DatasetVersionNotFoundError(
                f"Dataset {self.name} does not have version with uuid {uuid}"
            ) from None

    def remove_version(self, version: str) -> None:
        if not self.versions or not self.has_version(version):
            return

        self._versions = [v for v in self.versions if v.version != version]

    def identifier(self, version: str) -> str:
        """
        Get identifier in the form my-dataset@v3.0.1
        """
        if not self.has_version(version):
            raise DatasetVersionNotFoundError(
                f"Dataset {self.name} doesn't have a version {version}"
            )
        return f"{self.name}@v{version}"

    def uri(self, version: str) -> str:
        """
        Dataset uri example: ds://dogs@v3.0.1
        """
        identifier = self.identifier(version)
        return (
            f"{DATASET_PREFIX}{self.project.namespace.name}"
            f".{self.project.name}.{identifier}"
        )

    @property
    def next_version_major(self) -> str:
        """
        Returns the next auto-incremented version if the major part is being bumped.
        """
        if not self.versions:
            return "1.0.0"

        major, _, _ = semver.parse(self.latest_version)
        return semver.create(major + 1, 0, 0)

    @property
    def next_version_minor(self) -> str:
        """
        Returns the next auto-incremented version if the minor part is being bumped.
        """
        if not self.versions:
            return "1.0.0"

        major, minor, _ = semver.parse(self.latest_version)
        return semver.create(major, minor + 1, 0)

    @property
    def next_version_patch(self) -> str:
        """
        Returns the next auto-incremented version if the patch part is being bumped.
        """
        if not self.versions:
            return "1.0.0"

        major, minor, patch = semver.parse(self.latest_version)
        return semver.create(major, minor, patch + 1)

    @property
    def latest_version(self) -> str:
        """Returns latest version of a dataset"""
        if not self.versions:
            raise DatasetVersionNotFoundError("Dataset has no versions")
        return max(self.versions).version

    @property
    def latest_complete_version(self) -> str | None:
        """Returns latest COMPLETE version, or None if there isn't one."""
        complete = [v for v in self.versions if v.status == DatasetStatus.COMPLETE]
        if not complete:
            return None
        return max(complete).version

    def latest_major_version(self, major: int) -> str | None:
        """
        Returns latest specific major version, e.g if dataset has versions:
            - 1.4.1
            - 2.0.1
            - 2.1.1
            - 2.4.0
        and we call `.latest_major_version(2)` it will return: "2.4.0".
        If no major version is find with input value, None will be returned
        """
        versions = [v for v in self.versions if semver.parse(v.version)[0] == major]
        if not versions:
            return None
        return max(versions).version

    def latest_compatible_version(self, version_spec: str) -> str | None:
        """
        Returns the latest version that matches the given version specifier.

        Supports Python version specifiers like:
        - ">=1.0.0,<2.0.0" (compatible release range)
        - "~=1.4.2" (compatible release clause)
        - "==1.2.*" (prefix matching)
        - ">1.0.0" (exclusive ordered comparison)
        - ">=1.0.0" (inclusive ordered comparison)
        - "!=1.3.0" (version exclusion)

        Args:
            version_spec: Version specifier string following PEP 440

        Returns:
            Latest compatible version string, or None if no compatible version found
        """
        spec_set = SpecifierSet(version_spec)

        # Convert dataset versions to packaging.Version objects
        # and filter compatible ones
        compatible_versions = []
        for v in self.versions:
            pkg_version = Version(v.version)
            if spec_set.contains(pkg_version):
                compatible_versions.append(v)

        if not compatible_versions:
            return None

        # Return the latest compatible version
        return max(compatible_versions).version

    def to_dict(self) -> dict[str, Any]:
        result = {}
        for f in fields(self):
            value = object.__getattribute__(self, f.name)
            key = f.metadata.get("alias", f.name)
            if hasattr(value, "to_dict"):
                value = value.to_dict()
            elif isinstance(value, list) and value and hasattr(value[0], "to_dict"):
                value = [v.to_dict() for v in value]
            result[key] = value
        return result

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "DatasetRecord":
        if "_versions" in d:
            raise ValueError(
                "Serialized dataset record must use 'versions', not '_versions'"
            )
        project = Project.from_dict(d["project"])
        versions = [DatasetVersion.from_dict(v) for v in d["versions"]]
        kwargs = {
            f.name: d[f.name]
            for f in fields(cls)
            if f.name in d and f.name not in {"_versions", "project"}
        }
        return cls(**kwargs, _versions=versions, project=project)


@dataclass
class DatasetListRecord:
    id: int
    name: str
    project: Project
    description: str | None
    attrs: list[str]
    versions: list[DatasetListVersion]
    created_at: datetime | None = None
    uuid: str = field(kw_only=True)

    @classmethod
    def parse(  # noqa: PLR0913
        cls,
        namespace_id: int,
        namespace_uuid: str,
        namespace_name: str,
        namespace_description: str | None,
        namespace_created_at: datetime,
        project_id: int,
        project_uuid: str,
        project_name: str,
        project_description: str | None,
        project_created_at: datetime,
        project_namespace_id: int,
        dataset_id: int,
        dataset_uuid: str,
        name: str,
        description: str | None,
        attrs: str,
        created_at: datetime,
        version_id: int,
        version_uuid: str,
        version_dataset_id: int,
        version: str,
        version_status: int,
        version_created_at: datetime,
        version_finished_at: datetime | None,
        version_error_message: str,
        version_error_stack: str,
        version_num_objects: int | None,
        version_size: int | None,
        version_query_script: str | None,
        version_job_id: str | None = None,
    ) -> "DatasetListRecord":
        attrs_lst: list[str] = json.loads(attrs) if attrs else []

        namespace = Namespace(
            namespace_id,
            namespace_uuid,
            namespace_name,
            namespace_description,
            namespace_created_at,
        )

        project = Project(
            project_id,
            project_uuid,
            project_name,
            project_description,
            project_created_at,
            namespace,
        )

        dataset_version = DatasetListVersion.parse(
            version_id,
            version_uuid,
            version_dataset_id,
            version,
            version_status,
            version_created_at,
            version_finished_at,
            version_error_message,
            version_error_stack,
            version_num_objects,
            version_size,
            version_query_script,  # type: ignore[arg-type]
            version_job_id,
        )

        return cls(
            id=dataset_id,
            uuid=dataset_uuid,
            name=name,
            project=project,
            description=description,
            attrs=attrs_lst,
            versions=[dataset_version],
            created_at=created_at,
        )

    @property
    def full_name(self) -> str:
        return f"{self.project.namespace.name}.{self.project.name}.{self.name}"

    def latest_version(self) -> DatasetListVersion:
        return max(self.versions, key=lambda v: v.version_value)

    @property
    def is_bucket_listing(self) -> bool:
        """
        For bucket listing we implicitly create underlying dataset to hold data. This
        method is checking if this is one of those datasets.
        """
        from datachain.client import Client

        # TODO refactor and maybe remove method in
        # https://github.com/datachain-ai/datachain/issues/318
        return Client.is_data_source_uri(self.name) or self.name.startswith(
            LISTING_PREFIX
        )

    def has_version_with_uuid(self, uuid: str) -> bool:
        return any(v.uuid == uuid for v in self.versions)

    def to_dict(self) -> dict[str, Any]:
        result = {}
        for f in fields(self):
            value = getattr(self, f.name)
            if hasattr(value, "to_dict"):
                value = value.to_dict()
            elif isinstance(value, list) and value and hasattr(value[0], "to_dict"):
                value = [v.to_dict() for v in value]
            result[f.name] = value
        return result

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "DatasetListRecord":
        project = Project.from_dict(d["project"])
        versions = [DatasetListVersion.from_dict(v) for v in d["versions"]]
        kwargs = {
            f.name: d[f.name]
            for f in fields(cls)
            if f.name in d and f.name not in {"project", "versions"}
        }
        kwargs["versions"] = versions
        kwargs["project"] = project
        return cls(**kwargs)


class RowDict(dict):
    pass
