import errno
import hashlib
import io
import logging
import os
import posixpath
import re
from abc import ABC, abstractmethod
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import datetime
from functools import partial
from io import BytesIO
from pathlib import Path, PurePosixPath
from typing import TYPE_CHECKING, Any, ClassVar, Literal
from urllib.parse import urlparse

from fsspec.callbacks import DEFAULT_CALLBACK, Callback
from fsspec.utils import stringify_path
from pydantic import Field, field_validator, model_validator

from datachain import json
from datachain.client.fileslice import FileSlice
from datachain.fs.utils import path_to_fsspec_uri
from datachain.lib.data_model import DataModel
from datachain.lib.utils import DataChainError, rebase_path
from datachain.nodes_thread_pool import NodesThreadPool
from datachain.sql.types import JSON, Boolean, DateTime, Int, String
from datachain.utils import TIME_ZERO

if TYPE_CHECKING:
    from numpy import ndarray
    from typing_extensions import Self

    from datachain.catalog import Catalog
    from datachain.client.fsspec import Client
    from datachain.dataset import RowDict
    from datachain.query.session import Session

sha256 = partial(hashlib.sha256, usedforsecurity=False)

logger = logging.getLogger("datachain")

_SOURCE_SCHEME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9+.-]*://")

# how to create file path when exporting
ExportPlacement = Literal["filename", "etag", "fullpath", "checksum", "filepath"]

FileType = Literal["binary", "text", "image", "video", "audio"]
EXPORT_FILES_MAX_THREADS = 5


class FileExporter(NodesThreadPool):
    """Class that does file exporting concurrently with thread pool"""

    def __init__(
        self,
        output: str | os.PathLike[str],
        placement: ExportPlacement,
        use_cache: bool,
        link_type: Literal["copy", "symlink"],
        max_threads: int = EXPORT_FILES_MAX_THREADS,
        client_config: dict | None = None,
    ):
        super().__init__(max_threads)
        self.output = output
        self.placement = placement
        self.use_cache = use_cache
        self.link_type = link_type
        self.client_config = client_config

    def done_task(self, done):
        for task in done:
            task.result()

    def do_task(self, file: "File"):
        file.export(
            self.output,
            self.placement,
            self.use_cache,
            link_type=self.link_type,
            client_config=self.client_config,
        )
        self.increase_counter(1)


class VFileError(DataChainError):
    def __init__(self, message: str, source: str, path: str, vtype: str = ""):
        self.message = message
        self.source = source
        self.path = path
        self.vtype = vtype

        type_ = f" of vtype '{vtype}'" if vtype else ""
        super().__init__(f"Error in v-file '{source}/{path}'{type_}: {message}")

    def __reduce__(self):
        return self.__class__, (self.message, self.source, self.path, self.vtype)


class FileError(DataChainError):
    def __init__(self, message: str, source: str, path: str):
        self.message = message
        self.source = source
        self.path = path
        super().__init__(f"Error in file '{source}/{path}': {message}")

    def __reduce__(self):
        return self.__class__, (self.message, self.source, self.path)


class VFile(ABC):
    @classmethod
    @abstractmethod
    def get_vtype(cls) -> str:
        pass

    @classmethod
    @abstractmethod
    def open(cls, file: "File", location: list[dict]):
        pass


class TarVFile(VFile):
    """Virtual file model for files extracted from tar archives."""

    @classmethod
    def get_vtype(cls) -> str:
        return "tar"

    @classmethod
    def open(cls, file: "File", location: list[dict]):
        """Stream file from tar archive based on location in archive.

        Reads always consult the cache (hit → local, miss → remote stream);
        ``_caching_enabled`` only governs whether a miss is also persisted.
        """
        tar_file = cls.parent(file, location)

        loc = location[0]

        if (offset := loc.get("offset", None)) is None:
            raise VFileError("'offset' is not specified", file.source, file.path)

        if (size := loc.get("size", None)) is None:
            raise VFileError("'size' is not specified", file.source, file.path)

        client = file._catalog.get_client(tar_file.source)
        fd = client.open_object(tar_file, use_cache=True)
        return FileSlice(fd, offset, size, file.name)

    @classmethod
    def parent(cls, file: "File", location: list[dict]) -> "File":
        if len(location) > 1:
            raise VFileError(
                "multiple 'location's are not supported yet", file.source, file.path
            )

        loc = location[0]

        if (parent := loc.get("parent", None)) is None:
            raise VFileError("'parent' is not specified", file.source, file.path)

        tar_file = File(**parent)
        tar_file._set_stream(file._catalog)

        return tar_file


class VFileRegistry:
    _vtype_readers: ClassVar[dict[str, type["VFile"]]] = {"tar": TarVFile}

    @classmethod
    def register(cls, reader: type["VFile"]):
        cls._vtype_readers[reader.get_vtype()] = reader

    @classmethod
    def _get_reader(cls, file: "File", location: list[dict]):
        if len(location) == 0:
            raise VFileError(
                "'location' must not be list of JSONs", file.source, file.path
            )

        if not (vtype := location[0].get("vtype", "")):
            raise VFileError("vtype is not specified", file.source, file.path)

        reader = cls._vtype_readers.get(vtype, None)
        if not reader:
            raise VFileError(
                "reader not registered", file.source, file.path, vtype=vtype
            )

        return reader

    @classmethod
    def open(cls, file: "File", location: list[dict]):
        reader = cls._get_reader(file, location)
        return reader.open(file, location)

    @classmethod
    def parent(cls, file: "File", location: list[dict]) -> "File":
        reader = cls._get_reader(file, location)
        return reader.parent(file, location)


class File(DataModel):
    """
    `DataModel` for reading binary files.

    Attributes:
        source (str): The source of the file (e.g., 's3://bucket-name/').
        path (str): The path to the file (e.g., 'path/to/file.txt').
        size (int): The size of the file in bytes. Defaults to 0.
        version (str): The version of the file. Defaults to an empty string.
        etag (str): The ETag of the file. Defaults to an empty string.
        is_latest (bool): Whether the file is the latest version. Defaults to `True`.
        last_modified (datetime): The last modified timestamp of the file.
            Defaults to Unix epoch (`1970-01-01T00:00:00`).
        location (dict | list[dict], optional): The location of the file.
            Defaults to `None`.
    """

    source: str = Field(default="")
    path: str
    size: int = Field(default=0)
    version: str = Field(default="")
    etag: str = Field(default="")
    is_latest: bool = Field(default=True)
    last_modified: datetime = Field(default=TIME_ZERO)
    location: dict | list[dict] | None = Field(default=None)

    _datachain_column_types: ClassVar[dict[str, Any]] = {
        "source": String,
        "path": String,
        "size": Int,
        "version": String,
        "etag": String,
        "is_latest": Boolean,
        "last_modified": DateTime,
        "location": JSON,
    }
    _hidden_fields: ClassVar[list[str]] = [
        "source",
        "version",
        "etag",
        "is_latest",
        "last_modified",
        "location",
    ]

    _unique_id_keys: ClassVar[list[str]] = [
        "source",
        "path",
        "size",
        "etag",
        "version",
        "is_latest",
        "location",
        "last_modified",
    ]

    # Allowed kwargs we forward to TextIOWrapper
    _TEXT_WRAPPER_ALLOWED: ClassVar[tuple[str, ...]] = (
        "encoding",
        "errors",
        "newline",
        "line_buffering",
        "write_through",
    )

    @staticmethod
    def _validate_dict(
        v: str | dict | list[dict] | None,
    ) -> str | dict | list[dict] | None:
        if v is None or v == "":
            return None
        if isinstance(v, str):
            try:
                return json.loads(v)
            except Exception as e:  # noqa: BLE001
                raise ValueError(
                    f"Unable to convert string '{v}' to dict for File feature: {e}"
                ) from None
        return v

    # Workaround for empty JSONs converted to empty strings in some DBs.
    @field_validator("location", mode="before")
    @classmethod
    def validate_location(cls, v):
        return File._validate_dict(v)

    @model_validator(mode="after")
    def _normalize_path(self) -> "File":
        # On Windows, local paths may contain backslash separators from
        # os.path.join / Path objects. Normalize them to forward slashes so
        # PurePosixPath-based helpers (.name, .parent, …) work correctly.
        # Cloud object keys are left untouched - a literal backslash is a
        # valid character in S3/GCS keys and must not be silently replaced.
        if (
            os.name == "nt"
            and "\\" in self.path
            and (not self.source or self.source.startswith("file://"))
        ):
            self.path = self.path.replace("\\", "/")
        return self

    @field_validator("source")
    @classmethod
    def validate_source(cls, source: str) -> str:
        # Allow empty source for intermediate/placeholder objects, but when set
        # require an explicit scheme to avoid ambiguous handling.
        if source and not _SOURCE_SCHEME_RE.match(source):
            raise ValueError(
                "File.source must start with a URI scheme (e.g. file://, s3://), "
                f"got: {source!r}"
            )
        return source

    def model_dump_custom(self):
        res = self.model_dump()
        res["last_modified"] = str(res["last_modified"])
        return res

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._catalog = None
        self._caching_enabled: bool = False
        self._download_cb: Callback = DEFAULT_CALLBACK
        self._fs_path_cache: tuple[str, str, str] | None = None

    def __getstate__(self):
        state = super().__getstate__()
        # Exclude _catalog from pickling - it contains SQLAlchemy engine and other
        # non-picklable objects. The catalog will be re-set by _set_stream() on the
        # worker side when needed.
        state["__dict__"] = state["__dict__"].copy()
        state["__dict__"]["_catalog"] = None
        return state

    def as_text_file(self) -> "TextFile":
        """Convert the file to a `TextFile` object."""
        if isinstance(self, TextFile):
            return self
        file = TextFile(**self.model_dump())
        file._set_stream(self._catalog, caching_enabled=self._caching_enabled)
        return file

    def as_image_file(self) -> "ImageFile":
        """Convert the file to a `ImageFile` object."""
        if isinstance(self, ImageFile):
            return self
        file = ImageFile(**self.model_dump())
        file._set_stream(self._catalog, caching_enabled=self._caching_enabled)
        return file

    def as_video_file(self) -> "VideoFile":
        """Convert the file to a `VideoFile` object."""
        if isinstance(self, VideoFile):
            return self
        file = VideoFile(**self.model_dump())
        file._set_stream(self._catalog, caching_enabled=self._caching_enabled)
        return file

    def as_audio_file(self) -> "AudioFile":
        """Convert the file to a `AudioFile` object."""
        if isinstance(self, AudioFile):
            return self
        file = AudioFile(**self.model_dump())
        file._set_stream(self._catalog, caching_enabled=self._caching_enabled)
        return file

    @classmethod
    def upload(
        cls,
        data: bytes,
        path: str | os.PathLike[str],
        catalog: "Catalog | None" = None,
    ) -> "Self":
        """Upload bytes to a storage path and return a File pointing to it.

        Args:
            data: The raw bytes to upload.
            path: Destination path (local or remote, e.g. ``s3://bucket/file.txt``).
            catalog: Optional catalog instance. If None, the current session
                catalog is used.

        Returns:
            File: A new File object with metadata populated from the upload.

        Example:
            ```py
            file = File.upload(b"hello world", "s3://bucket/hello.txt")
            ```

        Note:
            To write data as a stream, use `File.at` with `open` instead:
            ```py
            file = File.at("s3://bucket/output.txt")
            with file.open("wb") as f:
                f.write(b"hello world")
            ```
        """
        if catalog is None:
            from datachain.query.session import Session

            catalog = Session.get().catalog
        from datachain.client.fsspec import Client

        path_str = stringify_path(path)

        client_cls = Client.get_implementation(path_str)
        source, rel_path = client_cls.split_url(path_str)

        client = catalog.get_client(client_cls.storage_uri(source))
        file = client.upload(data, rel_path)
        if not isinstance(file, cls):
            file = cls(**file.model_dump())
        file._set_stream(catalog)
        return file

    @classmethod
    def at(
        cls, uri: str | os.PathLike[str], session: "Session | None" = None
    ) -> "Self":
        """Construct a File from a full URI in one call.

        Args:
            uri: Full URI or path to the file
                (e.g. ``s3://bucket/path/to/file.png`` or ``/local/path``).
            session: Optional session instance. If None, the current session is used.

        Returns:
            File: A new File object pointing to the given URI.

        Example:
            ```py
            file = File.at("s3://bucket/path/to/output.png")
            with file.open("wb") as f: ...
            ```
        """
        from datachain.client.fsspec import Client
        from datachain.query.session import Session

        if session is None:
            session = Session.get()
        catalog = session.catalog
        uri_str = stringify_path(uri)
        if uri_str.endswith(("/", os.sep)):
            raise ValueError(
                f"File.at directory URL/path given (trailing slash), got: {uri_str}"
            )
        client_cls = Client.get_implementation(uri_str)
        source, rel_path = client_cls.split_url(uri_str)
        source_uri = client_cls.storage_uri(source)
        file = cls(source=source_uri, path=rel_path)
        file._set_stream(catalog)
        return file

    @classmethod
    def _from_row(cls, row: "RowDict") -> "Self":
        return cls(**{key: row[key] for key in cls._datachain_column_types})

    @property
    def name(self) -> str:
        """The file name extracted from the path.

        Example:
            ```py
            file = File(source="s3://bucket", path="data/subdir/image.jpg")
            file.name  # 'image.jpg'
            ```
        """
        return PurePosixPath(self.path).name

    @property
    def parent(self) -> str:
        """The parent directory of the file, extracted from the path.

        Example:
            ```py
            file = File(source="s3://bucket", path="data/subdir/image.jpg")
            file.parent  # 'data/subdir'
            ```
        """
        return str(PurePosixPath(self.path).parent)

    @contextmanager
    def open(
        self,
        mode: str = "rb",
        *,
        client_config: dict[str, Any] | None = None,
        **open_kwargs,
    ) -> Iterator[Any]:
        """Open the file and return a file-like object.

        Supports both read ("rb", "r") and write modes (e.g. "wb", "w", "ab").
        When opened in a write mode, metadata is refreshed after closing.

        Reads always consult the cache (hit → local, miss → remote stream);
        ``_caching_enabled`` only governs whether a miss is also persisted.
        """
        writing = any(ch in mode for ch in "wax+")
        if self.location and writing:
            raise VFileError(
                "Writing to virtual file is not supported",
                self.source,
                self.path,
            )

        if self._catalog is None:
            raise RuntimeError("Cannot open file: catalog is not set")

        base_cfg = getattr(self._catalog, "client_config", {}) or {}
        merged_cfg = {**base_cfg, **(client_config or {})}
        client: Client = self._catalog.get_client(self.source, **merged_cfg)

        if not writing:
            if self.location:
                with VFileRegistry.open(self, self.location) as f:  # type: ignore[arg-type]
                    with self._wrap_text(f, mode, open_kwargs=open_kwargs) as wrapped:
                        yield wrapped
                return
            if self._caching_enabled:
                self.ensure_cached()
            with client.open_object(self, use_cache=True, cb=self._download_cb) as f:
                with self._wrap_text(f, mode, open_kwargs=open_kwargs) as wrapped:
                    yield wrapped
            return

        # write path
        full_path = self.get_fs_path()
        fs_mode = mode if "b" in mode else f"{mode}b"
        binary_kwargs = {
            k: v for k, v in open_kwargs.items() if k not in self._TEXT_WRAPPER_ALLOWED
        }
        with client.fs.open(full_path, fs_mode, **binary_kwargs) as raw_handle:
            with self._wrap_text(
                raw_handle,
                mode,
                open_kwargs=open_kwargs,
            ) as wrapped:
                yield wrapped

        version_hint = self._extract_write_version(raw_handle)

        # refresh metadata pinned to the version that was just written
        refreshed = client.get_file_info(self.path, version_id=version_hint)
        for k, v in refreshed.model_dump().items():
            setattr(self, k, v)

    @contextmanager
    def _wrap_text(
        self,
        f: Any,
        mode: str,
        *,
        open_kwargs: dict[str, Any] | None = None,
    ) -> Iterator[Any]:
        """Yield a stream, optionally wrapped for text, with correct close ordering."""
        if "b" in mode or isinstance(f, io.TextIOBase):
            yield f
            return

        text_kwargs = {
            k: v
            for k, v in (open_kwargs or {}).items()
            if k in self._TEXT_WRAPPER_ALLOWED
        }
        wrapper = io.TextIOWrapper(f, **text_kwargs)
        try:
            yield wrapper
        finally:
            wrapper.flush()
            wrapper.detach()

    def _extract_write_version(self, handle: Any) -> str | None:
        """Best-effort extraction of object version after a write.

        S3 (s3fs) and Azure (adlfs) populate version_id on the handle.
        GCS (gcsfs>=2026.2.0) populates generation. Azure and GCS require
        upstream fixes to be released.
        """
        for attr in ("version_id", "generation"):
            if value := getattr(handle, attr, None):
                return value
        return None

    def read_bytes(self, length: int = -1):
        """Returns file contents as bytes."""
        with self.open(mode="rb") as stream:
            return stream.read(length)

    def read_text(self, **open_kwargs):
        """Return file contents decoded as text.

        **open_kwargs : Any
            Extra keyword arguments forwarded to ``open(mode="r", ...)``
            (e.g. ``encoding="utf-8"``, ``errors="ignore"``)
        """
        with self.open(mode="r", **open_kwargs) as stream:
            return stream.read()

    def read(self, length: int = -1):
        """Returns file contents."""
        return self.read_bytes(length)

    def save(self, destination: str, client_config: dict | None = None) -> "File":
        """Write file contents to *destination*.

        Args:
            destination: Target path or URI.  Accepts a local OS path, a
                cloud URI (``s3://…``, ``gs://…``, ``az://…``), or an
                unencoded ``file://`` URI as produced by
                :func:`~datachain.fs.utils.path_to_fsspec_uri`.
                Do **not** pass ``Path.as_uri()`` output — that produces
                RFC percent-encoded URIs (e.g. ``file:///my%20dir``) which
                fsspec does not decode, causing ``FileNotFoundError`` for
                paths containing spaces, ``#``, or ``%``.
            client_config: Optional extra kwargs forwarded to the storage
                client (e.g. credentials, endpoint URL).

        Returns:
            A ``File`` representing the newly written destination, with
            ``version`` populated on versioned backends.

        Example:
            ```py
            file.save("/local/output/result.bin")
            file.save("s3://my-bucket/output/result.bin")
            file.save("~/output/result.bin")
            ```
        """
        if self._catalog is None:
            raise RuntimeError("Cannot save file: catalog is not set")

        destination = stringify_path(destination)
        client, rel_path = self._resolve_destination(destination, client_config)
        with self.open(mode="rb") as src:
            result = client.upload(src, rel_path)
        result._set_stream(self._catalog)
        return result

    def _resolve_destination(
        self, destination: str, client_config: dict | None = None
    ) -> "tuple[Client, str]":
        """Return (client rooted at the storage, rel_path) for *destination*."""
        from datachain.client.fsspec import Client as FSClient

        uri = path_to_fsspec_uri(destination)
        client_cls = FSClient.get_implementation(uri)
        storage, rel_path = client_cls.split_url(uri)
        client = self._catalog.get_client(  # type: ignore[union-attr]
            client_cls.storage_uri(storage), **(client_config or {})
        )
        return client, rel_path

    def _symlink_to(self, destination: str) -> None:
        if self.location:
            raise OSError(errno.ENOTSUP, "Symlinking virtual file is not supported")

        if self._caching_enabled:
            self.ensure_cached()
            source = self.get_local_path()
            assert source, "File was not cached"
        elif self.source.startswith("file://"):
            source = self.get_fs_path()
        else:
            raise OSError(errno.EXDEV, "can't link across filesystems")

        return os.symlink(source, destination)

    def export(
        self,
        output: str | os.PathLike[str],
        placement: ExportPlacement = "fullpath",
        use_cache: bool = True,
        link_type: Literal["copy", "symlink"] = "copy",
        client_config: dict | None = None,
    ) -> None:
        """Copy or link this file into an output directory.

        Args:
            output: Destination directory.  Accepts a local OS path, a cloud
                prefix fsspec URI (``s3://…``, ``gs://…``, ``az://…``).
            placement: How to build the path under *output*:

                - ``"fullpath"`` (default) — ``output/bucket/dir/file.txt``
                - ``"filepath"`` — ``output/dir/file.txt``
                - ``"filename"`` — ``output/file.txt``
                - ``"etag"`` — ``output/<etag>.txt``
            use_cache: If True, download to local cache first.  Also
                required for symlinking remote files.
            link_type: ``"copy"`` (default) or ``"symlink"``.
                Symlink falls back to copy for virtual files and for
                remote files when *use_cache* is False.
            client_config: Extra kwargs forwarded to the storage client.

        Example:
            ```py
            # flat export by filename
            f.export("./export", placement="filename")

            # export to a cloud prefix
            f.export("s3://output-bucket/results", placement="filepath")

            # pass storage credentials via client_config
            f.export("s3://bucket/out", client_config={"aws_access_key_id": "…"})

            # symlink from local cache (avoids re-downloading)
            f.export("./local_out", use_cache=True, link_type="symlink")
            ```
        """
        if self._catalog is None:
            raise RuntimeError("Cannot export file: catalog is not set")

        self._caching_enabled = use_cache

        suffix = self._get_destination_suffix(placement)
        output_str = stringify_path(output)
        client = self._catalog.get_client(output_str, **(client_config or {}))

        # Normalization and traversal safety: for local exports, resolve to absolute
        # and validate the suffix. Cloud exports skip this — the cloud client already
        # rejects path-traversal characters in object keys.
        if client.PREFIX == "file://":
            from datachain.fs.utils import is_subpath

            output_os = client.fs._strip_protocol(output_str)
            # On Windows, normalize backslash separators to forward slashes
            # so posixpath.join produces consistent paths.  On Linux/macOS
            # backslash is a legal filename character and must not be replaced.
            output_abs = os.path.abspath(output_os)
            if os.name == "nt":
                output_abs = output_abs.replace("\\", "/")
            dst = posixpath.join(output_abs, suffix)

            try:
                client.validate_file_path(suffix)
            except ValueError as exc:
                raise FileError(str(exc), stringify_path(output), suffix) from None

            if not is_subpath(output_abs, dst):
                raise FileError(
                    "destination is not within output directory",
                    stringify_path(output),
                    dst,
                )
        else:
            # For cloud exports, simply join the output prefix and suffix.
            # Relying on cloud clients to do their own validation.
            dst = posixpath.join(output_str, suffix)

        client.fs.makedirs(posixpath.dirname(dst), exist_ok=True)

        if link_type == "symlink":
            try:
                return self._symlink_to(dst)
            except OSError as exc:
                if exc.errno not in (errno.ENOTSUP, errno.EXDEV, errno.ENOSYS):
                    raise

        self.save(dst, client_config=client_config)

    def _set_stream(
        self,
        catalog: "Catalog",
        caching_enabled: bool = False,
        download_cb: Callback = DEFAULT_CALLBACK,
    ) -> None:
        self._catalog = catalog
        self._caching_enabled = caching_enabled
        self._download_cb = download_cb

    def ensure_cached(self) -> None:
        """Download the file to the local cache.

        `get_local_path` can be used to return the path to the cached copy on disk.
        This is useful when you need to pass the file to code that expects a local
        filesystem path (e.g. ``ffmpeg``, ``opencv``, ``pandas``, etc).

        Example:
            ```py
            file.ensure_cached()
            local_path = file.get_local_path()
            df = pandas.read_csv(local_path)
            ```
        """
        if self._catalog is None:
            raise RuntimeError(
                "cannot download file to cache because catalog is not setup"
            )
        client = self._catalog.get_client(self.source)
        client.download(self, callback=self._download_cb)

    async def _prefetch(self, download_cb: "Callback | None" = None) -> bool:
        if self._catalog is None:
            raise RuntimeError("cannot prefetch file because catalog is not setup")

        file = self
        if self.location:
            file = VFileRegistry.parent(self, self.location)  # type: ignore[arg-type]

        client = self._catalog.get_client(self.source)
        await client._download(file, callback=download_cb or self._download_cb)
        file._set_stream(
            self._catalog, caching_enabled=True, download_cb=DEFAULT_CALLBACK
        )
        return True

    def get_local_path(self) -> str | None:
        """Return path to a file in a local cache.

        Returns None if file is not cached.
        Raises an exception if cache is not setup.
        """
        if self._catalog is None:
            raise RuntimeError(
                "cannot resolve local file path because catalog is not setup"
            )
        return self._catalog.cache.get_path(self)

    def get_file_suffix(self):
        return PurePosixPath(self.path).suffix

    def get_file_ext(self):
        return PurePosixPath(self.path).suffix.lstrip(".")

    def get_file_stem(self):
        return PurePosixPath(self.path).stem

    def get_fs_path(self) -> str:
        """Combine ``source`` and ``path`` into the full location string.

        For cloud backends the result is a full URI-like (``s3://…``, ``gs://…``).
        For local files the result is a **bare OS path** (no ``file://``
        prefix).

        Examples:
            ```py
            # Cloud (S3, GCS, Azure, …)
            f = File(source="s3://my-bucket", path="data/image.jpg")
            f.get_fs_path()  # 's3://my-bucket/data/image.jpg'

            # Local files
            f = File(source="file:///home/user/project", path="out/result.csv")
            f.get_fs_path()  # '/home/user/project/out/result.csv'

            # No source — returns the relative path as-is
            f = File(source="", path="dir/file.txt")
            f.get_fs_path()  # 'dir/file.txt'
            ```

        Raises:
            FileError: If ``path`` is empty, ends with ``/``, or contains
                ``.`` / ``..`` segments.  For local files, also rejects
                absolute paths, drive letters, and empty segments.
        """
        # Fast path: return cached result when source and path are unchanged.
        cache = self._fs_path_cache
        if cache is not None and cache[0] == self.source and cache[1] == self.path:
            return cache[2]

        from datachain.client.fsspec import Client

        client_cls = Client.get_implementation(self.source or "")
        try:
            client_cls.validate_file_path(self.path)
            client_cls.validate_source(self.source)
        except ValueError as exc:
            raise FileError(str(exc), self.source, self.path) from exc
        path = self.path

        if not self.source:
            result = path
        elif self.source.startswith("file://"):
            base_path = client_cls.FS_CLASS._strip_protocol(self.source)
            result = Path(base_path, *PurePosixPath(path).parts).as_posix()
        else:
            # Cloud: build a full URI.
            name = client_cls.FS_CLASS._strip_protocol(self.source)
            base = str(client_cls.storage_uri(name))
            if base.endswith("/"):
                result = f"{base}{path}"
            else:
                result = f"{base}/{path}"

        self._fs_path_cache = (self.source, self.path, result)
        return result

    def _get_destination_suffix(self, placement: ExportPlacement) -> str:
        """Return the relative suffix used when exporting to an output prefix."""
        if placement == "filename":
            path = self.name
        elif placement == "etag":
            path = f"{self.etag}{self.get_file_suffix()}"
        elif placement == "fullpath":
            path = self.path
            source = urlparse(self.source)
            if source.scheme and source.scheme != "file":
                path = posixpath.join(source.netloc, path.lstrip("/"))
        elif placement == "filepath":
            path = self.path
        elif placement == "checksum":
            raise NotImplementedError("Checksum placement not implemented yet")
        else:
            raise ValueError(f"Unsupported file export placement: {placement}")

        # Always treat the computed suffix as relative for joining.
        # This prevents `posixpath.join()` from dropping the output prefix when
        # `path` starts with '/'.
        return path.lstrip("/")

    def get_fs(self):
        return self._catalog.get_client(self.source).fs

    def get_hash(self) -> str:
        fingerprint = f"{self.source}/{self.path}/{self.version}/{self.etag}"
        if self.location:
            fingerprint += f"/{self.location}"
        return sha256(fingerprint.encode()).hexdigest()

    def resolve(self) -> "Self":
        """
        Resolve a File object by checking its existence and updating its metadata.

        Returns:
            File: The resolved File object with updated metadata.
        """
        if self._catalog is None:
            raise RuntimeError("Cannot resolve file: catalog is not set")

        if self.location:
            raise VFileError(
                "Resolving a virtual file is not supported",
                self.source,
                self.path,
            )

        try:
            client = self._catalog.get_client(self.source)
        except NotImplementedError as e:
            raise RuntimeError(
                f"Unsupported protocol for file source: {self.source}"
            ) from e

        try:
            converted_info = client.get_file_info(self.path)
            # get_file_info always returns a base File; re-wrap as type(self)
            # so resolve() preserves the subclass (TextFile, ImageFile, …).
            res = type(self)(**converted_info.model_dump())
            res._set_stream(self._catalog)
            return res
        except (FileNotFoundError, PermissionError, OSError) as e:
            logger.warning(
                "Error when resolving %s/%s: %s",
                self.source,
                self.path,
                str(e),
            )

        res = type(self)(
            path=self.path,
            source=self.source,
            size=0,
            etag="",
            version="",
            is_latest=True,
            last_modified=TIME_ZERO,
        )
        res._set_stream(self._catalog)
        return res

    def rebase(
        self,
        old_base: str,
        new_base: str,
        suffix: str = "",
        extension: str = "",
    ) -> str:
        """
        Rebase the file's URI from one base directory to another.

        Args:
            old_base: Base directory to remove from the file's URI
            new_base: New base directory to prepend
            suffix: Optional suffix to add before file extension
            extension: Optional new file extension (without dot)

        Returns:
            str: Rebased URI with new base directory

        Raises:
            ValueError: If old_base is not found in the file's URI

        Examples:
            ```py
            file = File(source="s3://bucket", path="data/2025-05-27/file.wav")
            file.rebase("s3://bucket/data", "s3://output-bucket/processed",
                        extension="mp3")
            # 's3://output-bucket/processed/2025-05-27/file.mp3'

            file.rebase("data/audio", "/local/output", suffix="_ch1",
                        extension="npy")
            # '/local/output/file_ch1.npy'
            ```
        """
        return rebase_path(self.get_fs_path(), old_base, new_base, suffix, extension)


class TextFile(File):
    """`DataModel` for reading text files."""

    @contextmanager
    def open(
        self,
        mode: str = "r",
        *,
        client_config: dict[str, Any] | None = None,
        **open_kwargs,
    ) -> Iterator[Any]:
        """Open the file and return a file-like object.
        Default to text mode"""
        with super().open(
            mode=mode, client_config=client_config, **open_kwargs
        ) as stream:
            yield stream

    def read(self, **open_kwargs):
        """Return file contents as text (default mode for TextFile)."""
        return self.read_text(**open_kwargs)

    def read_text(self, **open_kwargs):
        """Return file contents as text.

        **open_kwargs : Any
            Extra keyword arguments forwarded to ``open()`` (e.g. encoding).
        """
        with self.open(**open_kwargs) as stream:
            return stream.read()

    def save(self, destination: str, client_config: dict | None = None) -> "TextFile":
        """Writes its content to destination"""
        result = super().save(destination, client_config=client_config)
        tf = TextFile(**result.model_dump())
        tf._set_stream(self._catalog)
        return tf


class ImageFile(File):
    """`DataModel` for reading image files."""

    def get_info(self) -> "Image":
        """
        Retrieves metadata and information about the image file.

        Returns:
            Image: A Model containing image metadata such as width, height and format.
        """
        from .image import image_info

        return image_info(self)

    def read(self):
        """Returns `PIL.Image.Image` object."""
        from PIL import Image as PilImage

        fobj = super().read()
        return PilImage.open(BytesIO(fobj))

    def save(  # type: ignore[override]
        self,
        destination: str,
        format: str | None = None,
        client_config: dict | None = None,
    ) -> "ImageFile":
        """Save the image to *destination*, optionally re-encoding to *format*.

        If ``destination`` is a remote path, the image will be uploaded to
        remote storage.  See :meth:`File.save` for full destination semantics.
        """
        if self._catalog is None:
            raise RuntimeError("Cannot save file: catalog is not set")
        destination = stringify_path(destination)

        # If format is not provided, determine it from the file extension
        if format is None:
            from pathlib import PurePosixPath

            from PIL import Image as PilImage

            ext = PurePosixPath(destination).suffix.lower()
            format = PilImage.registered_extensions().get(ext)

        if not format:
            raise FileError(
                f"Can't determine format for destination '{destination}'",
                self.source,
                self.path,
            )

        buf = BytesIO()
        self.read().save(buf, format=format)
        client, rel_path = self._resolve_destination(destination, client_config)
        result = client.upload(buf.getvalue(), rel_path)
        img = ImageFile(**result.model_dump())
        img._set_stream(self._catalog)
        return img


class Image(DataModel):
    """
    A data model representing metadata for an image file.

    Attributes:
        width (int): The width of the image in pixels. Defaults to -1 if unknown.
        height (int): The height of the image in pixels. Defaults to -1 if unknown.
        format (str): The format of the image file (e.g., 'jpg', 'png').
                      Defaults to an empty string.
    """

    width: int = Field(default=-1)
    height: int = Field(default=-1)
    format: str = Field(default="")


class VideoFile(File):
    """
    A data model for handling video files.

    This model inherits from the `File` model and provides additional functionality
    for reading video files, extracting video frames, and splitting videos into
    fragments.

    The ``video_stream_index`` argument used by video methods is the zero-based
    index among video streams, matching FFmpeg ``v:N`` and PyAV
    ``container.streams.video[N]`` selectors.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._video_info_cache: dict[int, Any] = {}

    def get_info(self, video_stream_index: int = 0) -> "Video":
        """
        Retrieves metadata and information about the video file.

        Metadata is read through ``File.open()``, so it can stream when caching
        is disabled. When caching is enabled, opening the file may populate the
        local cache first.

        Args:
            video_stream_index: Zero-based index among video streams to inspect.
                Defaults to 0.

        Returns:
            Video: A Model containing video metadata such as duration,
                   resolution, frame rate, and codec details.
        """
        from .video import video_info

        if video_stream_index not in self._video_info_cache:
            self._video_info_cache[video_stream_index] = video_info(
                self, video_stream_index=video_stream_index
            )
        return self._video_info_cache[video_stream_index]

    def get_frame(self, frame: int, video_stream_index: int = 0) -> "VideoFrame":
        """
        Returns a specific video frame by its frame number.

        This returns a frame reference without decoding or validating that the
        frame exists. The returned timestamp is estimated from FPS metadata.
        Pixel access methods decode the requested frame; use ``get_frames()``
        for sequential access and decoded frame timestamps when available.

        Args:
            frame (int): The frame number to read.
            video_stream_index: Zero-based index among video streams to read.
                Defaults to 0.

        Returns:
            VideoFrame: Video frame model.
        """
        if frame < 0:
            raise ValueError("frame must be a non-negative integer")

        from .video import video_frame

        return video_frame(self, frame, video_stream_index=video_stream_index)

    def get_frames(
        self,
        start: int = 0,
        end: int | None = None,
        step: int = 1,
        video_stream_index: int = 0,
    ) -> "Iterator[VideoFrame]":
        """
        Returns video frames from the specified range in the video.

        Args:
            start (int): The starting frame number (default: 0).
            end (int, optional): The ending frame number (exclusive). If None,
                                 frames are read until the end of the video
                                 (default: None).
            step (int): The interval between frames to read (default: 1).
            video_stream_index: Zero-based index among video streams to read.
                Defaults to 0.

        Returns:
            Iterator[VideoFrame]: An iterator yielding video frames.

        Note:
            If end is not specified, number of frames will be taken from the video file,
            this means video metadata needs to be read.
        """
        from .video import validate_frame_range, video_frames

        start, end, step = validate_frame_range(
            self, start, end, step, video_stream_index=video_stream_index
        )

        yield from video_frames(
            self, start, end, step, video_stream_index=video_stream_index
        )

    def get_fragment(self, start: float, end: float) -> "VideoFragment":
        """
        Returns a video fragment from the specified time range.

        Args:
            start (float): The start time of the fragment in seconds.
            end (float): The end time of the fragment in seconds.

        Returns:
            VideoFragment: A Model representing the video fragment.
        """
        if start < 0 or end < 0 or start >= end:
            raise ValueError(
                f"Can't get video fragment for '{self.path}', "
                f"invalid time range: ({start:.3f}, {end:.3f})"
            )

        return VideoFragment(video=self, start=start, end=end)

    def get_fragments(
        self,
        duration: float,
        start: float = 0,
        end: float | None = None,
    ) -> "Iterator[VideoFragment]":
        """
        Splits the video into multiple fragments of a specified duration.

        Args:
            duration (float): The duration of each video fragment in seconds.
            start (float): The starting time in seconds (default: 0).
            end (float, optional): The ending time in seconds. If None, the entire
                                   remaining video is processed (default: None).

        Returns:
            Iterator[VideoFragment]: An iterator yielding video fragments.

        Note:
            If end is not specified, duration will be taken from the video file,
            which means video metadata needs to be read.
        """
        if duration <= 0:
            raise ValueError("duration must be a positive float")
        if start < 0:
            raise ValueError("start must be a non-negative float")

        if end is None:
            end = self.get_info().duration

        if end < 0:
            raise ValueError("end must be a non-negative float")
        if start >= end:
            raise ValueError("start must be less than end")

        while start < end:
            yield self.get_fragment(start, min(start + duration, end))
            start += duration

    def save(  # type: ignore[override]
        self,
        destination: str,
        client_config: dict | None = None,
    ) -> "VideoFile":
        """Writes its content to destination"""
        result = super().save(destination, client_config=client_config)
        vf = VideoFile(**result.model_dump())
        vf._set_stream(self._catalog)
        return vf


class AudioFile(File):
    """
    A data model for handling audio files.

    This model inherits from the `File` model and provides additional functionality
    for reading audio files, extracting audio fragments, and splitting audio into
    fragments.
    """

    def get_info(self) -> "Audio":
        """
        Retrieves metadata and information about the audio file.

        Metadata is read through ``File.open()``, so it can stream when caching
        is disabled. When caching is enabled, opening the file may populate the
        local cache first. For UDFs that only need audio metadata, it can be
        useful to disable caching and prefetching.

        Returns:
            Audio: A Model containing audio metadata such as duration,
                   sample rate, channels, and codec details.
        """
        from .audio import audio_info

        return audio_info(self)

    def get_fragment(self, start: float, end: float) -> "AudioFragment":
        """
        Returns an audio fragment from the specified time range. It does not
        download the file, neither it actually extracts the fragment. It returns
        a Model representing the audio fragment, which can be used to read or save
        it later.

        Args:
            start (float): The start time of the fragment in seconds.
            end (float): The end time of the fragment in seconds.

        Returns:
            AudioFragment: A Model representing the audio fragment.
        """
        if start < 0 or end < 0 or start >= end:
            raise ValueError(
                f"Can't get audio fragment for '{self.path}', "
                f"invalid time range: ({start:.3f}, {end:.3f})"
            )

        return AudioFragment(audio=self, start=start, end=end)

    def get_fragments(
        self,
        duration: float,
        start: float = 0,
        end: float | None = None,
    ) -> "Iterator[AudioFragment]":
        """
        Splits the audio into multiple fragments of a specified duration.

        Args:
            duration (float): The duration of each audio fragment in seconds.
            start (float): The starting time in seconds (default: 0).
            end (float, optional): The ending time in seconds. If None, the entire
                                   remaining audio is processed (default: None).

        Returns:
            Iterator[AudioFragment]: An iterator yielding audio fragments.

        Note:
            If end is not specified, number of samples will be taken from the
            audio file, this means audio metadata needs to be read.
        """
        if duration <= 0:
            raise ValueError("duration must be a positive float")
        if start < 0:
            raise ValueError("start must be a non-negative float")

        if end is None:
            end = self.get_info().duration

        if end < 0:
            raise ValueError("end must be a non-negative float")
        if start >= end:
            raise ValueError("start must be less than end")

        while start < end:
            yield self.get_fragment(start, min(start + duration, end))
            start += duration

    def save(  # type: ignore[override]
        self,
        destination: str,
        format: str | None = None,
        start: float = 0,
        end: float | None = None,
        client_config: dict | None = None,
    ) -> "AudioFile":
        """Save audio file or extract fragment to specified format.

        If ``destination`` is a remote path, the audio file will be uploaded
        to remote storage.

        Args:
            destination: Output directory path or URI (e.g. ``s3://…``, ``gs://…``).
            format: Output format ('wav', 'mp3', etc). Defaults to source format.
            start: Start time in seconds (>= 0). Defaults to 0.
            end: End time in seconds. If None, extracts to end of file.
            client_config: Optional client configuration.

        Returns:
            AudioFile: New audio file with format conversion/extraction applied.

        Examples:
            audio.save("/path", "mp3")                        # Entire file to MP3
            audio.save("s3://bucket/path", "wav", start=2.5)  # From 2.5s to end as WAV
            audio.save("/path", "flac", start=1, end=3)       # 1-3s fragment as FLAC
        """
        if self._catalog is None:
            raise RuntimeError("Cannot save file: catalog is not set")

        from .audio import save_audio

        return save_audio(self, destination, format, start, end, client_config)


class AudioFragment(DataModel):
    """
    A data model for representing an audio fragment.

    This model represents a specific fragment within an audio file with defined
    start and end times. It allows access to individual fragments and provides
    functionality for reading and saving audio fragments as separate audio files.

    Attributes:
        audio (AudioFile): The audio file containing the audio fragment.
        start (float): The starting time of the audio fragment in seconds.
        end (float): The ending time of the audio fragment in seconds.
    """

    audio: AudioFile
    start: float
    end: float

    def get_np(self) -> tuple["ndarray", int]:
        """
        Returns the audio fragment as a NumPy array with sample rate.

        Returns:
            tuple[ndarray, int]: A tuple containing the audio data as a NumPy array
                               and the sample rate.
        """
        from .audio import audio_to_np

        duration = self.end - self.start
        return audio_to_np(self.audio, self.start, duration)

    def read_bytes(self, format: str = "wav") -> bytes:
        """
        Returns the audio fragment as audio bytes.

        Args:
            format (str): The desired audio format (e.g., 'wav', 'mp3').
                         Defaults to 'wav'.

        Returns:
            bytes: The encoded audio fragment as bytes.
        """
        from .audio import audio_to_bytes

        duration = self.end - self.start
        return audio_to_bytes(self.audio, format, self.start, duration)

    def save(
        self,
        destination: str,
        format: str | None = None,
        client_config: dict | None = None,
    ) -> "AudioFile":
        """
        Saves the audio fragment as a new audio file.

        If ``destination`` is a remote path, the audio file will be uploaded
        to remote storage.

        Args:
            destination: Output directory path or URI (e.g. ``s3://…``, ``gs://…``).
            format: Output audio format (e.g., 'wav', 'mp3').
                    If None, inferred from the file extension.
            client_config: Optional client configuration (e.g. credentials).

        Returns:
            AudioFile: A Model representing the saved audio file.
        """
        from .audio import save_audio

        return save_audio(
            self.audio,
            destination,
            format,
            self.start,
            self.end,
            client_config=client_config,
        )


class VideoFrame(DataModel):
    """
    A data model for representing a video frame.

    This model inherits from the `VideoFile` model and adds a `frame` attribute,
    which represents a specific frame within a video file. It allows access
    to individual frames and provides functionality for reading and saving
    video frames as image files.

    Attributes:
        video (VideoFile): The video file containing the video frame.
        frame (int): The frame number referencing a specific frame in the video file.
        video_stream_index (int): Zero-based index among video streams containing
            the frame.
        timestamp (float): Frame timestamp in seconds. Frames returned by
            ``VideoFile.get_frame()`` use FPS metadata. Frames yielded by
            ``VideoFile.get_frames()`` use decoded frame timestamps when
            available.

    Note:
        The decoded ``av.VideoFrame`` is cached in the ``_decoded`` instance
        attribute the first time any of ``get_np()``, ``read_bytes()``, or
        ``save()`` is called.  Frames yielded by ``VideoFile.get_frames()``
        are pre-populated with the decoded frame, so the first call to any of
        those methods requires no I/O.  The cache is held for the lifetime of
        the ``VideoFrame`` object; when many frames are kept in memory at once
        (e.g. ``list(video.get_frames())``) the cached pixel buffers can
        create significant memory pressure (~3 MB each for 1080p video).  The
        cache is excluded from pickling so cross-process serialisation (e.g.
        DataChain ``.gen()`` workers) is unaffected.
    """

    video: VideoFile
    frame: int
    video_stream_index: int = 0
    timestamp: float

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._decoded = None

    def __getstate__(self):
        state = super().__getstate__()
        state["__dict__"] = state["__dict__"].copy()
        state["__dict__"]["_decoded"] = None
        return state

    def get_np(self) -> "ndarray":
        """
        Returns a video frame from the video file as a NumPy array.

        The decoded ``av.VideoFrame`` is cached in ``_decoded`` on the first
        call, so repeated calls to ``get_np()`` return the cached pixels
        without a second decode pass regardless of whether the frame came
        from ``VideoFile.get_frames()`` or ``VideoFile.get_frame()``.

        Returns:
            ndarray: A NumPy array representing the video frame,
                     in the shape (height, width, channels).
        """
        if self._decoded is not None:
            return self._decoded.to_ndarray(format="rgb24")

        from .video import _decode_video_frame

        self._decoded, _ = _decode_video_frame(
            self.video,
            self.frame,
            self.video_stream_index,
        )
        return self._decoded.to_ndarray(format="rgb24")

    def read_bytes(self, format: str = "jpg") -> bytes:
        """
        Returns a video frame from the video file as image bytes.

        Uses the cached decoded frame when available (e.g. after ``get_np()``
        or for frames yielded by ``VideoFile.get_frames()``), avoiding a second
        decode pass.

        Args:
            format (str): The desired image format (e.g., 'jpg', 'png').
                          Defaults to 'jpg'.

        Returns:
            bytes: The encoded video frame as image bytes.
        """
        from PIL import Image as PilImage

        from .video import _image_format

        buf = BytesIO()
        PilImage.fromarray(self.get_np()).save(buf, format=_image_format(format))
        return buf.getvalue()

    def save(
        self,
        destination: str | os.PathLike[str],
        format: str = "jpg",
        client_config: dict | None = None,
    ) -> "ImageFile":
        """
        Saves the current video frame as an image file.

        Uses the cached decoded frame when available (e.g. after ``get_np()``
        or for frames yielded by ``VideoFile.get_frames()``), avoiding a second
        decode pass.

        If ``destination`` is a remote path, the image file will be uploaded
        to remote storage.

        Args:
            destination: Output directory path or URI (e.g. ``s3://…``, ``gs://…``).
            format: Image format (e.g., 'jpg', 'png'). Defaults to 'jpg'.
            client_config: Optional client configuration (e.g. credentials).

        Returns:
            ImageFile: A Model representing the saved image file.
        """
        catalog = self.video._catalog
        if catalog is None:
            raise RuntimeError("Cannot save video frame: catalog is not set")

        destination = stringify_path(destination)
        image_bytes = self.read_bytes(format)
        extension = format.removeprefix(".")
        output_file = posixpath.join(
            destination, f"{self.video.get_file_stem()}_{self.frame:04d}.{extension}"
        )
        client, rel_path = self.video._resolve_destination(output_file, client_config)
        result = client.upload(image_bytes, rel_path)
        image = ImageFile(**result.model_dump())
        image._set_stream(catalog)
        return image


class VideoFragment(DataModel):
    """
    A data model for representing a video fragment.

    This model inherits from the `VideoFile` model and adds `start`
    and `end` attributes, which represent a specific fragment within a video file.
    It allows access to individual fragments and provides functionality for reading
    and saving video fragments as separate video files.

    Attributes:
        video (VideoFile): The video file containing the video fragment.
        start (float): The starting time of the video fragment in seconds.
        end (float): The ending time of the video fragment in seconds.
    """

    video: VideoFile
    start: float
    end: float

    def save(
        self,
        destination: str,
        format: str | None = None,
        client_config: dict | None = None,
        timeout: float | None = None,
    ) -> "VideoFile":
        """
        Saves the video fragment as a new video file.

        If ``destination`` is a remote path, the video file will be uploaded
        to remote storage.

        Args:
            destination: Output directory path or URI (e.g. ``s3://…``, ``gs://…``).
            format: Output video format (e.g., 'mp4', 'avi').
                    If None, inferred from the file extension.
            client_config: Optional client configuration (e.g. credentials).
            timeout: FFmpeg subprocess timeout in seconds. If None, a timeout is
                computed from the fragment duration. Set to 0 to disable.

        Returns:
            VideoFile: A Model representing the saved video file.
        """
        from .video import save_video_fragment

        return save_video_fragment(
            self.video,
            self.start,
            self.end,
            destination,
            format,
            client_config=client_config,
            timeout=timeout,
        )


class Video(DataModel):
    """
    A data model representing metadata for a video file.

    Attributes:
        width (int): The width of the video in pixels. Defaults to -1 if unknown.
        height (int): The height of the video in pixels. Defaults to -1 if unknown.
        fps (float): The frame rate of the video (frames per second).
                     Defaults to -1.0 if unknown.
        duration (float): The total duration of the video in seconds.
                          Defaults to -1.0 if unknown.
        frames (int): The total number of frames in the video.
                      Defaults to -1 if unknown.
        format (str): The format of the video file (e.g., 'mp4', 'avi').
                      Defaults to an empty string.
        codec (str): The codec used for encoding the video. Defaults to an empty string.
    """

    width: int = Field(default=-1)
    height: int = Field(default=-1)
    fps: float = Field(default=-1.0)
    duration: float = Field(default=-1.0)
    frames: int = Field(default=-1)
    format: str = Field(default="")
    codec: str = Field(default="")


class Audio(DataModel):
    """
    A data model representing metadata for an audio file.

    Attributes:
        sample_rate (int): The sample rate of the audio (samples per second).
                          Defaults to -1 if unknown.
        channels (int): The number of audio channels. Defaults to -1 if unknown.
        duration (float): The total duration of the audio in seconds.
                         Defaults to -1.0 if unknown.
        samples (int): The total number of samples in the audio.
                      Defaults to -1 if unknown.
        format (str): The format of the audio file (e.g., 'wav', 'mp3').
                     Defaults to an empty string.
        codec (str): The codec used for encoding the audio. Defaults to an empty string.
        bit_rate (int): The bit rate of the audio in bits per second.
                       Defaults to -1 if unknown.
    """

    sample_rate: int = Field(default=-1)
    channels: int = Field(default=-1)
    duration: float = Field(default=-1.0)
    samples: int = Field(default=-1)
    format: str = Field(default="")
    codec: str = Field(default="")
    bit_rate: int = Field(default=-1)

    @staticmethod
    def get_channel_name(num_channels: int, channel_idx: int) -> str:
        """Map channel index to meaningful name based on common audio formats"""
        channel_mappings = {
            1: ["Mono"],
            2: ["Left", "Right"],
            4: ["W", "X", "Y", "Z"],  # First-order Ambisonics
            6: ["FL", "FR", "FC", "LFE", "BL", "BR"],  # 5.1 surround
            8: ["FL", "FR", "FC", "LFE", "BL", "BR", "SL", "SR"],  # 7.1 surround
        }

        if num_channels in channel_mappings:
            channels = channel_mappings[num_channels]
            if 0 <= channel_idx < len(channels):
                return channels[channel_idx]

        return f"Ch{channel_idx + 1}"


class ArrowRow(DataModel):
    """`DataModel` for reading row from Arrow-supported file."""

    file: File
    index: int
    kwargs: dict

    @contextmanager
    def open(self):
        """Stream row contents from indexed file."""
        from pyarrow.dataset import dataset

        if self.file._caching_enabled:
            self.file.ensure_cached()
            path = self.file.get_local_path()
            ds = dataset(path, **self.kwargs)
        else:
            path = self.file.get_fs_path()
            ds = dataset(path, filesystem=self.file.get_fs(), **self.kwargs)

        return ds.take([self.index]).to_reader()

    def read(self):
        """Returns row contents as dict."""
        with self.open() as record_batch:
            return record_batch.to_pylist()[0]


def get_file_type(type_: FileType = "binary") -> type[File]:
    file: type[File] = File
    if type_ == "text":
        file = TextFile
    elif type_ == "image":
        file = ImageFile  # type: ignore[assignment]
    elif type_ == "video":
        file = VideoFile
    elif type_ == "audio":
        file = AudioFile

    return file
