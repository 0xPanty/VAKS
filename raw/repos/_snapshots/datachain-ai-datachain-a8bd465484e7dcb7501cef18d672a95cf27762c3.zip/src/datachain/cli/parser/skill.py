from datachain.cli.commands.skill import TARGET_LAYOUT
from datachain.cli.parser.utils import CustomHelpFormatter


def add_skill_parser(subparsers, parent_parser) -> None:
    skill_help = "Manage and install DataChain AI skills"
    skill_description = "Commands for managing DataChain skills for AI coding tools."
    skill_parser = subparsers.add_parser(
        "skill",
        parents=[parent_parser],
        description=skill_description,
        help=skill_help,
        formatter_class=CustomHelpFormatter,
    )
    skill_subparser = skill_parser.add_subparsers(
        dest="skill_cmd",
        help="Use `datachain skill CMD --help` to display command-specific help",
    )

    install_help = "Install DataChain skills into an AI coding tool"
    install_description = (
        "Install DataChain skills (core, knowledge, jobs) into an AI coding tool "
        "such as Claude Code, Cursor, Codex, GitHub Copilot, or Pi."
    )
    install_parser = skill_subparser.add_parser(
        "install",
        parents=[parent_parser],
        description=install_description,
        help=install_help,
        formatter_class=CustomHelpFormatter,
    )
    install_parser.add_argument(
        "skills",
        nargs="?",
        default=None,
        metavar="SKILLS",
        help=(
            "Comma-separated skill names to install: core, knowledge, jobs "
            "(default: install all)"
        ),
    )
    install_parser.add_argument(
        "--target",
        choices=sorted(TARGET_LAYOUT.keys()),
        default="claude",
        help="Target AI coding tool to install skills into (default: claude)",
    )
    install_parser.add_argument(
        "--local",
        action="store_true",
        default=False,
        help=(
            "Install into the current project directory"
            " instead of the user home directory"
        ),
    )

    uninstall_help = "Uninstall DataChain skills from an AI coding tool"
    uninstall_description = (
        "Remove previously installed DataChain skills from an AI coding tool."
    )
    uninstall_parser = skill_subparser.add_parser(
        "uninstall",
        parents=[parent_parser],
        description=uninstall_description,
        help=uninstall_help,
        formatter_class=CustomHelpFormatter,
    )
    uninstall_parser.add_argument(
        "skills",
        nargs="?",
        default=None,
        metavar="SKILLS",
        help=(
            "Comma-separated skill names to uninstall: core, knowledge, jobs "
            "(default: uninstall all)"
        ),
    )
    uninstall_parser.add_argument(
        "--target",
        choices=sorted(TARGET_LAYOUT.keys()),
        default="claude",
        help="Target AI coding tool to uninstall skills from (default: claude)",
    )
    uninstall_parser.add_argument(
        "--local",
        action="store_true",
        default=False,
        help=(
            "Uninstall from the current project directory"
            " instead of the user home directory"
        ),
    )

    list_help = "List available DataChain skills"
    list_description = "List all available DataChain skills and supported targets."
    skill_subparser.add_parser(
        "list",
        parents=[parent_parser],
        description=list_description,
        help=list_help,
        formatter_class=CustomHelpFormatter,
    )
