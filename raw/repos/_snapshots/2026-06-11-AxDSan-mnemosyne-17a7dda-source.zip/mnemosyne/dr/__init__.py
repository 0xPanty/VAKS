"""Mnemosyne Disaster Recovery Module"""
