# Mnemosyne + Hermes Agent

Mnemosyne is the native memory provider for Hermes Agent. Two integration paths:

## Path 1: MCP (recommended for latest)

Add to your Hermes `config.yaml`:

```yaml
mcp:
  servers:
    mnemosyne:
      command: mnemosyne
      args: ["mcp"]
```

Tools register as native Hermes commands.

## Path 2: Hermes Plugin (built-in)

```bash
pip install mnemosyne-hermes
hermes config set memory.provider mnemosyne
hermes memory setup
```

This gives you **23 tools** — remember, recall, forget, stats, knowledge graph ops, multi-agent shared surface, scratchpad, export/import, and more. All native Hermes commands.

## Usage

In Hermes, use the built-in commands:
- `mnemosyne_remember` — Store a memory
- `mnemosyne_recall` — Search memories
- `mnemosyne_forget` — Remove a memory
- `mnemosyne_stats` — View memory statistics
- `mnemosyne_sleep` — Run consolidation
