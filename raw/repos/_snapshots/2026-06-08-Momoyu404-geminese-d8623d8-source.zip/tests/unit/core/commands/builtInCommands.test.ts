import {
  BUILT_IN_COMMANDS,
  detectBuiltInCommand,
  getBuiltInCommandsForDropdown,
} from '../../../../src/core/commands/builtInCommands';

describe('builtInCommands', () => {
  describe('detectBuiltInCommand', () => {
    it('detects /clear command', () => {
      const result = detectBuiltInCommand('/clear');
      expect(result).not.toBeNull();
      expect(result?.command.name).toBe('clear');
      expect(result?.command.action).toBe('clear');
      expect(result?.args).toBe('');
    });

    it('detects /new command as alias for clear', () => {
      const result = detectBuiltInCommand('/new');
      expect(result).not.toBeNull();
      expect(result?.command.name).toBe('clear');
      expect(result?.command.action).toBe('clear');
    });

    it('is case-insensitive', () => {
      expect(detectBuiltInCommand('/CLEAR')).not.toBeNull();
      expect(detectBuiltInCommand('/Clear')).not.toBeNull();
      expect(detectBuiltInCommand('/NEW')).not.toBeNull();
    });

    it('detects command with trailing whitespace', () => {
      const result = detectBuiltInCommand('/clear ');
      expect(result).not.toBeNull();
      expect(result?.command.name).toBe('clear');
      expect(result?.args).toBe('');
    });

    it('detects command with arguments', () => {
      const result = detectBuiltInCommand('/clear some arguments');
      expect(result).not.toBeNull();
      expect(result?.command.name).toBe('clear');
      expect(result?.args).toBe('some arguments');
    });

    it('detects /add-file command with path argument', () => {
      const result = detectBuiltInCommand('/add-file /path/to/file');
      expect(result).not.toBeNull();
      expect(result?.command.name).toBe('add-file');
      expect(result?.command.action).toBe('add-file');
      expect(result?.args).toBe('/path/to/file');
    });

    it('detects /add-file command with home path', () => {
      const result = detectBuiltInCommand('/add-file ~/projects/file.md');
      expect(result).not.toBeNull();
      expect(result?.command.name).toBe('add-file');
      expect(result?.args).toBe('~/projects/file.md');
    });

    it('returns null for non-slash input', () => {
      expect(detectBuiltInCommand('clear')).toBeNull();
      expect(detectBuiltInCommand('hello /clear')).toBeNull();
    });

    it('returns null for unknown commands', () => {
      expect(detectBuiltInCommand('/unknown')).toBeNull();
      expect(detectBuiltInCommand('/foo')).toBeNull();
    });

    it('returns null for empty input', () => {
      expect(detectBuiltInCommand('')).toBeNull();
      expect(detectBuiltInCommand('   ')).toBeNull();
    });

    it('returns null for just slash', () => {
      expect(detectBuiltInCommand('/')).toBeNull();
    });

    it('detects /resume command', () => {
      const result = detectBuiltInCommand('/resume');
      expect(result).not.toBeNull();
      expect(result?.command.name).toBe('resume');
      expect(result?.command.action).toBe('resume');
      expect(result?.args).toBe('');
    });

    it('detects /fork command', () => {
      const result = detectBuiltInCommand('/fork');
      expect(result).not.toBeNull();
      expect(result?.command.name).toBe('fork');
      expect(result?.command.action).toBe('fork');
      expect(result?.args).toBe('');
    });

    it('detects /fork case-insensitively', () => {
      expect(detectBuiltInCommand('/FORK')).not.toBeNull();
      expect(detectBuiltInCommand('/Fork')).not.toBeNull();
    });
  });

  describe('getBuiltInCommandsForDropdown', () => {
    it('returns all built-in commands with proper format', () => {
      const commands = getBuiltInCommandsForDropdown();

      expect(commands.length).toBe(BUILT_IN_COMMANDS.length);

      const clearCmd = commands.find((c) => c.name === 'clear');
      expect(clearCmd).toBeDefined();
      expect(clearCmd?.id).toBe('builtin:clear');
      expect(clearCmd?.description).toBe('Start a new conversation');
      expect(clearCmd?.content).toBe('');
    });

    it('returns commands compatible with SlashCommand interface', () => {
      const commands = getBuiltInCommandsForDropdown();

      for (const cmd of commands) {
        expect(cmd).toHaveProperty('id');
        expect(cmd).toHaveProperty('name');
        expect(cmd).toHaveProperty('description');
        expect(cmd).toHaveProperty('content');
      }
    });
  });

  describe('BUILT_IN_COMMANDS', () => {
    it('has clear command with new alias', () => {
      const clearCmd = BUILT_IN_COMMANDS.find((c) => c.name === 'clear');
      expect(clearCmd).toBeDefined();
      expect(clearCmd?.aliases).toContain('new');
      expect(clearCmd?.action).toBe('clear');
    });

    it('has add-file command that accepts args', () => {
      const addFileCmd = BUILT_IN_COMMANDS.find((c) => c.name === 'add-file');
      expect(addFileCmd).toBeDefined();
      expect(addFileCmd?.action).toBe('add-file');
      expect(addFileCmd?.hasArgs).toBe(true);
      expect(addFileCmd?.description).toBe('Add external context file');
    });

    it('has resume command', () => {
      const resumeCmd = BUILT_IN_COMMANDS.find((c) => c.name === 'resume');
      expect(resumeCmd).toBeDefined();
      expect(resumeCmd?.action).toBe('resume');
      expect(resumeCmd?.description).toBe('Resume a previous conversation');
    });

    it('has fork command without args', () => {
      const forkCmd = BUILT_IN_COMMANDS.find((c) => c.name === 'fork');
      expect(forkCmd).toBeDefined();
      expect(forkCmd?.action).toBe('fork');
      expect(forkCmd?.hasArgs).toBeUndefined();
    });
  });

});
