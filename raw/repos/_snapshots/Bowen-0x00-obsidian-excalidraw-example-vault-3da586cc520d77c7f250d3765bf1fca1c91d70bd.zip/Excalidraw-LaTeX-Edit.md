$$
\int f(x) dx
$$