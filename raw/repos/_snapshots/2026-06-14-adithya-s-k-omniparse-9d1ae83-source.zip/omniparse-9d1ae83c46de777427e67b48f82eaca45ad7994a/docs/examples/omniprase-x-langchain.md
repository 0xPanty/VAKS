# OmniPrase x Langchain

